# #725 filesystem limitation — checkpoint002 only

OFFSOURCE evidence extraction from source `f6c2a4fcef3f533d9a474575e89df353a33eedd4`. This is the completed two-second **NoQualification smoke**, not normal-trial evidence. No source changes or new execution were performed.

The native registry and completed frames contain exactly eight `fs.write` calls, each replacing 128 verified bytes in `qualified-editor.txt`. No other `fs.*` verb was measured.

| Distinct maximum | Original suffix | Actual value | Same-call helper / padded envelope / full frame hold | Native evidence |
| --- | --- | --- | --- | --- |
| Unpadded current-read + atomic-replace helper | write/00032 |194µs |194 /10065 /44354µs |WriteId(12235), WaitId(17356), observer 117; raw line 265 |
| Padded service envelope | write/00075 |150075µs |187 /150075 /184457µs |WriteId(38578), WaitId(52820), observer 261; raw line 308 |
| Full frame app-lock hold | write/00035 |186432µs |151 /150072 /186432µs |WriteId(13745), WaitId(24282), observer 134; raw line 268 |

The separately recorded native FiniteService interval for write 75 is 4325634→4475712µs (150078µs); for write 35 it is 1761034→1911110µs (150076µs). These endpoints differ from the service envelope timer; neither is replaced with the configured 150000µs target. All eight observed full fs.write holds were below the unchanged strict 200000µs limit.

`app/rpc.rs:409` holds AppState through dispatch. `app/fs.rs:383` performs fs.write inline; its test-only service wrapper at 399 covers only `replace_editor_text` (423–427): current read/editability checks and descriptor-relative replacement. `scoped_file.rs:115` writes and syncs the file, then renameat at 129 and directory sync at 143. `test_support/finite_service.rs:266` measures actual work before target padding;198–202 performs the remaining-target sleep;208 records the observed padded envelope. Scope resolution, publication/invalidation and the final response read (`app/fs.rs:411`) are outside the narrow helper timer.

**No unpadded whole-frame hold was measured.** The helper duration is wall time, not isolated syscall time. Full frame held time sums all AppState acquisitions (`timing.rs:563`, drop accounting 771–783) and includes padding and surrounding guarded work. Subtracting a configured target or unrelated maxima cannot produce an unpadded hold measurement. No individual filesystem holder is assigned blame for a particular MCP wait from these aggregate samples.

The complete public filesystem mutation family registered at `api/v1/git.rs:68`–103 remains affected:

| Verb | Product handler | Measured here |
| --- | --- | --- |
| `fs.write` | `app/fs.rs:383` | 8 calls |
| `fs.createDirectory` | `app/fs.rs:261` | No |
| `fs.createFile` | `app/fs.rs:278` | No |
| `fs.mkdir` | `app/fs.rs:331` | No |
| `fs.uploadBegin` | `app/fs/uploads.rs:209` | No |
| `fs.uploadChunk` | `app/fs/uploads.rs:169` | No |
| `fs.uploadFinish` | `app/fs/uploads.rs:109` | No |
| `fs.uploadAbort` | `app/fs/uploads.rs:99` | No |

#725 therefore remains a limitation: real synchronous filesystem work occupies AppState, so a real operation approaching 200 ms can consume the strict <200 ms hold budget before surrounding work. Eight small saves do not establish a ceiling for arbitrary storage, larger payloads or the unexercised verbs. Filesystem reads and deferred Git operations are separate paths; this is not an exhaustive application-wide syscall inventory.

Raw source of all three maxima: `gates/release-checkpoint-002-f6c2a4fcef3f/smoke/retained-pipeline-VBED87/traffic/small_trial_1/control-rows.jsonl`, lines 265, 268, 308; full original prefix `qual/small_trial_1/`. Native roots and intervals are retained in sibling `native-registry-final.json`; `control-other-frames.jsonl` contains no additional fs.* samples.

Raw SHA256:

- `control-rows.jsonl`: `ae57bd9b600136b78929c1bef90701e5fad02dbd513ee546486bbb5176f7e9ec`
- `control-other-frames.jsonl`: `5177c268fc6240808402103d389ba40e0dfd2881eadf2ec3ccfc444d3f98f6ae`
- `native-registry-final.json`: `a43b610a3abeec94ec304754c54e1ae6886e38b2e7bc095e7cd569d7eb5e8e34`
- `NoQualification.json`: `ee24118faacce98bec4be788553e9c2fc95b988fa61ef854632978385b3fa766`

The companion JSON contains all eight paired samples, precise source references, checkpoint source hashes and explicit instrumentation limits. Source references use the frozen checkpoint bytes; equality against the currently read source is recorded per file.
