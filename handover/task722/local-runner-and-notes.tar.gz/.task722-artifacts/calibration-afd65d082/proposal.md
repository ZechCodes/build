# Runner calibration proposal

Run: 39627704997; job: 119317253458; source: afd65d0829c51dff6889d61715c8e5b017a24867.
Raw log SHA256: e77a73bd99ca062b7b7bfc0ebe05731d62f881d9b4358ef1f1fb5c706c4c907e

Independent calculation concatenates all 12 writer sample vectors, sorts once, and takes nearest-rank ceil(0.95*223)-1 = index 211. No per-verb percentile averaging; 352 read frames excluded.

| Metric | ms |
|---|---:|
| count | 223.000000 |
| sum_ms | 5357.262000 |
| p50_ms | 20.487000 |
| p95_ms | 61.463000 |
| max_ms | 132.380000 |

Proposed aggregate writer-hold p95 ceiling: 75 ms, provisional pending the requested 2–3 runner results and coordinator approval. This is 22.02% above this run’s 61.463 ms. Proposed calibration rule: round 1.20 times the largest p95 of the 2–3 runs upward to the next 5 ms. One run establishes no variance bound. Keep current source in Calibration mode until approved.

All existing hard per-verb max <200 ms, 100 ms read checks, and 5 s checks remain unchanged. This run fails the real list_tasks client-total check (958.409609 ms), independently of the expected unconfigured aggregate failure. #738 owns the product fix; this branch does not waive or fix it.

Writer per-method distributions:
| Method | count | p95 ms | max ms |
|---|---:|---:|---:|
| agent.deliver | 27 | 27.382 | 132.380 |
| agent.poll_status | 24 | 121.439 | 122.470 |
| entity.seen | 8 | 40.036 | 40.036 |
| mcp.control:comment_task | 24 | 29.304 | 30.240 |
| mcp.control:create_task | 24 | 87.869 | 119.345 |
| mcp.control:message_agent | 24 | 27.356 | 27.601 |
| mcp.control:move_task | 24 | 27.500 | 29.156 |
| mcp.control:post_thread_message | 24 | 14.981 | 16.569 |
| mcp.control:set_topic | 24 | 18.647 | 19.499 |
| tasks.delivery_service | 4 | 0.191 | 0.191 |
| thread.post | 8 | 122.739 | 122.739 |
| user.present | 8 | 1.952 | 1.952 |
