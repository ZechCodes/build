# Three-run calibration result

All runs used afd65d0829c51dff6889d61715c8e5b017a24867. All three debug jobs succeeded; all three release busy jobs failed. No failed run was replaced.

| Run | Writer frames | Pooled p95 ms | Maximum hold ms |
|---|---:|---:|---:|
| 39627704997 | 223 | 61.463 | 132.380 |
| 39630419837 | 222 | 76.387 | 128.802 |
| 39630431116 | 222 | 60.576 | 145.345 |

Approved formula gives **95 ms**: 1.20 ×76.387 =91.6644 ms, rounded upward to next5ms. Each pool contains exactly12 writer methods, excluding352 read frames. Source configuration is a separate action; aggregate calibration never waives hard read failures.

| Run | Read | Client max ms | Frame max ms | Pool wait max ms | App lock wait/hold max ms |
|---|---|---:|---:|---:|---|
| 39627704997 | mcp.control:list_tasks | 958.410 | 928.882 | 18.602 | 0.000/0.000 |
| 39630419837 | mcp.control:list_tasks | 1183.180 | 1143.669 | 9.777 | 0.000/0.000 |
| 39630419837 | mcp.control:list_task_dependents | 174.803 | 168.845 | 4.958 | 0.000/0.000 |
| 39630419837 | mcp.control:list_workspaces | 105.309 | 61.081 | 6.022 | 0.000/0.000 |
| 39630419837 | mcp.control:list_work | 132.963 | 130.220 | 9.682 | 0.000/0.000 |
| 39630419837 | mcp.control:search_conversation | 169.502 | 168.967 | 6.213 | 0.000/0.000 |
| 39630419837 | mcp.control:read_comment | 141.452 | 141.375 | 4.210 | 0.000/0.000 |
| 39630419837 | mcp.control:read_review | 174.181 | 174.087 | 8.154 | 0.000/0.000 |
| 39630431116 | mcp.control:list_tasks | 877.662 | 851.554 | 14.835 | 0.000/0.000 |
| 39630431116 | mcp.control:list_task_dependents | 218.092 | 215.732 | 11.586 | 0.000/0.000 |
| 39630431116 | mcp.control:search_conversation | 223.036 | 219.336 | 5.431 | 0.000/0.000 |

Different phase maxima may belong to different frames; this table does not subtract independent maxima or claim causal attribution. Every listed breach remains an actual <=100ms failure. Shared cause with list_tasks/#738 is unproven. No fixes or threshold relaxations for these read paths are included in #722.
