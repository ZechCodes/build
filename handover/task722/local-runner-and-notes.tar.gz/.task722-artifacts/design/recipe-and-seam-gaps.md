# Qualification recipe and seam gaps

This is implementation planning, not runtime coverage evidence. All98 semantic RPC methods need actual valid dispatch and a final-effect proof; the seven/eight staged controls establish no long-trial qualification. Candidate paths below include an exists flag in the JSON; missing paths are search leads, not claimed interfaces.

| Family | Methods needing recipe | Candidate production/test paths |
|---|---|---|
| agent | agent.add, agent.choose, agent.interrupt, agent.remove, agent.start | app/runtime/agents/endpoints.rs, app/runtime/sessions.rs, app/tests/runtime/agent_tabs.rs |
| branch | branch.dispatch, branch.finish | app/worktrees/dispatch.rs, app/workspaces/mod.rs, app/tests/workspaces.rs |
| bridge | bridge.check_update, bridge.install_update | app/updates.rs, update/, app/tests/updates.rs |
| capture | capture.answer, capture.cancel, capture.create, capture.reroute | app/captures/mod.rs, app/tests/routing/captures.rs |
| conversation | conversation.reset, conversation.settings, conversation.unwatch, conversation.watch | app/conversations/ |
| entity | entity.dismiss, entity.mute, entity.seen | app/board/attention.rs |
| fs | fs.createDirectory, fs.createFile, fs.mkdir, fs.uploadAbort, fs.uploadBegin, fs.uploadChunk, fs.uploadFinish, fs.write | app/fs.rs, app/fs/uploads.rs |
| git | git.checkout_ref, git.commit, git.discard, git.fetch, git.merge_abort, git.pull, git.push, git.stage, git.stash, git.stash_pop | app/git/mod.rs, app/git/deferred.rs, app/runtime/deferred.rs |
| harnesses | harnesses.refresh | app/harness_inventory.rs |
| project | project.add_source, project.create, project.delete, project.ensure_conversation, project.init_git, project.remove_source, project.set_compaction, project.set_isolation, project.set_remote, project.sync_source, project.update_source | app/projects/requests.rs, app/projects/source_update.rs, app/projects/base_sync.rs, app/projects/deletion.rs, app/tests/configuration/projects.rs |
| push | push.registerKey, push.revokeKey | app/push_keys.rs, app/tests/push_keys.rs |
| run | run.abandon, run.adopt, run.git_action, run.message, run.request_changes | app/runs/review.rs, app/runs/lifecycle.rs |
| settings | settings.set | app/config/settings.rs, app/config/compaction_wire.rs |
| tasks | tasks.assign, tasks.attach, tasks.close, tasks.comment, tasks.create, tasks.read_through, tasks.reopen, tasks.review.act, tasks.review.close, tasks.review.complete, tasks.review.merge, tasks.review.open, tasks.review.push, tasks.review.refresh, tasks.review.reopen, tasks.review.snapshot, tasks.review.update, tasks.unwatch, tasks.update, tasks.waiting_on.add, tasks.waiting_on.remove, tasks.watch | app/tracker/mod.rs, app/tracker/reviews.rs, app/tracker/reviews/, app/tests/reviews/, app/tracker/delivery_service.rs |
| term | term.close, term.create | app/runtime/terminals.rs, app/tests/runtime/terminals.rs, app/tests/runtime/terminal_lifecycle.rs |
| thread | thread.attach, thread.post | app/conversations/, app/tests/conversations/ |
| user | user.present | app/session_summaries.rs |
| workspace | workspace.add_directory, workspace.create, workspace.delete, workspace.ensure_conversation, workspace.finish, workspace.init_git, workspace.measure_sizes, workspace.reclaim, workspace.remove_directory, workspace.rename, workspace.retry, workspace.set_compaction, workspace.set_locked | app/workspaces/, app/runtime/lifecycle/runner.rs, app/tests/workspaces/ |

Separate ownership suggested: tracker/review recipes; project/workspace/run/branch lifecycle recipes; agent/conversation/provider/capture recipes; filesystem/upload/Git recipes; terminal/service/config/key recipes. Reuse the actual test helpers and wire handlers, retain scoped origin context, and provide success/final-effect verification rather than a list of metadata records.

The required common-path80/10/10 mix cannot be obtained by delaying an arbitrary dummy callback: real scope admission, native exclusion, execution and publication must remain present. OffLockGate alone can pause actual work but cannot guarantee safe finite Git/provider replacement. Direct synchronous fs.write currently needs an explicit injected service boundary or a deliberately under-lock finite service fixture; do not silently move its injected delay off the real path.

Optional remote notification delivery must have a precise exclusion policy; local publication is never excluded. Report SQL conservative upper, known-wait union, external wall envelope and external active time separately, without subtraction of unrelated intervals.
