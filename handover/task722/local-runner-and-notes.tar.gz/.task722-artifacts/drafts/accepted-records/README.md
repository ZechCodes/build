# Accepted record controls — off-source test-first draft

No tracked edits, builds, tests or runtime claims. The observer installation
method deliberately does nothing; accepted writes cannot fabricate evidence.

Proposed staging paths:

- `app/accepted_records.rs`: bounded witness schema and empty collector scaffold;
  expose with a cfg(test) module declaration in `app.rs`.
- `app/tests/runtime/write_wait_qualification/saved_records.rs` plus its four
  children here: expose from the existing qualification test root.

Actual control names:

- `saved_records::agents::concurrent_coding_topic_name_witnesses_bind_only_successful_installed_records`
- `saved_records::tasks::concurrent_task_writes_capture_changed_and_native_noop_records_per_original`

The first competes four actual Coding requests for two socket credits behind an
AppState holder, then injects one real store failure into a separate request.
It closes/joins every socket/server and encrypted receiver before demanding
each original's accepted snapshot. The second races two encrypted RPC updates
and two Coding move calls to one status, so exactly one real transition and
three status no-ops occur regardless of lock acquisition order.

Independent SQL checks use a Store clone captured in setup and execute without
an AppState guard. Native topic/name revisions are explicitly absent. Task
`updated_at` remains a native timestamp, never a synthetic monotonic revision.
The future opt-in observer belongs after successful persistence and actual
install, uses existing task write observations/disposition, and introduces no
SQL reads. It remains unimplemented until these controls show observed RED.

Fixture API: `SavedFixture::new(Arc<AcceptedRecords>)`; public `state`, `rpc`,
`owner`, `caller`, `token`, `store`, `project`, `task`.
`compete(Vec<SavedRequest>)` independently polls every offer and returns replies
in vector order. The held AppState is released only after every wrapper starts
and two actual MCP socket writes complete (or fewer if fewer MCP offers).
`mcp_exact(id,&action)` preserves native error envelopes as ReplyProof; transport
failures are Result errors. `finish(self)->Result<TempDir,String>` joins owned
transport, drops local state/plane handles, and bounds the wait for actual Weak
AppState ownership and original registry settlement. Keep the returned TempDir
result alive through post-cleanup SQL assertions. Any transport/cleanup fault or
unconfirmed drain preserves the private directory and returns its path, PID,
remaining AppState owners and unsettled originals; handler abort never proves
accepted blocking work completed.
