# Seen record reservation (offsource TESTFIRST contract)

This is a reservation for one narrow AcceptedRecord variant, not an observer
implementation or a new success rule. Global owns the actual encrypted-RPC test
package and attention save-result plumbing draft. Recipes owns the collector
extension after root source release. Existing topic/name/task tests do not cover
this hook: run the new native-wire controls to an intended missing-witness RED
before implementing it.

Proposed bounded type:

```rust
#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub(crate) struct SeenRecordWitness {
    pub original_ids: Vec<String>,
    pub owner: String,
    pub agent: String,
    pub conversation_owner: String,
    pub conversation_id: String,
    pub thread_id: String,
    pub generation_revision: u64,
    pub actual_reached_sequence: u64,
    pub saved_through_sequence: u64,
    pub published_through_sequence: u64,
    pub native_revision: Option<u64>,
}

// Existing AcceptedRecords::take continues to retain every record per original.
// Proposed enum addition: AcceptedRecord::Seen(SeenRecordWitness).
```

The native generation_revision belongs to the canonical thread; it is not a
revision of an attention save. native_revision must remain None. owner/agent
identify the addressed attention cursor, while conversation_owner/id identify
the resolved canonical thread used for its target. Keep those addresses distinct.

## Emission boundary and refusals

Only the actual entity.seen path can emit this variant. Generic touch/status/
attention publishers must not create Seen records merely because a WriteContext
is bound. Preserve the exact local result of conversation_last_sequences from
see_attention; neither the reply nor a later latest thread head can recover it.
The common fixture explicitly addresses one agent and supplies no window floor.
A no-target outcome or filtered unread-below-window target does not become zero:
it has no Seen success witness, and the backend must retain that proof gap.

After the native save returns success, confirm all of the following from values
already available under the original operation's guard:

- The addressed owner survives the exact `live` set passed to Store::save_attention.
  That Store transaction prunes the serialized map; a successful transaction alone
  does not prove a pruned owner's cursor was saved.
- saved_through_sequence comes from the same Attention record/map passed to that
  successful transaction, using the actual primary/legacy-cursor rule if needed.
  Do not substitute a later board cursor or add a SQL reload under AppState.
- published_through_sequence comes from the already accepted agent.list row for
  the same addressed owner/agent and canonical thread/generation. Do not force a
  refresh, synthesize a row or use a merely prepared candidate as installed proof.
- Both cursors cover actual_reached_sequence and are equal for this exact record.
  A no-op target below an existing cursor is valid if this native save succeeded;
  it does not get a fabricated sequence, event or revision.

A failed save, missing store, pruned owner, mismatched/missing accepted row, reset
refusal or absent target emits no successful Seen record. Keep existing reply
and failure-log semantics. The proposed private success return only exposes the
existing Store result; it must not reorder publication versus persistence or
change the production wire outcome.

The current collector retains exact original vectors and rejects duplicates at
consumption. Common Seen requires exactly one original and one Seen record. Keep
unknown/extra/late record diagnostics visible under the same archive contract as
Agent/Task. The separate backend extractor may turn this real record into
SavedEffect::Seen, but must validate the actual request owner/agent/thread_id/
conversation_id before doing so. It may not fabricate a Seen from later SQL or
published state.

## Focused controls owned by Global

- First actual seen, then later native message and later seen: retain the first
  original's target/cursors unchanged and independently verify native save/view.
- Actual old explicit target: the accepted cursor does not rewind, and no-op
  witness still records the actual old clamped target and None revision.
- Store failure while native RPC still replies Ok: no accepted Seen, persistent
  cursor remains unchanged, later unrelated persistence cannot rescue this origin.
- Invalid or reset address: actual refusal and no successful record.
- Actual other attention publisher: no Seen record under the shared collector.

Cleanup and provider safety follow the existing SavedFixture controls: retain
roots until RPC/socket/server work drains, fail and preserve temporary paths on
uncertain cleanup, and perform intended observer assertions after cleanup.

## Presence uses a separately tested narrow durability scalar

Root resolved this boundary after the initial Seen draft: preserve native
best-effort semantics. Global owns a focused TESTFIRST and exact offsource type
for original-specific Saved / SaveFailed / UnchangedNoSave outcomes. Reuse one
collector-owned durable UserSession scalar initialized from an actual Store load
off-lock during setup; update it only after actual successful native saves,
including non-user.present callers of note_user_activity. Capture prior durable
coverage and actual local/published session at each original execution.

A no-save result may rely on exact prior durable coverage; the conservative
consumer should require all three native UserSession fields to match rather than
comparing last_activity alone. A failed save is not successful evidence even if
a later original persists a newer row. Retain the earlier original's immutable
SaveFailed disposition. No guessed durability, forced new write, fabricated
native revision or SQL reload under AppState is authorized.

This Presence extension is separate from Seen and still needs its own observed
RED before implementation. There is no new generic event journal.
