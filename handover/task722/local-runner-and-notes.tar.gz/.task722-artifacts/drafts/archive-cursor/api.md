# Bounded append archive readers — OFFSOURCE TESTFIRST proposal

No source changes/build. Existing completed archives remain append-only for one finite trial; do not add compaction, a second ledger, or watchdog locking.

```
registry.completed_snapshots_cursor() -> CompletedSnapshotsCursor
registry.completed_intervals_cursor() -> CompletedIntervalsCursor
registry.completed_snapshots_since(&mut cursor, explicit_limit: usize)
    -> Result<Vec<WriteSnapshot>, ArchiveCursorError>
registry.completed_intervals_since(&mut cursor, explicit_limit: usize)
    -> Result<Vec<CompletedInterval>, ArchiveCursorError>
```

Cursor constructors start at zero, carry private Weak registry identity + next append offset, and are not Clone/Copy. Typed streams prevent accidental interchange. They do not hold a strong registry reference. Calls reject foreign registry, zero/oversized limit (MAX_ARCHIVE_BATCH=256) and offset beyond current append length before mutation; errors preserve cursor. A lagging cursor is VALID backlog and advances boundedly. No pruning exists, so there is no retention-based stale cursor. Non-Clone &mut cursors prevent safe-code reuse of old token copies; exact-once means the consumer uses one mutable cursor and only successfully returned rows advance it.

Under the existing collector lock clone at most explicit_limit consecutive NEW rows in native append order and advance offset to their end. Do not rescan/copy earlier rows, all origins or raw archives. Empty poll returns empty and keeps position; arrivals between polls appear in later calls. Limits above the fixed256-row maximum (including usize::MAX) reject without advancing; workload chooses an explicit finite cap. No default unbounded limit. Archive-only exports stay outside independent active watchdog path.

Scaffold will compile with real typed cursors/constructors/validation but returns empty batches, so append-order/chunk/arrival tests fail meaningfully. Implementation only after those REDs. Proposed controls: (1) snapshot completion order + limit2 over5 + live origin exclusion + repeated empty poll/newarrival; (2) raw interval CLOSE order + limit1 + coalesced shared origins stored once + laterclose; (3) foreign/future-offset/zero-limit reject without advancing and subsequent valid read works. Validate root/cancellation raw fields remain unchanged versus original final export where appropriate.
