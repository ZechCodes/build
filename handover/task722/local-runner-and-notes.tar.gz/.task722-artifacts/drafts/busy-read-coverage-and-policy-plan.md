# #722 scopes 4–7: busy read coverage and timing policy (DESIGN ONLY)

Baseline: clean build/qualify-722, main1f3516dce5b5522932a1611e661f9551ea645566. No source edits/build/test/runtime. No GitHub workflow dispatch. Coordinator will provide2–3real-runner calibration observations before an aggregate hold threshold is selected.

## Exact owned-file proposal

- `bridge/src/app/tests/runtime/lock_hold_busy.rs`: narrow fixture/read-worker/barrier/report/assertion wiring; preserve seed sizes,6existingMCPwriters,3RPCwriters,24actualstatus observations,24handoffs and drain proof.
- New `bridge/src/app/tests/runtime/lock_hold_busy/reads.rs`: typed14-tool cases, semantic fixture witnesses, endpoint selection and read-response checks. Split fixture seeding from requests if complexity grows; no ratchets.
- New `bridge/src/app/tests/runtime/lock_hold_busy/policy.rs` and child tests: complete cohort/latency/max/aggregate policy and synthetic failure controls.
- `bridge/src/timing/phase_samples.rs`: cfgtest-only atomic summary+raw-frame-held capture and exact sample tests. Keep existing production timers/endpoints unchanged.
- A tiny cfgtest-only classifier/registry seam in `app/mcp.rs`/`app/mcp/read_lane.rs` may be needed so coverage tests compare actual supported read actions rather than a second disconnected list. Coordinate this with the MCP registry owner before editing. Prefer one explicit typed read registry feeding workload and count/budget assertions; never classify arbitrary actions by tool-name prefix.
- No `.github/workflows/timing.yml` trigger or ceiling edit in this scope. Coordinator owns workflow/calibration integration; existing release build-before-run policy stays.

## Current behavior / intended difference

Current Busy has seven MCP labels: six writer actions plus get_task. Each has24actualparsed replies. Five RPC labels have8each, status24. Current client cohort is232including status; MCPread100ms budget checks get_task only. Per-label frame-held policy combines p95<50 and max<200 in one assertion, so the first p95 failure obscures later labels. PhaseSamples stores raw values internally but snapshot exposes sorted summaries only.

Proposed MCP cohort is6writers +14reads =20labels,24each (480MCP replies), plus40RPC replies +24status completions =544client/status samples. Read100ms cohort has14*24MCP +2*8RPC =352samples. Preserve per-request socket-write→parsed-reply and encrypted-submit→decrypted-exact-ID endpoints. Do not count a fast error as a successful read, and do not suppress slow results. Report the expanded cohort explicitly: it is not comparable as an unchanged workload to #709.

Keep existing seven-action order and acknowledged-topic/history checks; place the13additional reads at a documented stable point each round or in separately synchronized readers. Choose the schedule once before calibration and retain it identically thereafter. Parallel read workers improve overlap proof but change barrier shape; exact participant counts must be tested. Do not silently add reads only after writers drain. A dedicated read actor per original coding agent can issue its eleven coding/project-capable reads and three router reads through one stable router identity while writer/status/RPC actors are active. Router identity switching is per-frame, so no native router process is required.

## Semantic read matrix

Use typed BridgeAction values and their actual tool_name labels. All callers authenticate through real ControlPlane/UnixStream framing, no direct helper timing.

| tool | authenticated endpoint / valid params | nonvacuous successful result witness |
|---|---|---|
| get_task | coding/project; existing task_id | exact task ID/project |
| list_tasks | coding/project; state/status/label None | known seeded task ID in returned tasks |
| list_task_dependents | coding/project; stable seeded task; limit Some(1), cursor None | seed one native dependency between two existing otherwise idle tasks; dependent ID present |
| list_harnesses | coding/project; no params | real catalogue shape and known provider; no unknown-tool/error shortcut |
| list_workspace_agents | coding/project; existing workspace e.g. owners[1] (not seed adopted owner unless verified alias exists) | exact workspace ID and expected canonical agent binding |
| list_project_agents | coding/project; no params | exact current project ID and actual accepted selected roster (empty is legitimate if no project owner; do not mint201st conversation merely for this test) |
| list_workspaces | coding/project; no params | current project workspaces and one seeded workspace ID, no foreign scope |
| list_projects | real router; no params | known project ID |
| list_work | real router; no params | known work/task ID; capture rows excluded by normal adapter |
| search_conversation | coding/project; ConversationQuery.text Some("Busy request 0:"), defaults otherwise | seeded32-item history hit with original body/identity; no extra history item required |
| read_conversation | real router; entity_id/agent_id of current coding actor, limit300 | original seeded transcript body retained despite later posts |
| read_comment | coding/project; immutable native comment ID seeded before timing | exact stored body/ID; concurrent comment writers do not overwrite this row |
| get_review | coding/project; real saved review task ID | saved snapshot/review ID |
| read_review | coding/project; real saved snapshot_id + directory_id, Blob, existing committed text path, paths[], patchfalse, range offset0/bytes4/rawNone | exact known blob prefix and valid source identity; never use rawSome(true) for a text file |

Current Busy seeds eight reviews with directories[]. That is valid for RPC get metadata but NOT for read_review. Seed an additional real native review snapshot against an existing linked workspace and an existing committed blob before timing; record actual IDs/expected bytes. Keep existing8RPCreviewtask IDs to preserve distinct reads unless coordinator explicitly chooses a new cohort. No direct fabricated unavailable ReviewDirectory and no timing of a refusal. Read comment/dependency rows use existing700tasks (no count inflation) and persist before warming.

Create one real router endpoint through the normal capture/router producer BEFORE app.shared starts background services, install its typed capability through AppState test helper, clear its fixture-only queued launch before sharing, and publish its accepted metadata with the ordinary warm. No provider process or extra warm tab. Existing twelve exact warm sessions remain the session-liveness cohort. Document the additional passive capture/router row; verify it is not consumed/abandoned by background delivery and token stays current throughout. Avoid the previously invalid pattern of queuing a fake router after app.shared and masking revocation by reinstalling its token.

RPC git.show: preserve real existing run_id/hash/max_bytes variation and assert returned commit/blob content shape. RPC tasks.review.get: preserve eight real saved task IDs and assert review object. Extend100ms client.total hard max to BOTH, not just frame/handler time. Keep all5s whole-cohort lock-wait, queue+permit+lock, frame-total and client/status-total gates unchanged.

## Registry/coverage TDD

Proposed first tests compile against current APIs and fail for real missing coverage, not missing new types:

1. Compare expected_request_samples/tool-labelled cases against explicit14actualread actions; current workload includes only get_task, so missing13names is intendedRED. Check unique action/tag/tool labels and exactly24samples each.
2. For every typed read case, verify actual scheduler classification as independent, correct allowed surface and real successful response shape with actual fixture IDs. Preserve DoneReport priority, malformed and wrapped-action negative controls. Existing focused guardfree groups cover the14variants; registry prevents future workload drift.
3. Inject one101ms client sample for EACH of13additionalMCPreads and bothRPCreads into otherwise valid synthetic measurements; current get_task-only helper wrongly accepts, intendedRED. Require100ms exact boundary pass and100+epsilon fail. Also test missing count/missing client sample/fast error is not accepted as coverage.
4. Seeded snapshot read produces actual saved blob bytes, seeded comment body, dependency edge and search/transcript witness; positive fixture controls before ignored timing qualification. No frozen full reply equality during concurrent mutation; assert immutable IDs/content invariants and use focused no-load legacy parity where exact reply comparison is meaningful.

## Per-label and aggregate hold policy

Separate assertions: every completed labelled frame's `frame.held.max_ms` must be finite, nonnegative and strictly<200ms. Retain each verb's p95 in report, with pass/fail diagnostics against historical50ms if useful, but remove it as an independent per-verb hard failure. Other5s/100ms hard gates remain independent and cannot be weakened by the hold policy change. Collect all violated hard constraints before asserting so one label does not hide others.

Aggregate writer p95 MUST pool actual raw per-frame held samples, not average or weight per-label percentile values. Explicit writer registry: six existing MCPwrite labels; RPCentity.seen/thread.post/user.present; agent.poll_status; agent.deliver; tasks.delivery_service. Do NOT include14read zero-hold frames or git.show/tasks.review.get; those would dilute the distribution. Include actual variable internal delivery/service counts and report them. Unknown captured labels should require explicit classification rather than silently disappearing.

Freeze summary and raw held vectors from the SAME clone under PhaseSamples' measurements mutex at the proven idle cut. Do not separately read raw values after summary capture; a periodic frame could create mismatched populations. Put raw writer data under a top-level report field, not inside measurements where overall_max_frame_sample assumes every key is a method. Report method→rawvector, total writer count, quantile method (nearest rank ceil(.95*N)-1), calculated aggregate p95 and eventual configured limit. Preserve all finite/nonnegative/count checks. Read samples remain in ordinary complete measurement summaries.

Coordinator calibration decides the aggregate limit from2–3real-runner observations. Do not guess a new ceiling, infer it from one workstation run or activate an unreviewed environment override. Until chosen, implement/test the raw estimator and explicit limit-taking policy with synthetic values; final gate constant/wiring follows coordinator decision. Keep per-label200ms and5s/100ms gates active throughout calibration.

Synthetic aggregate TDD: construct distributions whose pooled p95 differs from average/maximum of label p95s; assert exact nearest-rank value and raw count; reject a configured-limit breach; retain equality/strictness as explicitly approved; reject NaN/infinite/negative/missing/duplicated samples; prove adding many readzero frames cannot alter writer p95; prove a sparse label p95>50 with max<200 is report-only when aggregate passes. Preserve samples for every failed run and no retries/threshold ratchets.

## Verification / coordination

No source/runtime authorized yet. Root chooses exact seam/ownership and releases TESTONLY first, then one shared build and meaningful REDs; implementation only after actual failure. Existing guardfree14/read auth/reset/cancellation/SQL-release controls remain. Later isolated release busy qualification uses actualNI10, no concurrent compiler, fixed run count, full endpoint counts and raw results. Coordinator dispatches real-runner calibration; this agent never triggers GitHub.
