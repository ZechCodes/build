# Concrete common recipe map

This is an implementation contract, not passing execution evidence. Initial fixture history and independent-watch controls remain TESTFIRST.

The immutable40/s slot list is authoritative. Before dispatch, each recipe carries the original ID, exact intended due time, typed surface, real target IDs and an effect oracle. No overload/refusal/no-op substitute satisfies successful coverage.

## State slots

The8 SPA state slots/second cycle actual `thread.post`, `entity.seen`, `user.present`, `tasks.comment`, `tasks.update`. Each targets its scheduled active owner; the every-tenth-second burst targets owner0 across all four SPA openings. `thread.post` includes the original ID as operation_id and a bounded unique body; task state alternates backlog/in_progress on the first ordinary task in the target project. Comments retain the returned comment ID/body. Reserved last-two read-witness tasks in each project are excluded from write target selection. Effects are checked after actual final response against canonical thread/operation, stored comment/task, session state, or published seen marker as appropriate.

The24 MCP state slots/second cycle actual typed `SetTopic`, `SetName`, `TrackerMoveTask`, `TrackerCommentTask`, `PostThreadMessage`, `MessageAgent`. Each of the eight retained Coding identities stays in its actual project/workspace scope. Handoffs address the other active sibling in the SAME project. Unique bounded bodies/topics/names preserve per-original evidence; recipient SessionLog records and mandatory delivery obligations are joined. Additional rare recipes cover remaining mutating actions and reports; these six do not claim43-action coverage.

The concrete predecessor map is built once from actual scheduled due order. Same-owner state chains retain the prior original, including eight-write bursts. Caller semantic credits never exceed2 and refuse no intended slot. Credits and predecessor waits remain in caller latency; actual server logical waits retain separate intake endpoints.

## Filesystem slots

The4 real `fs.write` slots/second target `qualified-editor.txt` in their scheduled active roots. One original owns one filesystem service plan selected by ID, with targets10/25/50/150ms and actual ceiling250ms. No extra preparation write is issued per operation. Seed body is known; expected_revision is SHA256 of the previous SUCCESSFULLY verified body in that root's immutable predecessor chain. Each new body contains its exact original ID and remains bounded. Returned revision/size and actual resulting file bytes must agree. A stale revision/refusal fails; no reread/retry masks it.

The chain is per root, not merely per caller: a root is revisited every other second. Exact-ID finite service target, operation-before-padding, effect+padding wall time, actual frame full AppState hold and result are paired. Surrounding scope resolution/publication/final read stay in the full hold. All8 filesystem mutation verbs remain known guarded operations; this harness does not repair that limit.

## Git slots

Avoid a per-request synthetic file preparation and avoid shared `refs/stash` across linked worktrees. Before timing, create two UNIQUE local branch refs per active root, both pointing to the existing initial commit. Common writes alternate actual `git.checkout_ref` between that root's two branches under a per-root predecessor chain; no other root uses those refs. Every operation verifies the actual symbolic HEAD changed to its exact requested full_ref, with original commit identity retained. This creates16 declared local refs, zero additional workspaces/tasks/history items. Current working edits survive because the branches share their base tree; an actual checkout failure is retained, never replaced.

Targets25/50/100/475ms and actual ceiling500ms apply at the real scoped Git work boundary after production source exclusion/preflight. Source/checkout/ref guards, wait time and publication remain real. The stable inactive read workspace is never checked out or edited by common writers.

## Other traffic and proofs

Read cases come from the real45 RPC/14 MCP builders and scope-specific native witnesses. Four project metadata owners and one passive Router are explicitly counted; only the eight Coding identities write. All live Coding reads/writes share TWO sockets per identity, while each semantic caller also has its separate2-write cap. Router has two read-only sockets; SPA openings have eight separate read credits.

All143000 intended client IDs are registered before the acknowledged watchdog setup barrier. T0 is published once afterward. Timers start at intended due time BEFORE credit/socket/predecessor waits. The last Git call can finish after600s; offered-window and drained-final counts are reported separately with the unchanged600s rate denominator.

The100/s exempt mix uses actual terminal input/ack, subscriptions and ping against seeded private fake terminal/session and real subscription maps. Four actual background producers have separately reported initiations/completions, and BackgroundWork origins where needed for autonomous wait coverage. No background operation increments the24000 semantic client denominator.

Full decoded read results are immediately verified by strong native oracles. Retain lossless timing/counts/all slow IDs, bounded witnesses and precisely labelled reserialized-decoded-JSON size/hash, plus full failures/one example per case. This avoids retaining all maximum-valid read bodies in memory without reducing requested, encoded, transferred or parsed work.
