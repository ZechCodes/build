# Common long-workload integration draft (off-source)

No compiled or executed evidence. Initial eight test-first sources stay frozen.

## Fixture and cardinality

`FixtureEnvelope::{Small,Large}` describes TOTAL residents over four projects:

| | Tasks/project | Workspaces/project | Total thread items | Active workspaces |
|---|---|---|---:|---:|
| Small | 25/25/25/25 | 3/3/2/2 | 1000 | 8 (two/project) |
| Large | 2500/2500/2500/2500 | 50/50/50/50 | 100000 | 8 (two/project) |

Build a fresh temporary root/WAL Store and four locally configured Git repos per trial. Seed a template task using the real task handler once/project, clone its persisted typed record with fresh IDs and write through `Store::create_tracker_task` (number allocation retained), rather than rebuilding all publication graphs for every seed row. Construct real resident worktrees using libgit2 + WorkspaceRegistry adoption and persisted `ActiveRun` records, as the existing busy setup does. Create eight active canonical conversations and fake `AgentSession`s, correct recorded lineage and unique issued tokens. Histories distributed over resident conversations with already-consumed user prompts; no accidental historical delivery debt. Initial canonical/project/store counts and resident/item counts are asserted before timing. Warm ordinary projections and listener-captured services once, then install the optional logical-write registry. No live homes, sockets, providers or updater.

`QualificationFixture` must retain temp roots, repo fixtures and all fake session handles until producers, admitted operations, deferred queues and registry obligations drain. Fail startup rather than silently reducing resident cardinality or accepting a fake spawn fallback.

## Shared driver contract

`execute_rpc(caller, original_id, method, params) -> ReplyProof` uses one of four encrypted SPA-role `ChannelWire`s, the actual `FrameIntake`, exact string request ID and decrypted final response. One receiver task per wire demultiplexes accepted receipts/final replies/pushes into per-ID oneshots; duplicate/unknown final IDs are errors. The caller timer begins before sender-credit waiting; server wait begins at actual carrier intake. `accepted:true` is an admission receipt, never confirmation or completion.

`execute_mcp(caller, original_id, action) -> ReplyProof` uses one of eight authenticated agent identities and actual `ControlPlane`/`handle_done_stream`. Use fresh one-request duplex sockets per action, with at most two sockets concurrently per logical session (one outstanding request each). This matches the shipped client connection model and does not claim persistent pipelined server coverage. Tokens/generations match retained fake tabs; `session_locator_factory` rejects any unplanned launch. The new attribution hook must carry original IDs through MCP frame intake without introducing unsupported action parameters. Server complete-frame arrival and encoded reply flush are distinct endpoints from caller submission.

`ReplyProof` retains original ID, actual method/action, intended due time, offered time, caller-credit release/start, wire submit, admitted/ack timestamps if observed, parsed reply time, result bytes and registry WriteId. A valid common operation also has an actual effect assertion. SQL-only reads use published/saved read service results for verification instead of app-lock reads. Mere response metadata is not proof.

Rare recipes can reuse fixture handles and the exact same RPC/MCP driver. Their finite scripts are separate cohorts and must implement actual dispatch and final effect verification, not a metadata registration. They are not added to the40/s denominator. Destructive/replacement cases get disposable sibling context and explicit dependent chains.

## Scheduler and rates

Generate deterministic immutable IDs before launch. Each600-second trial has24000 intended semantic slots:32 bounded state,4 filesystem/process,4 Git/provider per actual timestamp second. An eight-write owner0 burst uses8 of those slots at a declared timestamp, assigned at most2/caller; it adds no traffic. Other slots rotate sibling owners/projects and carry predecessor IDs where necessary. Offer time is independent of credits; no closed-loop rate relabeling.

Maintain one pending FIFO per caller and exactly2 outstanding semantic credits per caller. Each scheduled offer is recorded even when credit-blocked. On completion, dispatch that caller's oldest eligible predecessor-satisfied offer. Report intended, actually offered, wire-submitted, admitted, durable-acknowledged, confirmed/completed, pending-unsubmitted and still-admitted counts/rates separately. An offered slot cannot vanish or become a successful write because credits were exhausted. At end600s stop generating offers, then fully drain admitted bounded work and all pending intents; if sustained40/s was not admitted/completed, qualification fails even when completed-request histograms look fast. Do not reset timestamps when a predecessor or queue changes.

State family rotation should use existing real tracker/topic/comment/message/attention/session methods with bounded64-256-byte payloads and alternating values so no-op updates do not dominate. Actual filesystem/process and Git/provider jobs must use reviewed finite external-execution injection at their production service boundary, retaining real captured owner/resource admission, commit and publication. Own injected active work is reported separately from waits behind another write. Per-second declared finite service targets are FS/process[10,25,50,150] ms and Git/provider[25,50,100,475] ms, selected by registered original ID rather than execution order. Actual hard service ceilings remain250/500 ms, with100 ms FS /25 ms Git margin near the ceilings. Run the actual effect first, then pad only the remaining target. Target and actual service duration are separate; any observed ceiling overrun fails and is never clamped or retried. The ceilings are declared maximum services, not permission to hide excess actual execution or to place the delay on an unrelated dummy route.

## Other traffic

Four actual independent producer tasks: status observations, delivery consumption, source/Git refresh completion, watcher/observation publication. Each has a declared period, actual started/completed counts, bounded fake external execution and joined shutdown. The source and watcher APIs/injection handles must be provided by production-hook owners; a timer incrementing a counter is not a producer.

Concurrent read plan covers the authoritative deployed RPC read registry and fourteen MCP read actions using reused actual builders. Require >=1000 actual completed requests/method/scenario/run where the full read gate applies. Legacy full/pending responses remain separate cohorts; they cannot become ready-value evidence. Eight outstanding reads/opening across the four SPA-role clients is a separate bound from two semantic write credits. Caller/server result timing, errors, cancelled, pending/legacy classifications and every >100ms sample are retained. This is server-side encrypted fake-carrier §8 workload; it does not certify actual browser negotiation/credit/cache dispatch for later step9.

Offer exactly60000 exempt frames/trial (100/actual second), with declared terminal input/ack, subscription controls and ping/other explicit control mix. Use real fake-terminal screen/session and actual subscription maps. They are separate from semantic counters and never mask under-delivery of40 semantic writes/s.

## Registry, watchdog and endpoints

Use `timing::write_wait::WriteWaitRegistry`: original logical ID at actual intake, child/coalesced obligations through nested/deferred/delivery execution, explicit wait interval guards and sync-only context binding inside each real blocking closure. The independent std watchdog checks immutable active rows every10ms and latches a >5000ms interval or cumulative blocked violation without app/collector/writer acquisition. Maintain all open IDs; completed histograms alone never pass an overdue outstanding write. Independently monitor client pending IDs from their original due/offer timestamps, including local credit/stream wait before server registration. A>5s pending caller or completed send-to-final encoded response>5s fails, even if no server registry row appeared. Retain offered/sent/server-intake times separately; never reset on credit release.

Report known-wait union, union(known waits + SQL service), conservative sum upper, SQL service union, own-external wall envelope and exclusive active external time separately. If known-wait or actual union violates5s, fail. Conservative upper must also fit5s; if SQL service is the sole cause, stop and ask coordinator rather than loosening the rule. Do not sum overlapping frame metrics or subtract independent maxima. Local publication and nested mandatory delivery are part of completion. Optional remote notices can be excluded only under the separately reviewed explicit policy, counted and timed independently.

## Fixed execution and failure

Six named ignored tests: small_trial_1/2/3 then large_trial_1/2/3, each exactly600s of offered supported load under verifiedNI10; one separate artifact per invocation. Build first, freeze exact source/profile, finish all other gates, then root fresh quiet release. No concurrent compilers/gates, no successful-only selection and no failed-trial replacement. Run all scheduled supported trials unless a safety/infrastructure failure makes continuation invalid; retain reason and all attempted/not-attempted entries. An actual supported-budget failure remains a failed result, not a rerun trigger.

On watchdog failure: stop offering new work, record every pending intent and active obligation immediately, retain accepted recovery obligations and drain finite admitted execution for bounded cleanup. Do not cancel an accepted write at5s to turn it into a success. Hung fixture/provider is an explicit failure with outstanding IDs; an outer harness watchdog may terminate only its own verified PID tree after preserving state. No failure is repaired by repeating a command.

Emit incremental compact progress from registry/atomic counters outside app/collector locks. Final raw per-original trace includes intervals, method, mix, payload bounds, all lifecycle milestones and outcomes; summary includes offered/admitted/completed rates, all p50/p95/p99/max, maximum individual/cumulative waits, all violations and remaining IDs. Existing PhaseSamples may be diagnostic but not the authoritative wait union or p99/all-caller endpoint recorder.

Fault/rare suites are separate from the six supported trials:10× burst with <=100ms pre-acceptance busy delivery, deliberately stalled service,6s exclusion before and after ack, cancellation/replacement/failed save/recovery; every accepted root/child remains observable through completion. Existing pure core/scheduler tests are prerequisites, not substitutes for these actual-path controls.

## Current assembly corrections (2026-10-21)

The current frozen source is9c8a21fdc; its178-focused stage has not established all new controls GREEN. The full independent watcher/coordinator/adapter implementations remain off source. No six-trial qualification has started.

The resident envelope INCLUDES four primary checkouts. Native primary evidence checks real Git workdirs and matching actual registry IDs; small=4primary+6linked, large=4primary+196linked. Four private bare local origins and16 active-root branch refs are separately declared fixture support. Full45 read setup adds one explicitly nonresident support Git checkout; registry counts must remain exact after real read/scope operations too, never only before adoption can run.

Four scope-specific project metadata owners (watched:false), two supplemental legacy plan records, one passive authenticated Router, zero extra authenticated Project endpoints, one stable read shell and one separate exempt-traffic shell are explicit ledger categories. Shells/Router add no canonical history. ALL native run/plan canonical histories (aliases deduped with agreement checks) share the1000/100000 global item budget. Global's read seed reserves8 searchable tail messages INSIDE that total: fill target−8, append one consumed message/active owner, archive the existing inactive owner without checkout deletion, then verify the exact total. Finalize asserts no canonical-item increase.

The complete relative client schedule has143000 originals/trial, not149000:24000 semantic +59000 reads +60000 exempt. Register all identities/offsets before acknowledged watcher setup, then publish T0 once. Eight Coding identities share TWO fresh sockets each across reads AND writes; semantic credits remain a separate2/caller cap. Additional Router has2read-only sockets. Intended timing precedes any local credit/socket/predecessor wait. No cross-caller predecessor chain may collapse the genuine8sameowner burst; use immutable event/version or exact message evidence rather than serializing to make latest-value assertions reliable. Two ordinary existing task rows/project can be assigned by active owner; last2project task rows remain read witnesses. FS and Git have separate necessary per-root chains, no artificial crossclass serialization.

Actual sent and parsed/decrypted-final timestamps, registry intake/admission/ack and completed-frame durations suffice; server encoded-final observations are optional. Client5s ends at actual decoded-final, not later oracle/drain work. Post-ack mandatory work retains its logical wait/obligation meter. Long ready reads require per-method/scenario p99≤100ms and≥1000 successes, retaining every slow sample; the short busy and controlled isolation maximum100ms gates are unchanged and separate.

Read bodies are fully requested, transferred, parsed and strongly verified. Retain bounded typed witnesses plus precisely labelled reserialized-decoded-JSON size/hash, full failures and one example/case; lossless timing/count/slow-ID evidence remains. No promise that this digest is original encrypted wire bytes.

Only actual typed optional-notice invocations with same-origin local-publication proof can use the optional5s cohort. Full frame/hold samples remain unchanged and optional rows add no semantic throughput. All other notices/children remain Required. Common CompleteReminder enrollment is empty; potential tracker-notice IDs are computed from actual task-write recipes and may yield zero real notices.

Separate BackgroundWork origins begin at actual producer invocations and do not increment24000 client writes. Status guard inheritance is explicitly TESTFIRST. File observation producer uses real reconcile+file update+actual note_files under its background context; native notify callbacks remain additional unassociated background activity, with no claim of cross-thread origin propagation.

Active finite-service checks use ONLY FiniteService categories and the EXACT sampled_at returned with immutable registry snapshots, never a later now. FS targets10/25/50/150ms and Git25/50/100/475ms are targets, not bounds; actual ceilings250/500ms remain strict. Same-ID reports retain operation-before-padding, complete finite envelope and full AppState hold. Eight filesystem mutation verbs remain guarded; this harness does not fix that limitation.
