#[cfg(unix)]
mod read_lane;
#[cfg(unix)]
mod reply;

use crate::app::{
    apply_thread_action, off_the_workers, AppState, DeferredJob, DeferredNext, DeliveryRunner,
    SessionRegistry,
};
use crate::mcp::{BridgeAction, DoneReport};
use crate::store::now_rfc3339;
use crate::timing::{FrameClock, FrameTimer, WaitTimer};
use serde_json::{json, Value};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::io::AsyncBufReadExt;

/// Who is on the other end of an authenticated MCP control frame.
///
/// The kind decides the tool surface, and it is read off the identity the frame
/// authenticated with — never off the frame's own claim about itself.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(in crate::app) enum AddressedSession {
    /// An agent working a plan or a run.
    Coding(McpConversationGeneration),
    /// A router deciding where one capture goes.
    Router {
        capture_id: String,
        agent_id: String,
    },
}

/// The conversation generation authenticated before a writer frame waits for
/// its mutation lock. Never retarget it after crossing an async boundary.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(in crate::app) struct McpConversationGeneration {
    pub entity_id: String,
    pub agent_id: String,
    pub thread_id: String,
}

impl McpConversationGeneration {
    pub(in crate::app) fn guard(&self, state: &AppState) -> Result<(), String> {
        let address = state.resolve_conversation_address(&self.entity_id, Some(&self.agent_id))?;
        state.guard_mutation_thread_id(&address, Some(&Value::String(self.thread_id.clone())))
    }
}

/// What a frame off the daemon's control socket — an agent's `done` report or
/// one of its MCP actions — is timed under. It is not a relay method, so it
/// gets a name of its own rather than borrowing one from the wire.
pub(in crate::app) const MCP_CONTROL_METHOD: &str = "mcp.control";

/// How many mutation/report frames may enter the control plane's writer lane.
///
/// The remaining writers wait asynchronously instead of parking a dozen
/// blocking threads at the app mutex. Explicit read adapters bypass these
/// permits and use the once-captured immutable read service for admission,
/// query work and final fences, without acquiring the app mutex.
pub(in crate::app) const CONTROL_FRAMES_AT_THE_LOCK: usize = 2;

#[cfg(all(test, unix))]
pub(in crate::app) fn is_independent_read(frame: &Value) -> bool {
    read_lane::action(frame).is_some()
}

#[cfg(all(test, unix))]
pub(in crate::app) fn probe_guarded_mcp_read(
    state: &Arc<Mutex<AppState>>,
    frame: &Value,
    before_final: impl FnOnce(),
) -> (Value, usize) {
    read_lane::probe_guarded_read(state, frame, before_final)
}

#[cfg(all(test, unix))]
pub(in crate::app) fn probe_guarded_mcp_executables(
    state: &Arc<Mutex<AppState>>,
    frame: &Value,
) -> (Value, usize) {
    read_lane::probe_guarded_executables(state, frame)
}

/// The arrival clock shared by every control stream and the bounded mutation
/// turns used by writers and completion reports.
pub(in crate::app) struct ControlPlane {
    clock: Arc<FrameClock>,
    turns: Arc<tokio::sync::Semaphore>,
    #[cfg(unix)]
    reads: Arc<read_lane::service::McpReadService>,
    #[cfg(test)]
    at_the_lock: std::sync::atomic::AtomicUsize,
    #[cfg(test)]
    most_at_the_lock: std::sync::atomic::AtomicUsize,
}

impl ControlPlane {
    pub(in crate::app) fn new(app: &AppState) -> Arc<ControlPlane> {
        Arc::new(ControlPlane {
            clock: Arc::clone(&app.frame_clock),
            #[cfg(unix)]
            reads: read_lane::service::McpReadService::capture(app),
            turns: Arc::new(tokio::sync::Semaphore::new(CONTROL_FRAMES_AT_THE_LOCK)),
            #[cfg(test)]
            at_the_lock: Default::default(),
            #[cfg(test)]
            most_at_the_lock: Default::default(),
        })
    }

    /// Route exact supported reads independently; other frames take a writer
    /// turn. The arrival timer includes permit, pool and app-lock waits.
    #[cfg(all(test, unix))]
    async fn answer(self: &Arc<Self>, state: Arc<Mutex<AppState>>, frame: Value) -> Option<Value> {
        self.answer_since(state, frame, WaitTimer::start()).await
    }

    #[cfg(unix)]
    async fn answer_since(
        self: &Arc<Self>,
        state: Arc<Mutex<AppState>>,
        frame: Value,
        arrived: WaitTimer,
    ) -> Option<Value> {
        let timer = self
            .clock
            .queued_since(crate::timing::Priority::Foreground, arrived)
            .start(MCP_CONTROL_METHOD);
        if let Some(action) = read_lane::action(&frame) {
            return Some(read_lane::answer(Arc::clone(&self.reads), frame, action, timer).await);
        }
        let turn = Turn::take(self, &timer).await;
        answer_off_the_workers(state, frame, timer, turn).await
    }

    /// The most writer/report frames admitted to the mutation lane at once.
    #[cfg(test)]
    pub(in crate::app) fn most_at_the_lock(&self) -> usize {
        self.most_at_the_lock
            .load(std::sync::atomic::Ordering::SeqCst)
    }
}

/// One mutation/report frame's turn in the bounded writer lane.
///
/// Held while the frame is at the lock, and given back while it waits on the
/// git it handed back: that git runs with the guard released, and a turn kept
/// through it would let two slow workspace operations stand every other
/// agent's frame in line with the mutex free. The frame takes a turn again
/// before it writes the git's outcome down. Its connection reads nothing more
/// until it is answered, so one agent's frames still land in the order sent.
pub(in crate::app) struct Turn {
    plane: Arc<ControlPlane>,
    permit: Option<tokio::sync::OwnedSemaphorePermit>,
}

impl Turn {
    pub(in crate::app) async fn take(plane: &Arc<ControlPlane>, timer: &FrameTimer) -> Turn {
        let mut turn = Turn {
            plane: Arc::clone(plane),
            permit: None,
        };
        turn.take_again(timer).await;
        turn
    }

    /// Give the turn back for as long as `work` runs, and wait for another
    /// after it.
    pub(in crate::app) async fn aside<T>(
        &mut self,
        timer: &FrameTimer,
        work: impl std::future::Future<Output = T>,
    ) -> T {
        self.give_back();
        let done = work.await;
        self.take_again(timer).await;
        done
    }

    async fn take_again(&mut self, timer: &FrameTimer) {
        let waiting = WaitTimer::start();
        #[cfg(test)]
        let logical_wait = timer.write_wait(crate::timing::write_wait::WaitKind::Permit);
        let permit = Arc::clone(&self.plane.turns)
            .acquire_owned()
            .await
            .expect("the control plane's turns are never closed");
        timer.record_permit_wait(waiting.elapsed());
        #[cfg(test)]
        drop(logical_wait);
        #[cfg(test)]
        {
            use std::sync::atomic::Ordering::SeqCst;
            let now = self.plane.at_the_lock.fetch_add(1, SeqCst) + 1;
            self.plane.most_at_the_lock.fetch_max(now, SeqCst);
        }
        self.permit = Some(permit);
    }

    fn give_back(&mut self) {
        if let Some(permit) = self.permit.take() {
            // Counted out while the permit is still held: dropped first, a
            // waiter it wakes could count itself in before this one left.
            #[cfg(test)]
            self.plane
                .at_the_lock
                .fetch_sub(1, std::sync::atomic::Ordering::SeqCst);
            drop(permit);
        }
    }
}

impl Drop for Turn {
    fn drop(&mut self) {
        self.give_back();
    }
}

/// Resolve a control frame only when it carries the current per-session
/// capability, returning the AGENT that sent it. The token is never included in
/// errors or logs.
///
/// `task_id` is the legacy spelling of the identity baked into the harness's
/// argv; that identity is the agent now, and the entity behind it is a lookup
/// away.
pub(in crate::app) fn authenticated_mcp_owner<'a>(
    frame: &'a Value,
    sessions: &SessionRegistry,
) -> Option<&'a str> {
    let owner = frame.get("task_id")?.as_str()?;
    let supplied = frame.get("session_token")?.as_str()?;
    sessions.token_matches(owner, supplied).then_some(owner)
}

#[cfg(unix)]
/// Run the git a socket line handed back — with the guard released and the
/// frame's turn given back, on a blocking thread so several harnesses at once
/// park no runtime worker — and write it down under the same timer. The
/// socket's twin of the drain in [`dispatch_frame`], for a router's tool and a
/// coding agent's report alike.
pub(in crate::app) async fn apply_off_the_socket(
    state: &Arc<Mutex<AppState>>,
    timer: &FrameTimer,
    turn: &mut Turn,
    mut deferred: DeferredJob,
) -> Result<Value, String> {
    loop {
        let waiting = WaitTimer::start();
        #[cfg(test)]
        let logical_wait = deferred.blocking_wait();
        let (done, pool_wait) = turn
            .aside(
                timer,
                tokio::task::spawn_blocking(move || {
                    let waited = waiting.elapsed();
                    #[cfg(test)]
                    drop(logical_wait);
                    (deferred.run(), waited)
                }),
            )
            .await
            .expect("the lifecycle job panicked");
        timer.record_pool_wait(pool_wait);
        match timer
            .lock(state)
            .apply_deferred_stage(MCP_CONTROL_METHOD, &Value::Null, done)
        {
            DeferredNext::Answered(answer) => return answer,
            DeferredNext::Again(next) => deferred = next,
        }
    }
}

pub(in crate::app) fn bind_done_listener(
    path: &std::path::Path,
) -> std::io::Result<tokio::net::UnixListener> {
    use std::os::unix::fs::PermissionsExt;

    let listener = tokio::net::UnixListener::bind(path)?;
    // bind(2) applies the process umask, but a permissive or changed umask must
    // never make the lifecycle control plane available to other local users.
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600))?;
    Ok(listener)
}

#[cfg(unix)]
pub(in crate::app) async fn serve_done_listener(
    state: Arc<Mutex<AppState>>,
    listener: tokio::net::UnixListener,
) {
    let plane = {
        let state = Arc::clone(&state);
        off_the_workers(move || {
            let app = state.lock().unwrap();
            ControlPlane::new(&app)
        })
        .await
    };
    let mut accept_backoff =
        crate::backoff::Backoff::new(Duration::from_millis(100), Duration::from_secs(5));
    loop {
        match listener.accept().await {
            Ok((stream, _)) => {
                accept_backoff.reset();
                tokio::spawn(handle_done_stream(
                    Arc::clone(&state),
                    stream,
                    Arc::clone(&plane),
                ));
            }
            Err(error) => {
                let wait = accept_backoff.current();
                eprintln!("done socket: accept error: {error}; retrying in {wait:?}");
                tokio::time::sleep(wait).await;
                accept_backoff.increase();
            }
        }
    }
}

#[cfg(unix)]
pub(in crate::app) async fn handle_done_stream(
    state: Arc<Mutex<AppState>>,
    stream: tokio::net::UnixStream,
    plane: Arc<ControlPlane>,
) {
    let (read_half, mut write_half) = stream.into_split();
    let mut lines = tokio::io::BufReader::new(read_half).lines();
    while let Ok(Some(line)) = lines.next_line().await {
        let arrived = WaitTimer::start();
        let Ok(frame) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        #[cfg(test)]
        let origin = (!is_independent_read(&frame))
            .then(|| plane.clock.mcp_write(&frame, arrived.started_at()))
            .flatten();
        #[cfg(test)]
        let arrived = arrived.with_write_origin(origin.clone());
        let response = plane.answer_since(Arc::clone(&state), frame, arrived).await;
        if let Some(response) = response {
            reply::emit(
                &mut write_half,
                response,
                #[cfg(test)]
                origin.as_deref(),
            )
            .await;
        } else {
            #[cfg(test)]
            if let Some(origin) = origin {
                origin.settled();
            }
        }
    }
}

/// Answer one writer/report frame on the blocking pool after permit admission.
///
/// App-lock waits and synchronous writer work must not park a runtime worker.
/// The frame's deferred awaits, including Git work with the guard released,
/// are driven from the same blocking thread. Supported reads use read_lane.
#[cfg(unix)]
async fn answer_off_the_workers(
    state: Arc<Mutex<AppState>>,
    frame: Value,
    timer: FrameTimer,
    mut turn: Turn,
) -> Option<Value> {
    let runtime = tokio::runtime::Handle::current();
    let waiting = WaitTimer::start();
    #[cfg(test)]
    let child = timer.write_context().map(|context| context.child());
    #[cfg(test)]
    let pool_wait = timer.write_wait(crate::timing::write_wait::WaitKind::BlockingPool);
    off_the_workers(move || {
        #[cfg(test)]
        drop(pool_wait);
        timer.record_pool_wait(waiting.elapsed());
        let response = runtime.block_on(handle_authenticated_mcp_frame(
            &state, &frame, &timer, &mut turn,
        ));
        #[cfg(test)]
        if let Some(child) = child {
            child.complete();
        }
        response
    })
    .await
}

pub(in crate::app) async fn handle_authenticated_mcp_frame(
    state: &Arc<Mutex<AppState>>,
    frame: &Value,
    timer: &FrameTimer,
    turn: &mut Turn,
) -> Option<Value> {
    #[cfg(test)]
    timer.sample_tool(
        serde_json::from_value::<BridgeAction>(frame["request"].clone())
            .as_ref()
            .map(BridgeAction::tool_name)
            .unwrap_or("done"),
    );
    let admission = timer.lock(state).update_admission();
    let _lease = match admission {
        Some(gate) => {
            let entered = {
                #[cfg(test)]
                let _scope = timer.write_context().map(|context| context.bind_sync());
                gate.try_enter()
            };
            match entered {
                Some(lease) => Some(lease),
                None => {
                    return Some(json!({
                        "ok": false,
                        "error": "bridge update handoff in progress"
                    }))
                }
            }
        }
        None => None,
    };
    let addressed = {
        let app = timer.lock(state);
        authenticated_mcp_owner(frame, &app.session_registry)
            .map(str::to_string)
            .and_then(|agent_id| app.addressed_session(agent_id))
    };
    match addressed {
        Some(AddressedSession::Router { capture_id, .. }) => {
            handle_router_mcp_frame(state, frame, &capture_id, timer, turn).await
        }
        Some(AddressedSession::Coding(generation)) => {
            handle_coding_mcp_frame(state, frame, &generation, timer, turn).await
        }
        None => Some(json!({ "ok": false, "error": "unauthorized MCP session" })),
    }
}

pub(in crate::app) async fn handle_router_mcp_frame(
    state: &Arc<Mutex<AppState>>,
    frame: &Value,
    capture_id: &str,
    timer: &FrameTimer,
    turn: &mut Turn,
) -> Option<Value> {
    if let Ok(report) =
        serde_json::from_value::<DoneReport>(frame.get("report").cloned().unwrap_or(Value::Null))
    {
        timer.lock(state).on_router_done(capture_id, report);
        return None;
    }
    let action = match parse_action_request(frame) {
        Ok(action) => action,
        Err(error) => return Some(mcp_action_response(Err(error))),
    };
    let (answered, deferred) = timer.lock(state).router_deferring(capture_id, action);
    let result = match deferred {
        Some(deferred) => apply_off_the_socket(state, timer, turn, deferred).await,
        None => answered,
    };
    DeliveryRunner::drain(state, timer);
    Some(mcp_action_response(result))
}

pub(in crate::app) async fn handle_coding_mcp_frame(
    state: &Arc<Mutex<AppState>>,
    frame: &Value,
    generation: &McpConversationGeneration,
    timer: &FrameTimer,
    turn: &mut Turn,
) -> Option<Value> {
    if let Ok(report) =
        serde_json::from_value::<DoneReport>(frame.get("report").cloned().unwrap_or(Value::Null))
    {
        let deferred = {
            let mut app = timer.lock(state);
            if let Err(error) = generation.guard(&app) {
                return Some(mcp_action_response(Err(error)));
            }
            app.done_deferring_for_agent(&generation.entity_id, &generation.agent_id, report)
        };
        if let Some(deferred) = deferred {
            if let Err(error) = apply_off_the_socket(state, timer, turn, deferred).await {
                eprintln!("done report {}: {error}", generation.entity_id);
            }
        }
        DeliveryRunner::drain(state, timer);
        return None;
    }
    let action = match parse_action_request(frame) {
        Ok(action) => action,
        Err(error) => return Some(mcp_action_response(Err(error))),
    };
    let (answered, deferred) = {
        let mut app = timer.lock(state);
        if let Err(error) = generation.guard(&app) {
            return Some(mcp_action_response(Err(error)));
        }
        app.agent_action_deferring(&generation.entity_id, &generation.agent_id, action)
    };
    let result = match deferred {
        Some(deferred) => apply_off_the_socket(state, timer, turn, deferred).await,
        None => answered,
    };
    DeliveryRunner::drain(state, timer);
    Some(mcp_action_response(result))
}

fn parse_action_request(frame: &Value) -> Result<BridgeAction, String> {
    // Serde errors can echo untrusted action names and field contents. Return
    // one fixed refusal after session authentication, including for actions
    // introduced by an adapter newer than this daemon.
    serde_json::from_value(frame.get("request").cloned().unwrap_or(Value::Null))
        .map_err(|_| "invalid MCP action request".to_string())
}

pub(in crate::app) fn mcp_action_response(result: Result<Value, String>) -> Value {
    match result {
        Ok(result) => json!({ "ok": true, "result": result }),
        Err(error) => match crate::api::v1::reviews::errors::decode(&error) {
            Some(error) => {
                let mut response = error.into_reply(Value::Null);
                response.as_object_mut().unwrap().remove("id");
                response
            }
            None => json!({ "ok": false, "error": error }),
        },
    }
}

impl AppState {
    pub(in crate::app) fn mcp_conversation_generation(
        &self,
        entity_id: &str,
        agent_id: &str,
    ) -> Result<McpConversationGeneration, String> {
        let address = self.resolve_conversation_address(entity_id, Some(agent_id))?;
        Ok(McpConversationGeneration {
            entity_id: entity_id.into(),
            agent_id: agent_id.into(),
            thread_id: self.conversation_at(&address)?.id.clone(),
        })
    }

    /// Listen on the daemon control socket for `done` reports forwarded by the
    /// per-task `build-bridge mcp` servers, and route each to its task's `on_done`.
    pub fn spawn_done_socket(state: Arc<Mutex<AppState>>, path: String) {
        tokio::spawn(async move {
            if let Some(parent) = std::path::Path::new(&path).parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            // A socket file that ANSWERS belongs to a running daemon: its
            // harnesses dial this path for every `done`, and unlinking it out
            // from under them silently breaks each one's report. A second
            // bridge (a dev stack launched from inside an agent session that
            // inherited BRIDGE_MCP_SOCKET, say) must refuse loudly instead of
            // stealing the control plane. Only a DEAD file — one nothing
            // accepts on — is stale debris to clear.
            if std::os::unix::net::UnixStream::connect(&path).is_ok() {
                eprintln!(
                    "done socket: {path} is already served by a live daemon; refusing to \
                     replace it. Set BRIDGE_MCP_SOCKET to a private path for this instance."
                );
                return;
            }
            let _ = std::fs::remove_file(&path);
            let listener = match bind_done_listener(std::path::Path::new(&path)) {
                Ok(l) => l,
                Err(e) => {
                    eprintln!("done socket: bind {path} failed: {e}");
                    return;
                }
            };
            eprintln!("done socket: listening on {path}");
            serve_done_listener(state, listener).await;
        });
    }

    /// Route an agent's `done` to its owner's lifecycle transition, by owner
    /// lookup (plans map, then runs map), without draining: a report whose
    /// follow-up has git to run hands that git back HERE, to the socket that
    /// can release the guard before running it. The
    /// `done` twin of [`AppState::dispatch_deferring`].
    #[cfg(test)]
    pub(in crate::app) fn done_deferring(
        &mut self,
        entity_id: &str,
        report: DoneReport,
    ) -> Option<DeferredJob> {
        let agent_id = self
            .entity_agents(entity_id)
            .ok()
            .and_then(|agents| agents.primary())
            .map(|agent| agent.id.clone());
        self.done_deferring_for_resolved_agent(entity_id, agent_id.as_deref(), report)
    }

    fn done_deferring_for_resolved_agent(
        &mut self,
        entity_id: &str,
        agent_id: Option<&str>,
        report: DoneReport,
    ) -> Option<DeferredJob> {
        if self.plans.contains_key(entity_id) {
            self.on_plan_agent_done(entity_id, agent_id, report);
        } else if self.runs.contains_key(entity_id) {
            self.on_run_agent_done(entity_id, agent_id, report);
        } else {
            eprintln!("on_agent_done: unknown entity {entity_id}");
        }
        self.take_deferred()
    }

    /// Route a report while retaining the authenticated actor long enough to
    /// stop only that agent's execution clock.
    ///
    /// The report is the user's to read, whoever started the turn. An agent
    /// that was asked for something by another agent answers it with
    /// `message_agent`; nothing here carries these words to anybody else.
    pub(in crate::app) fn done_deferring_for_agent(
        &mut self,
        entity_id: &str,
        agent_id: &str,
        report: DoneReport,
    ) -> Option<DeferredJob> {
        self.record_agent_working_since(entity_id, agent_id, None);
        // A Complete hands the task the agent holds on to In review (spec:
        // Tasks → Automatic activity), and then says what it still holds
        // (spec: Tasks → The Complete reminder). Both before the lifecycle
        // routing below, which may end the run this agent belongs to and take
        // the binding the task is found through with it.
        //
        // The reminder runs second so that a task this very report handed on
        // is described as it now stands rather than as it stood a moment ago —
        // which is also what keeps it out of the list.
        if report.status == crate::mcp::DoneStatus::Completed {
            self.move_held_task_on_complete(entity_id, agent_id);
            self.remind_of_open_tasks(entity_id, agent_id);
        }
        self.done_deferring_for_resolved_agent(entity_id, Some(agent_id), report)
    }

    /// Execute an MCP thread request against the conversation owner resolved
    /// from the agent identity baked into that session's MCP command. The
    /// authenticated agent resolves to its current plan or run; planned runs
    /// resolve unread/reply actions to the owning Task (legacy plan id), while
    /// planless adopted runs retain their independent worktree conversation.
    #[cfg(test)]
    pub(in crate::app) fn on_mcp_action(
        &mut self,
        entity_id: &str,
        action: BridgeAction,
    ) -> Result<Value, String> {
        let agent_id = self.entity_agents(entity_id)?.resolve(None)?.id.clone();
        self.on_agent_mcp_action(entity_id, &agent_id, action)
    }

    /// One agent's tool, without draining: the coding and project surfaces'
    /// twin of [`AppState::router_deferring`]. A project agent's write tool can
    /// hand back git the way a verb does — cutting a workspace is the same
    /// `workspace.create` the browser calls — and the socket is the one place
    /// that can run it with the guard released.
    pub(in crate::app) fn agent_action_deferring(
        &mut self,
        entity_id: &str,
        agent_id: &str,
        action: BridgeAction,
    ) -> (Result<Value, String>, Option<DeferredJob>) {
        let queued_before = self.delivery_queue.checkpoint();
        let answered = self.on_agent_mcp_action(entity_id, agent_id, action);
        if answered.is_err() {
            self.drop_turns_queued_since(queued_before);
        }
        (answered, self.take_deferred())
    }

    /// One agent's tool, drained — for the tests that own the state directly
    /// and have no mutex to release. Running it is what the MCP control socket
    /// does with the guard released.
    #[cfg(test)]
    pub(in crate::app) fn agent_action(
        &mut self,
        entity_id: &str,
        agent_id: &str,
        action: BridgeAction,
    ) -> Result<Value, String> {
        self.with_inline_deferred(|app| {
            let (answered, deferred) = app.agent_action_deferring(entity_id, agent_id, action);
            let Some(mut deferred) = deferred else {
                return answered;
            };
            loop {
                let done = deferred.run();
                match app.apply_deferred_stage(MCP_CONTROL_METHOD, &Value::Null, done) {
                    DeferredNext::Answered(answer) => return answer,
                    DeferredNext::Again(next) => deferred = next,
                }
            }
        })
    }

    /// The project-scoped tools, each a thin wrapper over the verb the client
    /// calls. `None` is "not one of mine", which is every conversation tool and
    /// everything the router surface answers.
    ///
    /// Not the project agent's alone: an agent working in a checkout carries
    /// most of these too, and reaches the same handlers. Which project is read
    /// or written comes from the CALLING agent's own binding — a project
    /// conversation for the project agent, its run for an agent in a checkout —
    /// and never from a tool argument, so none of these carries a project id.
    fn project_scoped_action(
        &mut self,
        entity_id: &str,
        agent_id: &str,
        action: &BridgeAction,
    ) -> Option<Result<Value, String>> {
        Some(match action {
            BridgeAction::ListHarnesses => Ok(self.harness_table()),
            BridgeAction::ListWorkspaces => self.project_agent_workspaces(entity_id),
            BridgeAction::ListWorkspaceAgents { workspace_id } => {
                self.project_agent_workspace_agents(entity_id, workspace_id)
            }
            BridgeAction::CreateWorkspace { name, isolation } => {
                self.project_agent_create_workspace(entity_id, name, isolation.as_deref())
            }
            BridgeAction::DeleteWorkspace { workspace_id } => {
                self.project_agent_delete_workspace(entity_id, workspace_id)
            }
            BridgeAction::AddWorkspaceAgent {
                workspace_id,
                notify_user,
                harness,
                model,
                effort,
                name,
                role,
                capability,
            } => self.project_agent_add_workspace_agent(
                crate::app::AgentSender {
                    entity_id,
                    agent_id,
                },
                workspace_id,
                crate::app::AgentChoiceArgs {
                    harness: harness.as_deref(),
                    model: model.as_deref(),
                    effort: effort.as_deref(),
                    role: role.as_deref(),
                    capability: capability.as_deref(),
                },
                name.as_deref(),
                *notify_user,
            ),
            BridgeAction::RemoveWorkspaceAgent {
                workspace_id,
                agent_id: removed,
            } => self.project_agent_remove_workspace_agent(entity_id, workspace_id, removed),
            BridgeAction::ListProjectAgents => self.project_agent_project_agents(entity_id),
            BridgeAction::AddProjectAgent {
                notify_user,
                harness,
                model,
                effort,
                name,
                role,
                capability,
            } => self.project_agent_add_project_agent(
                crate::app::AgentSender {
                    entity_id,
                    agent_id,
                },
                crate::app::AgentChoiceArgs {
                    harness: harness.as_deref(),
                    model: model.as_deref(),
                    effort: effort.as_deref(),
                    role: role.as_deref(),
                    capability: capability.as_deref(),
                },
                name.as_deref(),
                *notify_user,
            ),
            BridgeAction::MessageWorkspaceAgent {
                workspace_id,
                agent_id: addressed,
                body,
            } => self.project_agent_message_workspace_agent(
                entity_id,
                agent_id,
                crate::app::WorkspaceAgentAddress {
                    workspace_id,
                    agent_id: addressed.as_deref(),
                },
                body,
            ),
            BridgeAction::AddProjectSource {
                path,
                remote,
                name,
                base_branch,
            } => self.project_agent_add_project_source(
                entity_id,
                crate::app::ProjectSourceArgs {
                    path: path.as_deref(),
                    remote: remote.as_deref(),
                    name: name.as_deref(),
                    base_branch: base_branch.as_deref(),
                },
            ),
            BridgeAction::RemoveProjectSource { source_id } => {
                self.project_agent_remove_project_source(entity_id, source_id)
            }
            BridgeAction::ReclaimWorkspace { workspace_id } => {
                self.project_agent_reclaim_workspace(entity_id, agent_id, workspace_id)
            }
            BridgeAction::AddWorkspaceDirectory {
                workspace_id,
                source_id,
                path,
                remote,
                name,
            } => self.project_agent_add_workspace_directory(
                entity_id,
                workspace_id,
                crate::app::WorkspaceDirectoryArgs {
                    source_id: source_id.as_deref(),
                    path: path.as_deref(),
                    remote: remote.as_deref(),
                    name: name.as_deref(),
                },
            ),
            BridgeAction::RemoveWorkspaceDirectory {
                workspace_id,
                directory_id,
            } => {
                self.project_agent_remove_workspace_directory(entity_id, workspace_id, directory_id)
            }
            _ => return None,
        })
    }

    /// The same, for a caller that knows WHICH agent is speaking — every real
    /// one, since the MCP control plane authenticates an agent.
    pub(in crate::app) fn on_agent_mcp_action(
        &mut self,
        entity_id: &str,
        agent_id: &str,
        action: BridgeAction,
    ) -> Result<Value, String> {
        // The surface a session is on is a property of the SESSION — its
        // agent's persisted purpose says which one, never its id's prefix or
        // anything its launch declared — and the gate is here as well as in
        // the tool inventory each surface is shown: a harness that writes its
        // own frames must not reach past the surface it was opened on.
        let surface = self.agent_mcp_surface(entity_id, agent_id);
        if !action.allowed_on(surface) {
            return Err(format!(
                "{} is a {} tool; this session is on the {} surface",
                action.tool_name(),
                action.surface_name(),
                surface.as_str()
            ));
        }
        if let BridgeAction::MessageAgent {
            agent_id: target,
            body,
            attachments,
        } = &action
        {
            let sender = crate::app::AgentSender {
                entity_id,
                agent_id,
            };
            return self.agent_message_agent(sender, target, body, attachments);
        }
        // The task tracker, before the per-surface tables: it is the one
        // family both working surfaces carry, so it is answered in one place
        // rather than once in each.
        if let Some(answered) = self.review_surface_action(entity_id, agent_id, &action) {
            return answered;
        }
        if let Some(answered) = self.task_surface_action(entity_id, agent_id, &action) {
            return answered;
        }
        if let Some(answered) = self.project_scoped_action(entity_id, agent_id, &action) {
            return answered;
        }
        let sender = crate::app::AgentSender {
            entity_id,
            agent_id,
        };
        if let Some(answered) = self.compaction_action(sender, &action) {
            return answered;
        }
        if let BridgeAction::SearchConversation { query } = &action {
            return self.search_agent_conversations(entity_id, agent_id, query);
        }
        // The topic is the AGENT's, not the conversation's: two agents sharing
        // a Task's thread each name their own work, and the record is where
        // the bubble reads it from.
        if let BridgeAction::SetTopic { topic } = &action {
            return self.set_agent_topic(entity_id, agent_id, topic);
        }
        // And its name, which is the agent itself rather than its current
        // work. Refusable where the topic is not: two agents on one
        // conversation cannot both be "Tracker".
        if let BridgeAction::SetName { name } = &action {
            return self.set_agent_name(entity_id, agent_id, name);
        }
        let attachments = if let BridgeAction::PostThreadMessage {
            body, attachments, ..
        } = &action
        {
            crate::app::conversations::validate_agent_message_body(body)?;
            self.take_in_agent_message_files(entity_id, agent_id, attachments)?
        } else {
            Vec::new()
        };
        let posted_still_working = match &action {
            BridgeAction::PostThreadMessage { still_working, .. } => Some(*still_working),
            _ => None,
        };
        // Where an agent speaks — its own conversation, or its Task's when it
        // is the implementation's first — is one rule, and it is
        // `edit_agent_conversation`'s.
        let now = now_rfc3339();
        let result = self.edit_agent_conversation(entity_id, agent_id, |thread, _| {
            apply_thread_action(thread, action, attachments, &now)
        });
        if result.is_ok() {
            match posted_still_working {
                Some(true) => self.start_agent_working(entity_id, agent_id, &now),
                Some(false) => self.record_agent_working_since(entity_id, agent_id, None),
                None => {}
            }
            self.observe_conversation_working(entity_id, &now);
        }
        result
    }

    /// One agent's `done`, drained — the synchronous twin of
    /// [`AppState::done_deferring`], for the tests that own the state directly
    /// and have no guard to release. Running it is what the MCP control socket
    /// does with the guard released.
    #[cfg(test)]
    pub(in crate::app) fn on_agent_done(&mut self, entity_id: &str, report: DoneReport) {
        self.with_inline_deferred(|app| {
            let agent_id = app
                .entity_agents(entity_id)
                .ok()
                .and_then(|agents| agents.primary())
                .map(|agent| agent.id.clone());
            let deferred = match agent_id {
                Some(agent_id) => app.done_deferring_for_agent(entity_id, &agent_id, report),
                None => app.done_deferring(entity_id, report),
            };
            if let Some(deferred) = deferred {
                let done = deferred.run();
                if let Err(error) = app.apply_deferred(MCP_CONTROL_METHOD, &Value::Null, done) {
                    eprintln!("on_agent_done {entity_id}: {error}");
                }
            }
        })
    }
}

#[cfg(test)]
mod pr_error_tests {
    use super::*;

    #[test]
    fn mcp_pr_refusals_decode_without_exposing_the_internal_marker() {
        for (code, retryable) in [
            ("stale_version", false),
            ("busy", true),
            ("conflict", false),
        ] {
            let details = json!({"task_id":"task-1","directory_id":"dir-1","recovery":"Read get_review","reason":code});
            let error = crate::api::v1::reviews::errors::encode(
                code,
                "Review state changed",
                details.clone(),
            );
            let response = mcp_action_response(Err(error));
            assert_eq!(
                response,
                json!({"ok":false,"error":"Review state changed","error_code":code,"retryable":retryable,"details":details})
            );
            assert!(!response.to_string().contains("review_api_error:"));
        }
    }

    #[test]
    fn legacy_mcp_errors_and_successes_keep_their_exact_envelopes() {
        assert_eq!(
            mcp_action_response(Err("legacy refusal".into())),
            json!({"ok":false,"error":"legacy refusal"})
        );
        assert_eq!(
            mcp_action_response(Ok(json!({"task_id":"task-1"}))),
            json!({"ok":true,"result":{"task_id":"task-1"}})
        );
    }
}

#[cfg(test)]
#[path = "tests/runtime/mcp_wait_timing.rs"]
mod wait_timing_tests;
