from pathlib import Path
import hashlib,json,difflib,subprocess
repo=Path('/home/zech/Projects/.build-worktrees/workspaces/proj-1/lock-hold-709/Build')
bundle=repo.parent/'.task722-artifacts/drafts/common-harness/ack-emission2-f803'
stage=bundle/'testfirst'
files={}
path='bridge/src/app/mcp.rs'
text=(repo/path).read_text()
text=text.replace('#[cfg(unix)]\nmod read_lane;','#[cfg(unix)]\nmod read_lane;\n#[cfg(unix)]\nmod reply;',1)
text=text.replace('use tokio::io::{AsyncBufReadExt, AsyncWriteExt};','use tokio::io::AsyncBufReadExt;',1)
start=text.index('        #[cfg(test)]\n        let response_expected = response.is_some();')
end=text.index('\n    }\n}',start)
text=text[:start]+'''        if let Some(response) = response {
            reply::emit(
                &mut write_half,
                response,
                #[cfg(test)]
                origin.as_deref(),
            )
            .await;
        } else {
            #[cfg(test)]
            if let Some(origin) = origin {
                origin.settled();
            }
        }'''+text[end:]
files[path]=text
files['bridge/src/app/mcp/reply.rs']='''//! The existing MCP response emission sequence and its native origin outcome.
use serde_json::Value;
use tokio::io::{AsyncWrite, AsyncWriteExt};

#[cfg(test)]
mod tests;

pub(super) async fn emit<W: AsyncWrite + Unpin>(
    writer: &mut W,
    response: Value,
    #[cfg(test)] origin: Option<&crate::timing::write_origin::WriteOrigin>,
) {
    // Preserve all three existing operations even when an earlier one fails.
    let _content_written = writer.write_all(response.to_string().as_bytes()).await;
    let _newline_written = writer.write_all(b"\\n").await;
    let _flushed = writer.flush().await;
    #[cfg(test)]
    if let Some(origin) = origin {
        if _content_written.is_ok() && _newline_written.is_ok() && _flushed.is_ok() {
            origin.complete();
        } else {
            origin.cancel();
        }
    }
}
'''
for path, text in files.items():
    target=stage/'after'/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(text)
