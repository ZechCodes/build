from pathlib import Path
import hashlib,json,difflib,subprocess
repo=Path('/home/zech/Projects/.build-worktrees/workspaces/proj-1/lock-hold-709/Build')
bundle=repo.parent/'.task722-artifacts/drafts/common-harness/ack-emission2-f803'
stage=bundle/'implementation'
def read(path):
    first=bundle/'testfirst/after'/path
    return first.read_text() if first.exists() else (repo/path).read_text()
files={}
path='bridge/src/timing/write_origin.rs'; text=read(path)
needle='impl WriteOrigin {\n'
insert='''/// One native reply emission attempt, bound to its exact origin. Capturing
/// does not acknowledge or finish anything; only full send success commits it.
/// This observes a reply boundary, not receipt/durable acceptance of an effect.
pub(crate) struct ReplyEmission<'a> {
    origin: &'a WriteOrigin,
    started_at: Instant,
}

impl ReplyEmission<'_> {
    pub(crate) fn finish(self, sent: bool) {
        if !sent {
            self.origin.cancel();
            return;
        }
        self.origin.execution_started();
        if let Some(root) = self.origin.root.lock().unwrap().take() {
            root.acknowledged_at(self.started_at);
            root.complete();
        }
    }
}

'''
text=text.replace(needle,insert+needle,1)
needle='    pub(crate) fn complete(&self) {\n'
insert='''    /// Sample immediately before the first native send operation. The owning
    /// emitter must pass its actual complete send outcome to the returned token.
    pub(crate) fn begin_reply(&self) -> ReplyEmission<'_> {
        ReplyEmission {
            origin: self,
            started_at: self.context.now(),
        }
    }

'''
text=text.replace(needle,insert+needle,1); files[path]=text
path='bridge/src/timing/write_wait/handles.rs'; text=read(path)
needle='''    pub(crate) fn complete(mut self) {
'''
insert='''    pub(crate) fn acknowledged_at(&self, at: Instant) {
        self.context.registry.milestone_at(&self.context, true, at);
    }
'''
text=text.replace(needle,insert+needle,1)
text=text.replace('impl WriteContext {\n','''impl WriteContext {
    pub(crate) fn now(&self) -> Instant {
        self.registry.now()
    }
''',1); files[path]=text
path='bridge/src/timing/write_wait/registry.rs'; text=read(path)
needle='''    pub(super) fn milestone(&self, context: &WriteContext, acknowledged: bool) {
        let now = (self.clock)();
        self.mutate(|state| {
'''
replacement='''    pub(super) fn milestone(&self, context: &WriteContext, acknowledged: bool) {
        self.milestone_at(context, acknowledged, (self.clock)());
    }
    pub(super) fn milestone_at(&self, context: &WriteContext, acknowledged: bool, now: Instant) {
        self.mutate(|state| {
'''
assert text.count(needle)==1
text=text.replace(needle,replacement,1); files[path]=text
path='bridge/src/app/mcp/reply.rs'; text=read(path)
needle='''    // Preserve all three existing operations even when an earlier one fails.
    let _content_written = writer.write_all(response.to_string().as_bytes()).await;
'''
replacement='''    let bytes = response.to_string();
    #[cfg(test)]
    let emission = origin.map(|origin| origin.begin_reply());
    // Preserve all three existing operations even when an earlier one fails.
    let _content_written = writer.write_all(bytes.as_bytes()).await;
'''
assert text.count(needle)==1
text=text.replace(needle,replacement,1)
needle='''    if let Some(origin) = origin {
        if _content_written.is_ok() && _newline_written.is_ok() && _flushed.is_ok() {
            origin.complete();
        } else {
            origin.cancel();
        }
    }
'''
replacement='''    if let Some(emission) = emission {
        emission.finish(_content_written.is_ok() && _newline_written.is_ok() && _flushed.is_ok());
    }
'''
assert text.count(needle)==1
text=text.replace(needle,replacement,1); files[path]=text
for path,text in files.items():
    target=stage/'after'/path; target.parent.mkdir(parents=True,exist_ok=True); target.write_text(text)
subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true']+[str(stage/'after'/path) for path in files],check=True)
patch='';entries=[]
for path in sorted(files):
    before=read(path); after=(stage/'after'/path).read_text()
    patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
    entries.append({'path':path,'base_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'baseline':'TESTFIRST_after' if (bundle/'testfirst/after'/path).exists() else 'f803_tracked'})
(stage/'implementation.patch').write_text(patch)
manifest={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'requires_testfirst_patch_sha256':hashlib.sha256((bundle/'testfirst/testfirst.patch').read_bytes()).hexdigest(),'status':'offsource_UNAPPLIED_no_RED_receipt_yet','runtime':'No builds/tests/source edits. Only apply after coordinator observes exact native success regression RED and Trace reviews implementation.','scope':'MCP emission timestamp only. RPC emitter changes excluded pending their own deterministic test-first controls. No product operation ordering, thresholds, receipt behavior, existing ACK assertions, cancellation or required-child drain changes.','patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'files':entries}
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(manifest['patch_sha256'])
