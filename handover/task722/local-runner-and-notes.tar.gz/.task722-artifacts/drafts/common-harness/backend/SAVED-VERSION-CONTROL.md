# Exact native saved-version prerequisite

Off-source test-first design only. Do not implement a success callback before its actual RED. No source/test/build/runtime claim.

The actual native topic/name endpoints return the requested scalar after `edit_agent_record_checked` succeeds. That reply is not an independent persistence oracle. Reading the latest record later can be overwritten by a genuine concurrent second write; adding state predecessor chains would invalidate the declared eight-call burst. Task status can also be an accepted no-op or be reordered, so requiring a new Moved event for every accepted reply is incorrect.

Use one small opt-in cfg(test) observer at the existing accepted save/install boundary. It receives the bound original IDs and actual installed owner/agent ID plus topic/name/name_asked fields, or the actual accepted Task record fields + native updated_at/version and no-op/change disposition already known by the mutation. Do not perform another SQL read while AppState is held. Capture only the bounded fields required by these two cases, not Agent.thread or whole histories. If an endpoint has no native topic/name revision, explicitly report that absence; a harness-assigned observer sequence must not be labelled a product revision.

The observer must run only after the save and install succeeded. Failed persistence publishes no successful witness. A mutex-free installed observer check should remain no-op when not opted in; measured overhead is retained, never subtracted.

Required bounded actual controls:

1. Two real same-owner SetTopic calls and two real SetName calls via issued Coding sockets. Release an AppState holder so they compete normally, retaining two identity socket credits; no cross-request ordering. Capture actual replies, exact observer witnesses and last persisted record, then close/join all sockets/receiver/server work before assertions. Each accepted original must have exactly its own accepted fields even if later overwritten. The test-first scaffold emits no witness and fails only after actual calls/cleanup.
2. An actual failed save for a separately targeted request (`Store::fail_next_write` after the successful concurrent group is settled). Assert native error/unchanged persisted fields and zero successful observer record for that original after cleanup.
3. Concurrent tasks.update / move_task with repeated target status, retaining a real no-op. Original-specific accepted task records must match native successful replies whether or not a Moved event exists. Existing immutable Moved events can supplement changed cases; they cannot fabricate no-op changes or replace the accepted record.

The common backend retains these exact snapshots by original ID and reduces them to bounded passing witnesses after real replies. Missing/duplicate/uncommitted witnesses are hard proof failures. No expected-value echo, latest-record-only oracle, replacement write or caller serialization is allowed.
