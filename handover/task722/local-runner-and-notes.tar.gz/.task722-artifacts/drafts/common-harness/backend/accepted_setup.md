# Accepted-record consumer integration (OFFSOURCE; no runtime claim)

Owner: qualification_recipes for `common_requests/accepted.rs`; Busy owns backend wiring. The observer hooks have exact-source Trace PASS, while their runtime GREEN is pending the next checkpoint. This package must not be materialized into the frozen common engine before root releases it. A positive response alone remains a proof gap until this consumer and the other saved-effect paths run.

## Module and API

Add to common_requests.rs:

```rust
#[path = "common_requests/accepted.rs"]
mod accepted;
```

The draft implements these methods without constructing a whole Agent or Task:

```rust
pub fn requires_accepted_record(&self) -> bool;
pub fn verify_accepted_record(
    &self,
    decoded: &serde_json::Value,
    record: crate::app::accepted_records::AcceptedRecord,
) -> Result<OracleWitness, String>;
pub fn verify_accepted_comment(
    &self,
    decoded: &serde_json::Value,
    record: crate::app::accepted_records::AcceptedRecord,
    saved: crate::tracker::TaskComment,
) -> Result<OracleWitness, String>;
```

The single-record method accepts topic, name and task status. It deliberately refuses comments: the combined method requires the actual saved comment and merges both native checks, so task metadata cannot accidentally be treated as proof of saved comment text/author.

## Setup and capture ownership

PreparedBackend needs:

```rust
accepted: std::sync::Arc<crate::app::accepted_records::AcceptedRecords>,
accepted_raw: std::sync::Mutex<
    std::collections::BTreeMap<String, Vec<crate::app::accepted_records::AcceptedRecord>>,
>,
```

Construct the collector once with AcceptedRecords::new(). Install it once with
`fixture.state.lock()?.test_capture_accepted_records(Arc::clone(&self.accepted))`
in prepare_collectors, after actual bootstrap terminal proof and before any T0 or
trial write. Do not install a fresh observer per request or clear accepted work.
Keep any Store clone needed for independent immutable comments in PreparedBackend;
clone it during setup and release AppState before SQL work. No new SQL work goes
under the app mutex.

After `dispatch_write` returns a genuine positive final reply, take once by the
unchanged `slot.original_id`. Before selecting or verifying anything, retain the
entire Vec in `accepted_raw` under that original. A duplicate attempt to insert
that original fails; do not overwrite the prior entry. Archive the full retained
Vec on any failure, including zero records. Prefer a separate
`accepted-records.jsonl` artifact in final/failed cleanup rather than mislabelling
native records as decoded responses. Keep the archive owned until the cleanup
result is persisted; a failed sink write is a failure, not permission to discard.

For each actual planned write (including methods that expect no accepted record):

- Topic, name, status, comment: exactly one record is required. Zero/multiple is
  a hard proof failure; never choose first/latest or filter away another variant.
- Other methods: expect zero records. A record with the same original remains
  visible and fails as unexpected instead of being silently discarded.
- Only after the entire raw Vec is retained, clone its one record for validation.
  The clone is bounded to captured native fields, not an Agent.thread/history.
- Final settlement audit calls take again for every original in the immutable
  plan and retains/fails any late record. Receiving a reply is not sufficient
  proof that no later callback duplicated attribution.

The current collector exposes only take(original). This contract does not claim
it can enumerate unknown, unplanned originals. If final whole-collector auditing
is required, that needs an explicit read/drain API and test; do not invent it or
claim unknown IDs were audited. All expected IDs and unexpected records under
those IDs are checked by the rules above.

## Effect selection

```rust
match &request.effect {
    ExpectedEffect::Topic { .. }
    | ExpectedEffect::Name { .. }
    | ExpectedEffect::TaskStatus { .. } => {
        request.verify_accepted_record(decoded, exact_one_record)
    }
    ExpectedEffect::Comment { .. } => {
        // ID comes from the actual successful reply, never from a new mutation.
        let comment_id = decoded["result"]["comment"]["id"]
            .as_str().ok_or("actual comment reply lacks ID")?;
        // Use the setup Store clone in spawn_blocking, with no AppState guard.
        let saved = store.load_tracker_comment(comment_id)?
            .ok_or("acknowledged native comment was not saved")?;
        request.verify_accepted_comment(decoded, exact_one_record, saved)
    }
    _ => request.verify_saved(decoded, actual_saved_effect),
}
```

The pseudocode above returns the existing native oracle into
verify_and_summarize_response. Set EffectVerified only after that succeeds, and
keep the normal required-child completion/inbox check before Completed. Do not
set registry_root or mandatory_children_complete based on accepted-record proof.
Preserve all existing client, own-external and native wait measurements.

The archived record may contain another concurrent topic/name field. Only the
requested field is compared to this request; the whole actual captured record
is preserved. The requested field, returned scalar, actual installed owner/agent,
and actual MCP action/caller all have to agree. Names additionally require the
native name_asked=true state.

For task status and comments, all nine returned bounded native task fields are
compared (id, number, state, status, title, body, priority, labels, updated_at).
updated_at is parsed by the repo's time/Rfc3339 parser and retained exactly;
no monotonic/product revision is invented. The internal project_path is retained
in the raw record; it is not equated to the API's different project_id address.
Task status must equal the actual requested status. Changed requires the actual
nonempty native event ID, unequal from/to and to==accepted.status. Noop remains
an explicit successful status disposition and never gets a made-up Moved event.
Common comments must have StatusNoop, and still prove their exact saved ID/body/
author through the independent native comment oracle.

The common commands are independent single-original writes. The consumer requires
record.original_ids exactly [request.original_id]; foreign/repeated/joined IDs
fail visibly. This is a scoped claim for these real common routes, not a promise
that generic current_context is semantic authorship for every possible future
nested service scope. The status record does not independently carry the native
Moved-event actor; the consumer checks actual request actor/caller and native
status disposition, and must not label that as an independently reloaded actor.

## Test-first integration acceptance

Retain the already observed actual 312-smoke proof-gap failure. Before materializing
this consumer, root should have the actual observer controls GREEN. Then the same
unchanged smoke must prove successful records through this path, with no extra
writes or caller ordering. Add focused direct-oracle negative cases if needed:
wrong/multiple original IDs; wrong owner/agent; wrong action; failed response;
accepted requested field differing from reply; native timestamp from another
reply; Changed with empty event ID/equal statuses/wrong to; Noop without invented
event; comment supplied only a task record; and saved comment body/actor mismatch.
These are direct validations of evidence, not substitutes for the real socket
observer controls and actual concurrent common smoke.

No production code, tracked common source, test execution, or commits are included
in this offsource package.
