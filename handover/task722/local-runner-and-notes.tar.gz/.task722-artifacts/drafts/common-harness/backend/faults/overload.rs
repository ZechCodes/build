//! Actual400-intent overload; a valid busy is not a product defect or success.
use super::*;
use trial_complete::{PipelineControlRun,Provenance};
use serde::Serialize;
#[derive(Serialize)]
struct OverloadSummary<'a>{qualification:bool,engine:&'a trial_complete::PipelineControlReport,diagnostics:Value}
pub(in crate::app::tests::runtime::write_wait_qualification) struct OverloadRun{pub engine:PipelineControlRun,pub artifact:PathBuf,pub diagnostics:Value}

pub(in crate::app::tests::runtime::write_wait_qualification) async fn run_overload(name:TrialName,provenance:Provenance,artifacts:&FaultArtifacts)->Result<OverloadRun,String>{
    // Same existing preflight, before creating real fixture resources.
    if provenance.nice!=10||provenance.source_tree.is_empty()||provenance.binary_sha256.is_empty()||provenance.fresh_quiet_release_sha256.is_empty(){return Err("actual NI10/frozen source-binary/quiet receipt required before overload setup".into());}
    let plan=super::plan::overload_plan(name)?;let engine_root=artifacts.engine_path();
    let sink:Arc<dyn ArtifactSink>=Arc::new(trial_complete::JsonArtifacts::new(&engine_root)?);
    let prepared=match super::preparation::prepare_overload(name,provenance,plan.clone()).await{Ok(prepared)=>prepared,Err(failure)=>return Err(cleanup_setup(failure).await)};
    let backend=match ControlBackend::new_overload(prepared,Arc::clone(&sink)){Ok(backend)=>Arc::new(backend) as Arc<dyn trial_complete::TrialBackend>,Err(failure)=>return Err(cleanup_setup(failure).await)};
    let run=match trial_complete::run_fault_plan(name,Arc::clone(&backend),&*sink,plan.clone(),Duration::from_secs(1)).await{
        Ok(run)=>run,Err(error)=>{let closed=close_failed_backend(backend).await;return Err(format!("actual overload engine failure: {error}; actual bounded cleanup confirmed={closed}"));}
    };
    let diagnostics=match archive_diagnostics(&engine_root,name,&plan,&run.report){Ok(value)=>value,Err(error)=>json!({"archive_validation_error":error,"qualification":false})};
    let artifact=match artifacts.write("overload400",&OverloadSummary{qualification:false,engine:&run.report,diagnostics:diagnostics.clone()}){Ok(path)=>path,Err(error)=>{if run.unfinished.is_some(){std::mem::forget(run);}return Err(format!("overload summary persistence failed; any unfinished run ownership retained: {error}"));}};
    Ok(OverloadRun{engine:run,artifact,diagnostics})
}
async fn cleanup_setup(failure:PreparationFailure)->String{
    let reason=failure.reason;
    match failure.retained.shutdown().await{Ok(_)=>reason,Err(retained)=>{let cleanup=retained.reason;std::mem::forget(retained.retained);format!("{reason}; actual cleanup retained: {cleanup}")}}
}
fn archive_diagnostics(root:&Path,name:TrialName,plan:&[Slot],report:&trial_complete::PipelineControlReport)->Result<Value,String>{
    use std::io::BufRead;
    let dir=root.join(name.label());let native:Value=serde_json::from_reader(std::fs::File::open(dir.join("native-registry-final.json")).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    let rows=std::io::BufReader::new(std::fs::File::open(dir.join("control-rows.jsonl")).map_err(|e|e.to_string())?).lines().map(|line|serde_json::from_str::<Value>(&line.map_err(|e|e.to_string())?).map_err(|e|e.to_string())).collect::<Result<Vec<_>,String>>()?;
    let Some(state)=&report.fault_overload else{return Err("actual overload runner diagnostics missing".into());};
    let refusals=state.actual_refusals.values().map(|refusal|check_refusal(root,plan,&native,&rows,refusal)).collect::<Result<Vec<_>,String>>()?;
    Ok(json!({"intended_semantic":400,"offer_window_us":1_000_000,"semantic_caller_count":12,"semantic_credits_per_caller":2,
        "actual_refusals":refusals,"zero_busy_is_valid":true,"offered_unsent_dependents":state.censored_dependents,
        "interpretation":"valid proved preaccept busy is neither product defect nor successful mutation; no rewrite/retry/replacement; all engine violations remain attached",
        "native_rows":native["rows"].as_array().map(Vec::len),"archived_client_rows":rows.len()}))
}
fn check_refusal(root:&Path,plan:&[Slot],native:&Value,rows:&[Value],refusal:&trial_complete::ControlRefusal)->Result<Value,String>{
    let slot=plan.iter().find(|slot|slot.original_id==refusal.original_id).ok_or("actual refusal outside immutable400")?;
    let raw:Value=serde_json::from_reader(std::fs::File::open(root.join(&refusal.raw_response_artifact)).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    if raw["original_id"]!=refusal.original_id||raw["case"]!=refusal.method{return Err("actual raw refusal artifact identity changed".into());}
    let matching=native["rows"].as_array().ok_or("native rows missing")?.iter().filter(|row|row["original_id"]==refusal.original_id).collect::<Vec<_>>();
    let row=if matching.len()==1{Some(matching[0])}else{None};
    let frames=rows.iter().find(|row|row["slot"]["original_id"]==refusal.original_id).and_then(|row|row["frames"].as_array()).map_or(0,Vec::len);
    serde_json::to_value(super::refusal::archived(slot,refusal,&raw["decoded_response"],row,frames)).map_err(|e|e.to_string())
}

async fn close_failed_backend(backend:Arc<dyn trial_complete::TrialBackend>)->bool{
    backend.request_close();let until=Instant::now()+CLEANUP_BOUND;
    while !backend.closed()&&Instant::now()<until{tokio::time::sleep(Duration::from_millis(5)).await;}
    if backend.closed(){true}else{std::mem::forget(backend);false}
}
