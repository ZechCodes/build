//! Actual busy is optional. A busy string alone never proves pre-durability.
use super::*;
use serde::Serialize;
#[derive(Clone,Debug,Serialize)]
pub(in super::super) enum BusyDisposition {
    NotBusy,
    VerifiedFrontdoor { original_id:String, elapsed_us:u64, native_write_id:String },
    Invalid { original_id:String, reason:String },
}
pub(in super::super) fn classify(slot:&Slot,reply:&ReplyProof,row:Option<&WriteSnapshot>,executed_frames:usize)->BusyDisposition {
    if reply.reply["error_code"]!="busy" || reply.reply["retryable"]!=true {return BusyDisposition::NotBusy;}
    let invalid=|reason:&str|BusyDisposition::Invalid{original_id:slot.original_id.clone(),reason:reason.into()};
    if slot.traffic!=trial_complete::Traffic::Write{return invalid("reads may not be refused as busy");}
    if reply.original_id!=slot.original_id || reply.reply["ok"]!=false{return invalid("actual refusal identity/protocol mismatch");}
    let elapsed=reply.final_reply_at.saturating_duration_since(reply.sent_at);
    if elapsed>Duration::from_millis(100){return invalid("actual busy sent-to-decoded-final exceeded100ms");}
    let Some(row)=row else{return invalid("no actual native row proves preaccept disposition");};
    if row.original_id!=slot.original_id || row.acknowledged_at.is_some(){return invalid("actual ACK exists or original mismatch; not proved pre-durable");}
    // Current carrier's actual Full-admitter branch cancels its origin before
    // execution. Handler/API busy completes/ACKs its origin instead. Require
    // that actual terminal cancellation AND no executed frame/child, not just
    // a guessed error message or a missing synthetic server timestamp.
    if !row.cancelled || row.abandoned || !row.root_finished || !row.outstanding.is_empty() || !row.active.is_empty() || executed_frames!=0 {
        return invalid("actual root/frame evidence does not prove frontdoor rejection before execution");
    }
    BusyDisposition::VerifiedFrontdoor{original_id:slot.original_id.clone(),elapsed_us:super::evidence::us(elapsed),native_write_id:format!("{:?}",row.id)}
}

pub(in super::super) fn archived(slot:&Slot,refusal:&trial_complete::ControlRefusal,raw:&Value,row:Option<&Value>,executed_frames:usize)->BusyDisposition{
    let invalid=|reason:&str|BusyDisposition::Invalid{original_id:slot.original_id.clone(),reason:reason.into()};
    if raw["error_code"]!="busy"||raw["retryable"]!=true{return invalid("actual raw response is not retryable busy");}
    if raw["ok"]!=false||refusal.original_id!=slot.original_id{return invalid("actual refusal protocol/original mismatch");}
    if refusal.sent_to_decoded_final_ns>100_000_000{return invalid("actual refusal exceeded100ms");}
    let Some(row)=row else{return invalid("no unique actual native root; pre-durability unproved");};
    if !row.as_object().is_some_and(|row|row.contains_key("acknowledged_relative_us"))||row["method"]!=refusal.method||row["original_id"]!=slot.original_id||!row["acknowledged_relative_us"].is_null(){return invalid("native original mismatch or ACK exists");}
    if row["cancelled"]!=true||row["abandoned"]!=false||row["root_finished"]!=true||executed_frames!=0{return invalid("not a proved frontdoor cancellation before execution");}
    if row["outstanding"].as_array().is_none_or(|rows|!rows.is_empty())||row["active"].as_array().is_none_or(|rows|!rows.is_empty()){return invalid("actual rejected root retains unfinished obligations");}
    let Some(write_id)=row["write_id"].as_str().filter(|value|!value.is_empty())else{return invalid("actual native write_id missing");};
    BusyDisposition::VerifiedFrontdoor{original_id:slot.original_id.clone(),elapsed_us:refusal.sent_to_decoded_final_ns/1000,native_write_id:write_id.into()}
}
