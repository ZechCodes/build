//! Proposed methods inside ControlBackend; normal new() sets overload_busy=false.
use super::*;
impl ControlBackend {
    pub fn new_overload(prepared:PreparedBackend,sink:Arc<dyn ArtifactSink>)->Result<Self,PreparationFailure>{
        if prepared.plan.len()!=400 || prepared.plan.iter().any(|slot|slot.traffic!=Traffic::Write || slot.due_us>=1_000_000){return Err(PreparationFailure{reason:"invalid exact400 overload plan".into(),retained:prepared});}
        let mut backend=Self::new(prepared,sink)?;backend.overload_busy=true;Ok(backend)
    }
    pub(super) fn overload_refusal(&self,prepared:&PreparedBackend,slot:&Slot,recipe:&Recipe,reply:&ReplyProof)->Result<Option<ControlExecution>,String>{
        if !self.overload_busy || reply.reply["error_code"]!="busy" || reply.reply["retryable"]!=true{return Ok(None);}
        let artifact=self.sink.raw_response(prepared.name,&slot.original_id,&recipe.method,true,&reply.reply)?.ok_or("actual busy raw-response artifact missing")?;
        Ok(Some(ControlExecution::Refused(ControlRefusal{original_id:slot.original_id.clone(),method:recipe.method.clone(),raw_response_artifact:artifact,
            sent_to_decoded_final_ns:reply.final_reply_at.saturating_duration_since(reply.sent_at).as_nanos().min(u64::MAX as u128) as u64,
            pending_pre_durable_verification:true})))
    }
}
