//! Proposed additive model. Raw reply persisted first; no success/effect proof.
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct ControlRefusal {
    pub original_id:String,
    pub method:String,
    pub raw_response_artifact:String,
    pub sent_to_decoded_final_ns:u64,
    pub pending_pre_durable_verification:bool,
}
