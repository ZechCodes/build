// Next test-first stage only; current tracked freeze is untouched.
// Proposed ClientWatch lifecycle:
// register_at(id, intended_due) before timed start for every immutable slot;
// offer(id) records actual scheduler wake but never resets intended_due;
// sent/admitted/complete/cancel retain original deadline and raw milestones.
#[test]
fn future_schedule_registration_detects_scheduler_lag_before_offer_or_server_origin() {
    let (mut watch, clock) = fixture();
    let base = *clock.lock().unwrap();
    let original = "qual/small/trial1/write/00040";
    watch.register_at(original, base + Duration::from_secs(1));
    assert!(!watch.snapshot()[0].breached, "future intended time has zero age");
    *clock.lock().unwrap() = base + Duration::from_secs(6);
    assert!(!watch.snapshot()[0].breached, "exact five-second limit is inclusive");
    *clock.lock().unwrap() += Duration::from_nanos(1);
    assert!(watch.snapshot()[0].breached, "scheduler has not offered or sent the request");
    watch.offer(original);
    watch.sent(original);
    let row = &watch.snapshot()[0];
    assert_eq!(row.intended_at, base + Duration::from_secs(1));
    assert!(row.offered_at.unwrap() > row.intended_at);
    assert!(row.breached, "late offer/send cannot reset the original deadline");
}

// Independence test needed in same stage before implementing a real std
// watchdog: block the Tokio thread/hold AppState, advance clock from external
// test thread and require breach signal BEFORE releasing either blocker.
// Deadline index should be ordered by due and read via immutable ArcSwap so
// normal polls don't scan 24k future+completed rows or take mutator/AppState locks.
