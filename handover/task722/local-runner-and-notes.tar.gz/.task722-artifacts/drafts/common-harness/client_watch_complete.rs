//! OFF-SOURCE implementation draft; not a compiled or qualified result.
//!
//! Register the complete immutable schedule before waking any Tokio caller.
//! Call `offer` at the scheduler's actual release, before acquiring a caller's
//! two writer credits. `sent`, `server_registered`, `admitted`, and `complete`
//! record distinct observed boundaries; this module invents no server rows.
//!
//! The std watchdog owns its deadline index. It never locks Registry, Evidence,
//! AppState, a collector, or a writer. Its clock must also be independent of
//! those locks (use Arc::new(Instant::now) in actual trials). Archival snapshots
//! may take caller-evidence locks and are deliberately outside its poll path.

use std::collections::BTreeMap;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex, OnceLock, mpsc};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

pub(super) type Clock = Arc<dyn Fn() -> Instant + Send + Sync>;
const LIMIT: Duration = Duration::from_secs(5);
const POLL: Duration = Duration::from_millis(10);
// Each pass handles a bounded number of mailbox events before checking time.
const MAILBOX_BATCH: usize = 256;
// A memory safety bound, not a workload credit or a mechanism to drop intents.
// Exceeding it fails setup explicitly. The driver can specify its exact bound.
const DEFAULT_MAX_ORIGINALS: usize = 1_000_000;

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(super) enum TrafficCohort {
    SemanticWrite,
    Read,
    Exempt,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum FinalOutcome {
    Reply,
    ProtocolError,
    TransportError,
}

#[derive(Clone, Debug)]
pub(super) struct ClientRow {
    pub original_id: String,
    pub cohort: TrafficCohort,
    pub intended_at: Instant,
    pub registered_at: Instant,
    /// Compatibility-only enrollment through offer(). Qualification rejects it.
    pub implicit_schedule: bool,
    pub offered_at: Option<Instant>,
    pub sent_at: Option<Instant>,
    pub server_registered_at: Option<Instant>,
    pub admitted_at: Option<Instant>,
    /// The observed final encoded reply/transport terminal, never a cancellation.
    pub final_at: Option<Instant>,
    pub final_outcome: Option<FinalOutcome>,
    pub cancelled_at: Option<Instant>,
    /// Settlement timestamp retained for the original four-control API.
    pub finished_at: Option<Instant>,
    pub cancelled: bool,
    pub breached: bool,
}

impl ClientRow {
    pub fn age_at(&self, now: Instant) -> Duration {
        self.finished_at
            .map(|finished| finished.min(now))
            .unwrap_or(now)
            .saturating_duration_since(self.intended_at)
    }
}

struct Evidence {
    row: Mutex<Lifecycle>,
    deadline: Arc<Deadline>,
}

/// Actual mutable observations only. No placeholder absolute due time is stored
/// for a relative schedule before its single common start has been published.
struct Lifecycle {
    registered_at: Instant,
    implicit_schedule: bool,
    offered_at: Option<Instant>,
    sent_at: Option<Instant>,
    server_registered_at: Option<Instant>,
    admitted_at: Option<Instant>,
    final_at: Option<Instant>,
    final_outcome: Option<FinalOutcome>,
    cancelled_at: Option<Instant>,
    finished_at: Option<Instant>,
}

#[derive(Clone)]
enum Schedule {
    Absolute(Instant),
    Relative {
        offset: Duration,
        base: Arc<OnceLock<Instant>>,
    },
}

impl Schedule {
    fn intended_at(&self) -> Option<Instant> {
        match self {
            Self::Absolute(at) => Some(*at),
            Self::Relative { offset, base } => base.get().map(|base| {
                base.checked_add(*offset)
                    .expect("validated schedule instant")
            }),
        }
    }

    fn deadline_key(&self) -> DeadlineKey {
        match self {
            Self::Absolute(at) => {
                DeadlineKey::Absolute(at.checked_add(LIMIT).expect("deadline is representable"))
            }
            Self::Relative { offset, .. } => DeadlineKey::Relative(
                offset
                    .checked_add(LIMIT)
                    .expect("relative deadline is representable"),
            ),
        }
    }
}

#[derive(Clone, Copy, Eq, Ord, PartialEq, PartialOrd)]
enum DeadlineKey {
    Absolute(Instant),
    Relative(Duration),
}

/// Immutable identity/schedule plus independently readable terminal evidence.
/// settled_ns is zero while open; otherwise it is elapsed nanoseconds + 1
/// from Inner.epoch. One atomic publication records the terminal timestamp.
struct Deadline {
    original_id: String,
    cohort: TrafficCohort,
    schedule: Schedule,
    settled_ns: AtomicU64,
    breached: AtomicBool,
    notified: AtomicBool,
}

enum Event {
    Registered(Arc<Deadline>),
    Settled(Arc<Deadline>),
}

struct Registry {
    rows: BTreeMap<String, Arc<Evidence>>,
    receiver: Option<mpsc::Receiver<Event>>,
    latest_registration: Instant,
    maximum_relative_offset: Duration,
}

struct Inner {
    clock: Clock,
    epoch: Instant,
    maximum_originals: usize,
    registry: Mutex<Registry>,
    sender: mpsc::Sender<Event>,
    // Retain a thread handle for unparking; no caller mutex is read by watchdog.
    watchdog_thread: Mutex<Option<thread::Thread>>,
    relative_base: Arc<OnceLock<Instant>>,
    ready: AtomicBool,
    unmatched_replies: Mutex<Vec<String>>,
}

#[derive(Clone)]
pub(super) struct ClientWatch {
    inner: Arc<Inner>,
}

impl ClientWatch {
    pub fn new(clock: Clock) -> Self {
        Self::with_maximum_originals(clock, DEFAULT_MAX_ORIGINALS)
    }

    pub fn with_maximum_originals(clock: Clock, maximum_originals: usize) -> Self {
        assert!(maximum_originals > 0, "declare a nonzero schedule bound");
        let epoch = clock();
        let (sender, receiver) = mpsc::channel();
        Self {
            inner: Arc::new(Inner {
                clock,
                epoch,
                maximum_originals,
                registry: Mutex::new(Registry {
                    rows: BTreeMap::new(),
                    receiver: Some(receiver),
                    latest_registration: epoch,
                    maximum_relative_offset: Duration::ZERO,
                }),
                sender,
                watchdog_thread: Mutex::new(None),
                relative_base: Arc::new(OnceLock::new()),
                ready: AtomicBool::new(false),
                unmatched_replies: Mutex::new(Vec::new()),
            }),
        }
    }

    /// Default cohort is a semantic write, preserving the original test API.
    pub fn register_at(&self, original_id: &str, intended_at: Instant) {
        self.register_cohort_at(original_id, intended_at, TrafficCohort::SemanticWrite);
    }

    /// Identity-only lookup; safe before relative T0, with no archive scan.
    pub fn contains(&self, original_id: &str) -> bool {
        self.inner
            .registry
            .lock()
            .unwrap()
            .rows
            .contains_key(original_id)
    }

    pub fn schedule_lookup(&self, original_id: &str) -> Option<ScheduledIdentity> {
        let registry = self.inner.registry.lock().unwrap();
        registry
            .rows
            .get(original_id)
            .map(|evidence| ScheduledIdentity {
                cohort: evidence.deadline.cohort,
                intended_at: evidence.deadline.schedule.intended_at(),
            })
    }

    pub fn register_cohort_at(
        &self,
        original_id: &str,
        intended_at: Instant,
        cohort: TrafficCohort,
    ) {
        self.register(original_id, Schedule::Absolute(intended_at), cohort, false);
    }

    /// Allocate all 149k identities and immutable offsets during setup. No
    /// absolute trial timestamp is chosen until watch() acknowledges indexing.
    pub fn register_relative_at(&self, original_id: &str, offset: Duration, cohort: TrafficCohort) {
        self.register(
            original_id,
            Schedule::Relative {
                offset,
                base: Arc::clone(&self.inner.relative_base),
            },
            cohort,
            false,
        );
    }

    /// O(1) release of the already indexed schedule. Call immediately with a
    /// fresh Instant::now(), then release callers. It never moves a deadline.
    pub fn start_at(&self, base: Instant) {
        assert!(
            self.inner.ready.load(Ordering::Acquire),
            "watchdog acknowledges setup before T0"
        );
        let registry = self.inner.registry.lock().unwrap();
        assert!(
            base >= registry.latest_registration,
            "T0 follows full schedule registration"
        );
        base.checked_add(registry.maximum_relative_offset)
            .and_then(|at| at.checked_add(LIMIT))
            .expect("entire relative schedule is representable");
        self.inner
            .relative_base
            .set(base)
            .expect("one immutable trial T0");
        drop(registry);
        self.unpark();
    }

    fn register(
        &self,
        original_id: &str,
        schedule: Schedule,
        cohort: TrafficCohort,
        implicit_schedule: bool,
    ) {
        assert!(!original_id.is_empty(), "original identity is nonempty");
        let registered_at = (self.inner.clock)();
        let deadline = Arc::new(Deadline {
            original_id: original_id.into(),
            cohort,
            schedule: schedule.clone(),
            settled_ns: AtomicU64::new(0),
            breached: AtomicBool::new(false),
            notified: AtomicBool::new(false),
        });
        let evidence = Arc::new(Evidence {
            row: Mutex::new(Lifecycle {
                registered_at,
                implicit_schedule,
                offered_at: None,
                sent_at: None,
                server_registered_at: None,
                admitted_at: None,
                final_at: None,
                final_outcome: None,
                cancelled_at: None,
                finished_at: None,
            }),
            deadline: Arc::clone(&deadline),
        });
        let mut registry = self.inner.registry.lock().unwrap();
        assert!(
            !registry.rows.contains_key(original_id),
            "original schedule identity is unique"
        );
        assert!(
            registry.rows.len() < self.inner.maximum_originals,
            "declared schedule bound exceeded"
        );
        if let Schedule::Relative { offset, base } = &schedule {
            assert!(
                base.get().is_none(),
                "relative schedule is frozen before trial T0"
            );
            assert!(
                registry.receiver.is_some(),
                "register entire relative schedule before watch setup barrier"
            );
            registry.maximum_relative_offset = registry.maximum_relative_offset.max(*offset);
        }
        registry.latest_registration = registry.latest_registration.max(registered_at);
        registry.rows.insert(original_id.into(), evidence);
        // Send while serializing registrations so startup sees either an initial
        // immutable row or its queued registration. It cannot miss both.
        if registry.receiver.is_none() {
            self.inner
                .sender
                .send(Event::Registered(deadline))
                .expect("watchdog mailbox alive");
        }
        drop(registry);
        self.unpark();
    }

    fn evidence(&self, original_id: &str) -> Arc<Evidence> {
        Arc::clone(
            self.inner
                .registry
                .lock()
                .unwrap()
                .rows
                .get(original_id)
                .expect("original must already be scheduled"),
        )
    }

    pub fn offer(&self, original_id: &str) {
        // Retain the three old offer-only controls. Such rows are explicitly
        // flagged and rejected by assert_explicit_schedule() in normal trials.
        let exists = self
            .inner
            .registry
            .lock()
            .unwrap()
            .rows
            .contains_key(original_id);
        if !exists {
            self.register(
                original_id,
                Schedule::Absolute((self.inner.clock)()),
                TrafficCohort::SemanticWrite,
                true,
            );
        }
        let evidence = self.evidence(original_id);
        assert!(
            evidence.deadline.schedule.intended_at().is_some(),
            "T0 published before caller offer"
        );
        let mut row = evidence.row.lock().unwrap();
        assert!(row.finished_at.is_none(), "cannot offer a settled original");
        assert!(row.offered_at.is_none(), "original is offered once");
        row.offered_at = Some((self.inner.clock)());
    }

    pub fn sent(&self, original_id: &str) {
        let evidence = self.evidence(original_id);
        let mut row = evidence.row.lock().unwrap();
        assert!(row.offered_at.is_some(), "send follows actual offer");
        assert!(row.finished_at.is_none(), "cannot send a settled original");
        assert!(row.sent_at.is_none(), "original is sent once");
        row.sent_at = Some((self.inner.clock)());
    }

    /// Call only from an actual server-origin receipt correlated with this ID.
    pub fn server_registered(&self, original_id: &str) {
        self.server_registered_at(original_id, (self.inner.clock)());
    }

    /// Archive the actual registry boundary timestamp, not the later time at
    /// which the caller collected its correlated receipt.
    pub fn server_registered_at(&self, original_id: &str, observed_actual: Instant) {
        let evidence = self.evidence(original_id);
        let mut row = evidence.row.lock().unwrap();
        let sent_at = row.sent_at.expect("server receipt follows actual send");
        assert!(
            observed_actual >= sent_at,
            "server origin cannot precede actual send"
        );
        assert!(
            observed_actual <= (self.inner.clock)(),
            "actual server origin cannot be in the future"
        );
        if let Some(final_at) = row.final_at {
            assert!(
                observed_actual <= final_at,
                "server origin precedes final reply even when archived later"
            );
        }
        assert!(
            row.server_registered_at.is_none(),
            "one server origin per original"
        );
        row.server_registered_at = Some(observed_actual);
    }

    /// Separate actual admission evidence; a socket send is not admission.
    pub fn admitted(&self, original_id: &str) {
        self.admitted_at(original_id, (self.inner.clock)());
    }

    /// Archive the actual correlated admission timestamp from the registry.
    pub fn admitted_at(&self, original_id: &str, observed_actual: Instant) {
        let evidence = self.evidence(original_id);
        let mut row = evidence.row.lock().unwrap();
        let origin_at = row
            .server_registered_at
            .expect("admission has a real origin receipt");
        assert!(
            observed_actual >= origin_at,
            "actual admission cannot precede server origin"
        );
        assert!(
            observed_actual <= (self.inner.clock)(),
            "actual admission cannot be in the future"
        );
        if let Some(final_at) = row.final_at {
            assert!(
                observed_actual <= final_at,
                "actual admission precedes final reply even when archived later"
            );
        }
        assert!(row.admitted_at.is_none(), "original is admitted once");
        row.admitted_at = Some(observed_actual);
    }

    pub fn complete(&self, original_id: &str) {
        self.complete_with_outcome(original_id, FinalOutcome::Reply);
    }

    pub fn complete_with_outcome(&self, original_id: &str, outcome: FinalOutcome) {
        self.settle(original_id, Some(outcome));
    }

    pub fn cancel(&self, original_id: &str) {
        self.settle(original_id, None);
    }

    fn settle(&self, original_id: &str, outcome: Option<FinalOutcome>) {
        let evidence = self.evidence(original_id);
        let mut row = evidence.row.lock().unwrap();
        assert!(row.finished_at.is_none(), "original settles once");
        if outcome == Some(FinalOutcome::Reply) || outcome == Some(FinalOutcome::ProtocolError) {
            assert!(row.sent_at.is_some(), "a reply follows an actual send");
        }
        // Instrument immediately upon observing final encoded reply, failure,
        // or cancellation. Cancellation is failure evidence, never a success.
        let now = (self.inner.clock)();
        let encoded = encode_instant(self.inner.epoch, now);
        row.finished_at = Some(now);
        match outcome {
            Some(outcome) => {
                row.final_at = Some(now);
                row.final_outcome = Some(outcome);
            }
            None => {
                row.cancelled_at = Some(now);
            }
        }
        let intended_at = evidence
            .deadline
            .schedule
            .intended_at()
            .expect("T0 published before settlement");
        if now.saturating_duration_since(intended_at) > LIMIT {
            evidence.deadline.breached.store(true, Ordering::Release);
        }
        evidence
            .deadline
            .settled_ns
            .store(encoded, Ordering::Release);
        drop(row);
        if self.inner.registry.lock().unwrap().receiver.is_none() {
            self.inner
                .sender
                .send(Event::Settled(Arc::clone(&evidence.deadline)))
                .expect("watchdog mailbox alive");
        }
        self.unpark();
    }

    fn unpark(&self) {
        if let Some(thread) = self.inner.watchdog_thread.lock().unwrap().as_ref() {
            thread.unpark();
        }
    }

    /// Full archive, including future, unoffered, unsent, completed and cancelled
    /// originals. This deliberately scans all evidence only when requested.
    pub fn snapshot(&self) -> Vec<ClientRow> {
        self.snapshot_report().rows
    }

    /// Every active age in this report is capped with the same sampled instant.
    /// Per-event timestamps remain actual observations; never reinterpret this
    /// report's pending rows using a later Instant::now().
    pub fn snapshot_report(&self) -> ClientSnapshot {
        let now = (self.inner.clock)();
        let rows: Vec<_> = self
            .inner
            .registry
            .lock()
            .unwrap()
            .rows
            .values()
            .cloned()
            .collect();
        let rows = rows
            .into_iter()
            .map(|evidence| {
                let stored = evidence.row.lock().unwrap();
                let mut row = ClientRow {
                    original_id: evidence.deadline.original_id.clone(),
                    cohort: evidence.deadline.cohort,
                    intended_at: evidence
                        .deadline
                        .schedule
                        .intended_at()
                        .expect("snapshot relative evidence after T0"),
                    registered_at: stored.registered_at,
                    implicit_schedule: stored.implicit_schedule,
                    offered_at: stored.offered_at,
                    sent_at: stored.sent_at,
                    server_registered_at: stored.server_registered_at,
                    admitted_at: stored.admitted_at,
                    final_at: stored.final_at,
                    final_outcome: stored.final_outcome,
                    cancelled_at: stored.cancelled_at,
                    finished_at: stored.finished_at,
                    cancelled: stored.cancelled_at.is_some(),
                    breached: false,
                };
                drop(stored);
                if row.age_at(now) > LIMIT {
                    evidence.deadline.breached.store(true, Ordering::Release);
                }
                row.breached = evidence.deadline.breached.load(Ordering::Acquire);
                row
            })
            .collect();
        ClientSnapshot {
            sampled_at: now,
            rows,
        }
    }

    /// A transport demultiplexer must call this for unknown response IDs rather
    /// than silently dropping them or inventing a scheduled/server origin row.
    pub fn record_unmatched_reply(&self, original_id: &str) {
        self.inner
            .unmatched_replies
            .lock()
            .unwrap()
            .push(original_id.into());
    }

    /// Run after joined finite drain. Being below 5s is insufficient: every
    /// scheduled original needs an actual offer/send/final reply. Reads/exempt
    /// traffic do not require or fabricate semantic-write registry origins.
    pub fn reconcile_final(&self) -> FinalReconciliation {
        let snapshot = self.snapshot_report();
        let mut violations = Vec::new();
        for row in &snapshot.rows {
            let mut missing = Vec::new();
            if row.implicit_schedule {
                missing.push("explicit schedule");
            }
            if row.offered_at.is_none() {
                missing.push("actual offer");
            }
            if row.sent_at.is_none() {
                missing.push("actual send");
            }
            if row.cohort == TrafficCohort::SemanticWrite {
                if row.server_registered_at.is_none() {
                    missing.push("actual server origin");
                }
                if row.admitted_at.is_none() {
                    missing.push("actual admission");
                }
            }
            if row.final_at.is_none() {
                missing.push("final reply");
            }
            if row.final_outcome != Some(FinalOutcome::Reply) {
                missing.push("successful transport reply");
            }
            if row.cancelled {
                missing.push("uncancelled lifecycle");
            }
            if row.finished_at.is_none() {
                missing.push("settled lifecycle");
            }
            if row.breached {
                missing.push("deadline within 5 seconds");
            }
            if !missing.is_empty() {
                violations.push(format!("{}: {}", row.original_id, missing.join(", ")));
            }
        }
        for unmatched in self.inner.unmatched_replies.lock().unwrap().iter() {
            violations.push(format!("unmatched reply identity: {unmatched}"));
        }
        FinalReconciliation {
            sampled_at: snapshot.sampled_at,
            rows: snapshot.rows,
            violations,
        }
    }

    pub fn assert_explicit_schedule(&self) {
        let registry = self.inner.registry.lock().unwrap();
        for evidence in registry.rows.values() {
            let row = evidence.row.lock().unwrap();
            assert!(
                !row.implicit_schedule,
                "qualification requires registration before caller wake: {}",
                evidence.deadline.original_id
            );
            if let Some(intended_at) = evidence.deadline.schedule.intended_at() {
                assert!(
                    row.registered_at <= intended_at,
                    "schedule registered after intended due: {}",
                    evidence.deadline.original_id
                );
            }
        }
    }

    /// Every row remains in the immutable archive; rates use actual event times
    /// in [start, end), never intended counts as a substitute for offered work.
    pub fn counts_between(
        &self,
        start: Instant,
        end: Instant,
    ) -> BTreeMap<TrafficCohort, CohortCounts> {
        assert!(end >= start, "rate interval is ordered");
        let elapsed = end.duration_since(start);
        let mut counts = BTreeMap::from([
            (TrafficCohort::SemanticWrite, CohortCounts::new(elapsed)),
            (TrafficCohort::Read, CohortCounts::new(elapsed)),
            (TrafficCohort::Exempt, CohortCounts::new(elapsed)),
        ]);
        for row in self.snapshot() {
            let count = counts.get_mut(&row.cohort).unwrap();
            count.archived += 1;
            count.intended += usize::from(in_window(Some(row.intended_at), start, end));
            count.registered += usize::from(in_window(Some(row.registered_at), start, end));
            count.offered += usize::from(in_window(row.offered_at, start, end));
            count.sent += usize::from(in_window(row.sent_at, start, end));
            count.server_registered += usize::from(in_window(row.server_registered_at, start, end));
            count.admitted += usize::from(in_window(row.admitted_at, start, end));
            count.final_replies += usize::from(
                in_window(row.final_at, start, end)
                    && row.final_outcome == Some(FinalOutcome::Reply),
            );
            count.protocol_errors += usize::from(
                in_window(row.final_at, start, end)
                    && row.final_outcome == Some(FinalOutcome::ProtocolError),
            );
            count.transport_errors += usize::from(
                in_window(row.final_at, start, end)
                    && row.final_outcome == Some(FinalOutcome::TransportError),
            );
            count.cancelled += usize::from(in_window(row.cancelled_at, start, end));
            // These three are archive totals at snapshot, not interval rates.
            count.unfinished += usize::from(row.finished_at.is_none());
            count.breached += usize::from(row.breached);
            count.implicit_schedules += usize::from(row.implicit_schedule);
        }
        counts
    }

    /// One independent std thread; call and retain its guard before starting
    /// runtime callers. Initial schedule indexing is acknowledged synchronously.
    /// New registrations are supported but normal qualification freezes first.
    pub fn watch(&self) -> ClientWatchGuard {
        let (initial, receiver) = {
            let mut registry = self.inner.registry.lock().unwrap();
            let receiver = registry.receiver.take().expect("one watchdog per trial");
            let initial: Vec<_> = registry
                .rows
                .values()
                .map(|row| Arc::clone(&row.deadline))
                .collect();
            (initial, receiver)
        };
        let state = Arc::new(WatchState {
            stop: AtomicBool::new(false),
            failed: AtomicBool::new(false),
            polls: AtomicU64::new(0),
            inspected_deadlines: AtomicU64::new(0),
            indexed: AtomicU64::new(0),
            thread_finished: AtomicBool::new(false),
            observed: arc_swap::ArcSwap::from_pointee(imbl::OrdMap::new()),
            maximum_breaches: self.inner.maximum_originals,
        });
        let thread_state = Arc::clone(&state);
        let clock = Arc::clone(&self.inner.clock);
        let relative_base = Arc::clone(&self.inner.relative_base);
        let epoch = self.inner.epoch;
        let (breaches_tx, breaches_rx) = mpsc::channel();
        let (ready_tx, ready_rx) = mpsc::sync_channel(0);
        let handle = thread::Builder::new()
            .name("qualification-client-watch".into())
            .spawn(move || {
                let _exit = WatchExit(Arc::clone(&thread_state));
                let mut index = DeadlineIndex::default();
                for deadline in initial {
                    ingest_row(
                        &mut index,
                        deadline,
                        epoch,
                        clock(),
                        &thread_state,
                        &breaches_tx,
                    );
                }
                thread_state
                    .indexed
                    .store(index.len() as u64, Ordering::Release);
                ready_tx.send(()).expect("watchdog startup receiver alive");
                loop {
                    // Bounded mailbox work prevents continuous producers from
                    // starving deadline checks. No archive/future scan occurs.
                    let mut consumed = 0;
                    while consumed < MAILBOX_BATCH {
                        match receiver.try_recv() {
                            Ok(Event::Registered(row)) => ingest_row(
                                &mut index,
                                row,
                                epoch,
                                clock(),
                                &thread_state,
                                &breaches_tx,
                            ),
                            Ok(Event::Settled(row)) => {
                                index.remove(&row);
                                publish_breach(&row, epoch, clock(), &thread_state, &breaches_tx);
                            }
                            Err(mpsc::TryRecvError::Empty) => break,
                            Err(mpsc::TryRecvError::Disconnected) => break,
                        }
                        consumed += 1;
                    }
                    let now = clock();
                    while let Some(row) = index.pop_expired(now, relative_base.get().copied()) {
                        thread_state
                            .inspected_deadlines
                            .fetch_add(1, Ordering::Relaxed);
                        publish_breach(&row, epoch, now, &thread_state, &breaches_tx);
                    }
                    thread_state
                        .indexed
                        .store(index.len() as u64, Ordering::Release);
                    thread_state.polls.fetch_add(1, Ordering::Release);
                    if thread_state.stop.load(Ordering::Acquire) {
                        // The caller joins all producers/callers before requesting
                        // stop. Drain finite already queued events before exit.
                        if consumed < MAILBOX_BATCH {
                            break;
                        }
                        continue;
                    }
                    if consumed == MAILBOX_BATCH {
                        continue;
                    }
                    thread::park_timeout(POLL);
                }
            })
            .expect("spawn independent client watchdog");
        ready_rx
            .recv()
            .expect("watchdog indexed schedule before caller wake");
        *self.inner.watchdog_thread.lock().unwrap() = Some(handle.thread().clone());
        self.inner.ready.store(true, Ordering::Release);
        ClientWatchGuard {
            state,
            handle: Some(handle),
            breaches: breaches_rx,
        }
    }
}

pub(super) struct ClientSnapshot {
    pub sampled_at: Instant,
    pub rows: Vec<ClientRow>,
}

pub(super) struct ScheduledIdentity {
    pub cohort: TrafficCohort,
    /// None means the immutable relative schedule is registered but unreleased.
    pub intended_at: Option<Instant>,
}

pub(super) struct FinalReconciliation {
    pub sampled_at: Instant,
    pub rows: Vec<ClientRow>,
    pub violations: Vec<String>,
}

#[derive(Default)]
struct DeadlineIndex {
    absolute: BTreeMap<(Instant, String), Arc<Deadline>>,
    relative: BTreeMap<(Duration, String), Arc<Deadline>>,
}

impl DeadlineIndex {
    fn len(&self) -> usize {
        self.absolute.len() + self.relative.len()
    }

    fn insert(&mut self, row: Arc<Deadline>) {
        match row.schedule.deadline_key() {
            DeadlineKey::Absolute(at) => {
                self.absolute.insert((at, row.original_id.clone()), row);
            }
            DeadlineKey::Relative(offset) => {
                self.relative.insert((offset, row.original_id.clone()), row);
            }
        }
    }

    fn remove(&mut self, row: &Deadline) {
        match row.schedule.deadline_key() {
            DeadlineKey::Absolute(at) => {
                self.absolute.remove(&(at, row.original_id.clone()));
            }
            DeadlineKey::Relative(offset) => {
                self.relative.remove(&(offset, row.original_id.clone()));
            }
        }
    }

    fn pop_expired(
        &mut self,
        now: Instant,
        relative_base: Option<Instant>,
    ) -> Option<Arc<Deadline>> {
        if self
            .absolute
            .first_key_value()
            .is_some_and(|((at, _), _)| *at < now)
        {
            return self.absolute.pop_first().map(|(_, row)| row);
        }
        if let Some(base) = relative_base {
            let elapsed = now.saturating_duration_since(base);
            if self
                .relative
                .first_key_value()
                .is_some_and(|((offset, _), _)| *offset < elapsed)
            {
                return self.relative.pop_first().map(|(_, row)| row);
            }
        }
        None
    }
}

fn ingest_row(
    index: &mut DeadlineIndex,
    row: Arc<Deadline>,
    epoch: Instant,
    now: Instant,
    state: &WatchState,
    breaches: &mpsc::Sender<Breach>,
) {
    if row.settled_ns.load(Ordering::Acquire) == 0 {
        index.insert(row);
    } else {
        publish_breach(&row, epoch, now, state, breaches);
    }
}

fn encode_instant(epoch: Instant, at: Instant) -> u64 {
    u64::try_from(at.saturating_duration_since(epoch).as_nanos())
        .expect("trial timestamp fits u64 nanoseconds")
        .checked_add(1)
        .expect("trial terminal timestamp fits sentinel encoding")
}

fn publish_breach(
    row: &Deadline,
    epoch: Instant,
    now: Instant,
    state: &WatchState,
    breaches: &mpsc::Sender<Breach>,
) {
    let settled = row.settled_ns.load(Ordering::Acquire);
    let Some(intended_at) = row.schedule.intended_at() else {
        return; // Relative schedule is fully indexed but T0 is not released.
    };
    let observed_end = if settled == 0 {
        now
    } else {
        epoch
            .checked_add(Duration::from_nanos(settled - 1))
            .expect("stored terminal instant")
    };
    if row.breached.load(Ordering::Acquire)
        || observed_end.saturating_duration_since(intended_at) > LIMIT
    {
        row.breached.store(true, Ordering::Release);
        // Events are retained for evidence. Per-ID breached is sticky even if
        // the caller is cancelled or completes after this observation.
        if !row.notified.swap(true, Ordering::AcqRel) {
            let breach = Breach {
                original_id: row.original_id.clone(),
                cohort: row.cohort,
                intended_at,
                observed_at: now,
                settled_at: (settled != 0).then_some(observed_end),
            };
            let mut observed = (**state.observed.load()).clone();
            observed.insert(row.original_id.clone(), breach.clone());
            assert!(
                observed.len() <= state.maximum_breaches,
                "breach index bounded by registered original capacity"
            );
            state.observed.store(Arc::new(observed));
            let _ = breaches.send(breach);
        }
        state.failed.store(true, Ordering::Release);
    }
}

#[derive(Clone, Debug)]
pub(super) struct Breach {
    pub original_id: String,
    pub cohort: TrafficCohort,
    pub intended_at: Instant,
    pub observed_at: Instant,
    pub settled_at: Option<Instant>,
}

struct WatchState {
    stop: AtomicBool,
    failed: AtomicBool,
    polls: AtomicU64,
    inspected_deadlines: AtomicU64,
    indexed: AtomicU64,
    thread_finished: AtomicBool,
    observed: arc_swap::ArcSwap<imbl::OrdMap<String, Breach>>,
    maximum_breaches: usize,
}

struct WatchExit(Arc<WatchState>);
impl Drop for WatchExit {
    fn drop(&mut self) {
        if std::thread::panicking() || !self.0.stop.load(Ordering::Acquire) {
            self.0.failed.store(true, Ordering::Release);
        }
        self.0.thread_finished.store(true, Ordering::Release);
    }
}

/// IndependentProbe keeps this handle, never ClientWatch or its archive locks.
pub(super) struct ClientWatchObservation {
    state: Arc<WatchState>,
}

impl ClientWatchObservation {
    pub fn failed(&self) -> bool {
        self.state.failed.load(Ordering::Acquire)
            || (self.state.thread_finished.load(Ordering::Acquire)
                && !self.state.stop.load(Ordering::Acquire))
    }
    pub fn polls(&self) -> u64 {
        self.state.polls.load(Ordering::Acquire)
    }
    pub fn indexed(&self) -> u64 {
        self.state.indexed.load(Ordering::Acquire)
    }
    /// Immutable actual reported breaches, each with its own sampled observed_at.
    /// This does not drive deadlines or recompute ages at a later probe clock.
    pub fn breaches(&self) -> Arc<imbl::OrdMap<String, Breach>> {
        self.state.observed.load_full()
    }
}

pub(super) struct ClientWatchGuard {
    state: Arc<WatchState>,
    handle: Option<JoinHandle<()>>,
    breaches: mpsc::Receiver<Breach>,
}

#[derive(Debug)]
pub(super) struct WatchReport {
    pub failed: bool,
    pub panicked: bool,
    pub polls: u64,
    pub inspected_deadlines: u64,
    pub still_indexed: u64,
    pub breaches: Vec<Breach>,
}

impl ClientWatchGuard {
    pub fn observer(&self) -> Arc<ClientWatchObservation> {
        Arc::new(ClientWatchObservation {
            state: Arc::clone(&self.state),
        })
    }

    /// Keep the non-Sync receiver/guard in one control owner, outside the probe.
    /// Its sole additional thread waits for shutdown; it observes no deadlines.
    pub fn into_lifecycle(self) -> ClientWatchLifecycle {
        let observer = self.observer();
        let finish = Arc::new(AtomicBool::new(false));
        let report = Arc::new(OnceLock::new());
        let requested = Arc::clone(&finish);
        let completed = Arc::clone(&report);
        let thread = thread::Builder::new()
            .name("qualification-watch-owner".into())
            .spawn(move || {
                while !requested.load(Ordering::Acquire) {
                    thread::park();
                }
                let _ = completed.set(Arc::new(self.finish()));
            })
            .expect("spawn client-watch lifecycle owner");
        ClientWatchLifecycle {
            observer,
            finish,
            report,
            thread: Some(thread),
        }
    }
    pub fn failed(&self) -> bool {
        self.state.failed.load(Ordering::Acquire)
            || self.handle.as_ref().is_some_and(JoinHandle::is_finished)
    }

    pub fn polls(&self) -> u64 {
        self.state.polls.load(Ordering::Acquire)
    }

    /// Retain all per-ID rows separately via ClientWatch::snapshot(). Join all
    /// callers first, finish this guard second, archive snapshot last. An early
    /// failure stops new offers; it does not convert accepted writes to success.
    pub fn finish(mut self) -> WatchReport {
        let panicked = self.stop_and_join();
        WatchReport {
            failed: panicked || self.state.failed.load(Ordering::Acquire),
            panicked,
            polls: self.state.polls.load(Ordering::Acquire),
            inspected_deadlines: self.state.inspected_deadlines.load(Ordering::Acquire),
            still_indexed: self.state.indexed.load(Ordering::Acquire),
            breaches: self.breaches.try_iter().collect(),
        }
    }

    fn stop_and_join(&mut self) -> bool {
        self.state.stop.store(true, Ordering::Release);
        if let Some(handle) = self.handle.take() {
            handle.thread().unpark();
            handle.join().is_err()
        } else {
            false
        }
    }
}

/// Retain through backend shutdown. Probe only clones observer(); it never
/// accesses the controller/guard. Drop is cleanup, not passing evidence.
pub(super) struct ClientWatchLifecycle {
    observer: Arc<ClientWatchObservation>,
    finish: Arc<AtomicBool>,
    report: Arc<OnceLock<Arc<WatchReport>>>,
    thread: Option<JoinHandle<()>>,
}

impl ClientWatchLifecycle {
    pub fn observer(&self) -> Arc<ClientWatchObservation> {
        Arc::clone(&self.observer)
    }
    pub fn request_finish(&self) {
        self.finish.store(true, Ordering::Release);
        if let Some(thread) = &self.thread {
            thread.thread().unpark();
        }
    }
    pub fn report(&self) -> Option<Arc<WatchReport>> {
        self.report.get().cloned()
    }
    pub fn is_finished(&self) -> bool {
        self.thread.as_ref().is_some_and(JoinHandle::is_finished)
    }
}

impl Drop for ClientWatchLifecycle {
    fn drop(&mut self) {
        self.request_finish();
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

impl Drop for ClientWatchGuard {
    fn drop(&mut self) {
        // Normal qualification must call finish() and assert its report. Drop
        // is only panic/cleanup containment; it makes no qualification claim.
        self.stop_and_join();
    }
}

fn in_window(at: Option<Instant>, start: Instant, end: Instant) -> bool {
    at.is_some_and(|at| at >= start && at < end)
}

#[derive(Clone, Debug, Default)]
pub(super) struct CohortCounts {
    pub elapsed: Duration,
    pub archived: usize,
    pub intended: usize,
    pub registered: usize,
    pub offered: usize,
    pub sent: usize,
    pub server_registered: usize,
    pub admitted: usize,
    pub final_replies: usize,
    pub protocol_errors: usize,
    pub transport_errors: usize,
    pub cancelled: usize,
    pub unfinished: usize,
    pub breached: usize,
    pub implicit_schedules: usize,
}

impl CohortCounts {
    fn new(elapsed: Duration) -> Self {
        Self {
            elapsed,
            ..Self::default()
        }
    }

    pub fn actual_rate(&self, event_count: usize) -> Option<f64> {
        (!self.elapsed.is_zero()).then(|| event_count as f64 / self.elapsed.as_secs_f64())
    }
}
