ClientWatch implementation and integration controls (not run)
===========================================================

The sibling Rust file is an off-source, std-only implementation draft. No
compile, test, timing run, or qualification claim accompanies it. Keep the four
existing tracked controls verbatim when materializing it. The new intended-due
control should become GREEN through this implementation, after its recorded RED.

Required driver integration
---------------------------

1. Construct with `ClientWatch::new(Arc::new(Instant::now))`, or use
   `with_maximum_originals` with the full declared schedule bound. Register all
   semantic, read, and exempt IDs using `register_relative_at(id, offset,
   cohort)`. Offsets are immutable and allocation/indexing are setup work.
2. Start and retain `let guard = watch.watch()`. This returns only after the std
   thread has indexed every registered schedule entry. Relative registration
   after this barrier is rejected. No 30-second lead or later due-time reset is
   required. Call `watch.start_at(Instant::now())` once and release callers.
3. At the scheduler's actual due-time wake, call `offer(id)` before any credit
   acquisition, socket establishment, or stream/transport wait. Never defer
   registration or move the intended offset to match a delayed wake.
4. Call `sent(id)` at the actual send boundary. Each real MCP request still uses
   its fresh one-request socket; this helper does not choose transport lifetime
   or supply writer credits. Keep the shared two-credit-per-Coding-identity
   constraint in the driver. Record actual credit wait start/end there; do not
   label the whole offer-to-send interval as pure credit wait.
5. Only real correlated server intake/admission receipts may call
   `server_registered_at(id, actual_intake)` / `admitted_at(id, actual_admission)`.
   These timestamps may be archived after final reply; the values must preserve
   actual send <= intake <= admission <= final reply, and cannot be in the future.
   `server_registered(id)` / `admitted(id)` remain convenience helpers only for
   instrumentation invoked directly at the actual boundary. Never manufacture these events
   after a successful reply. Read and exempt cohorts do not need a semantic
   write registry row. Out-of-order receipt observation is not proof of actual
   intake time: attach the real instrumentation at its declared boundary.
6. Record the final encoded response immediately with `complete(id)`, or use
   `complete_with_outcome` for protocol/transport error terminals. A reply alone
   does not prove a durable write or successful effect; retain recipe-specific
   effect/accepted-job assertions. Route unknown reply IDs through
   `record_unmatched_reply(id)` and fail transport correlation.
7. While work is active, check `guard.failed()` and watchdog liveness/polls from
   the controller. On failure stop new offers and preserve all intended IDs;
   drain finite accepted work under the separate outer cleanup deadline. Do not
   cancel accepted work at 5 seconds to call it successful.
8. Join callers/producers, call `guard.finish()`, require no panic/failure, retain
   its report, and call `reconcile_final()`. Every cancelled, errored, unoffered,
   unsent, unfinished, unmatched, or missing semantic origin/admission is a final
   failure even if it has not yet aged beyond 5 seconds. Archive all rows. Call
   `counts_between(T0, T0 + 600 seconds)` for actual event counts and rates;
   intended count is not the offered count. Never merge read/exempt counts into
   semantic write rates. Archive totals are named separately from interval
   counts, and a zero-duration interval has no numerical rate.

The compatibility `offer` enrollment path exists solely for the three original
offer-only controls. It is explicitly marked `implicit_schedule` and rejected
by `assert_explicit_schedule()` and final reconciliation in normal trials.
Absolute `register_at` remains available for the four manual-clock controls.

New focused controls to implement before claiming integration
-----------------------------------------------------------

Use an atomic manual clock (`base + AtomicU64 nanoseconds`) in watcher controls;
never a clock closure that needs the intentionally held registry/lifecycle lock.
Use handshakes and bounded waits for std-thread progression, not assumed sleeps.

* Intended schedule and boundary: retain the current four controls. Verify due
  + exactly 5 seconds remains inclusive, due + 5 seconds + 1 nanosecond fails,
  and future due age clamps to zero. A late offer/send preserves the same due.
* Setup barrier: preregister 24,000 semantic, approximately 59,000 read and
  60,000 exempt offsets while advancing the setup clock substantially. Start
  watch, choose T0 only after its acknowledgement, and publish once. None is
  overdue because setup took time. A delayed post-T0 scheduler wake is overdue
  without offer, send, or server registration. A second T0 and late relative
  registration must fail, and the first immutable offsets must remain intact.
* Independent observation: on one thread retain the driver registry lock;
  separately retain an individual Lifecycle lock and a synthetic AppState lock.
  Advance the atomic clock past an unoffered original deadline. Verify the
  already-running std watchdog latches failure and identifies that ID while all
  those locks remain held. Release locks and join. This is stronger than a
  completed-only snapshot assertion.
* Tokio starvation: on a one-worker runtime occupy the executor with a bounded
  independent blocking-control handshake. The std watchdog must still fail the
  immutable pending ID. Do not claim this proves production backend integration.
* Active index bound: preregister a large future schedule and completed archive,
  with only a few active due rows. Across bounded poll handshakes verify future
  rows are not inspected, completed rows leave the index, and expired active
  IDs are retained as breaches. Counters are corroborating evidence; inspect
  the actual ordered-index path to exclude archive scans.
* Sticky settlement: make the watchdog detect an overdue original, then offer,
  send, complete or cancel it. It stays failed and retains original due and all
  actual event times. A late terminal without any watchdog poll also fails.
  Timely completion inspected later must not become late merely because the
  watchdog's current time is later. No duplicate per-ID breach events.
* Credit delay: hold both real caller credits and allow a third immutable due
  slot to reach its actual offer boundary. Before it acquires a credit or socket,
  advance past 5 seconds; the watcher must fail it. Releasing a credit, sending,
  and receiving a reply cannot erase the original deadline or the failure. Also
  verify a <=5-second delay passes only when final lifecycle/effect proofs pass.
* Separate cohorts and rates: register/write/send/complete different known counts
  in all three cohorts, including events exactly at T0 and T0 + 600 seconds.
  Verify [start,end) interval semantics, no semantic inflation by read/exempt
  traffic, future intended rows are not actual offers, and zero-duration rate is
  None. Credit wait counts come from explicit driver events, never subtraction.
* Lifecycle reconciliation: cancel a young row, leave one young row never
  offered, another offered but never sent, omit a semantic server receipt,
  receive a protocol/transport error, and report an unmatched response ID.
  All must fail final reconciliation even where breached is false. Successful
  read/exempt rows must not need fabricated semantic registry admissions.
* Identity safety: duplicate registration (including cross-cohort reuse), double
  offer/send/origin/admission/final/cancel, completion of an unknown ID, and a
  reply before send must fail rather than increment a second logical request.
  These are intentional invalid fixtures; do not catch their panic and treat
  the qualification trial as successful. Archive valid rows before injecting
  invalid fixtures if a panic poisons their local evidence mutex.
* Delayed receipt archival: complete a reply at t=4 seconds, then at t=8 seconds
  archive actual intake at t=1 second and actual admission at t=2 seconds. The
  row must retain those actual boundaries rather than t=8. Reject intake before
  send, admission before intake, either boundary after actual final reply, a
  future boundary, and repeated boundary registration. Convenience helpers at
  the actual boundary retain the same ordering rules. No final-encoding observer
  is added; adapters still record actual send and final decode immediately.
* One sampled report: hold a report at a sampled instant, then advance the clock
  without taking another sample. Reusing that report must not make a formerly
  young active request older; use its sampled_at when interpreting ages. A
  later report may fail. A future terminal timestamp is capped at sampled_at
  when computing active age; preserve the actual timestamp as separate evidence.
* Watcher health: deliberate independent thread panic must surface as failure
  through guard.failed()/finish(). Require a progressing poll heartbeat during
  integration. Guard Drop only performs cleanup; it is not passing evidence.

Real integration gates still required
------------------------------------

Add a short actual encrypted one-request MCP request that proves final reply and
real server receipt correlation, an actual admission-blocked/credit-delayed
negative control, and actual read/exempt traffic with separate rates. Capture
one sampled server registry snapshot alongside client evidence. Do not reevaluate
the server snapshot's already end-capped intervals with a later clock value.
The four existing unit controls plus this draft are insufficient to certify
these wire, credit, service, watchdog-independence, or long-trial obligations.
