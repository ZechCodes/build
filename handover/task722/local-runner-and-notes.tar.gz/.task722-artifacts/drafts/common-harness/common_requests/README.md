# Common request mapping split

OFFSOURCE mechanical decomposition only. No source copy/build/parser/formatter/lint/test/runtime was performed. `manifest.json` lists the11 implementation files; keep the mode444 original under archive as provenance only.

The public models and SavedEffect enum are byte-preserved from c970f6abc68b. Public build_common_requests, CommonRequest::method and CommonRequest::verify_saved signatures are unchanged. Root registers model/builder/verify; builder children separate SPAstate/MCPstate/finite mapping and target/slot/chain validation; verifier children separate finite/state/message checks. Every native branch remains a real saved-value assertion. Static text inventory preserves30 original native/error literals and the exact missing immutable moved-event error. This is not compiler/runtime equivalence evidence.

The same24000 sorted immutable semantic slots drive the same task-status/revision/ref counters. Only FS per-file and Git per-root predecessor chains exist. No state/burst ordering or extra FS/Git dependency was introduced. Durable operation IDs and full original IDs retain their existing separate values. Models still distinguish thread generation from canonical conversation address.

TaskVersion with no actual matching Moved event still returns the original explicit pending-proof error. No accepted Noop waiver, fake installed record, expected-value echo, latest-state replacement, ordering or repair operation was added. The future accepted-record integration remains separate.

The old too_many_arguments allowance is gone. Message checks use an address plus a message-expectation struct and retain exact body/role/operation/from-agent assertions. Builder match dispatch, target validation, task/native state checks and message verification are decomposed into helpers intended to stay below complexity15; actual Clippy validation still requires the reviewed source window.
