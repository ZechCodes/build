//! OFF-SOURCE concrete common-write request mapping and native effect checks.
//! Builds requests only; never dispatches/prepares a file/ref per operation.
//! Strong saved evidence must be extracted from the real Store/thread/session
//! log/libgit checkout. An expected value echoed as saved evidence is invalid.
use super::trial_complete::{Envelope, OracleAssertion, OracleWitness, Route, Slot, Traffic, TrialName, WitnessScalar, WriteClass};
use crate::mcp::BridgeAction;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use std::path::PathBuf;

#[derive(Clone, Debug)]
pub struct ActiveTarget {
    pub owner: String,
    pub agent: String,
    pub thread: String, // actual agent.thread.id generation guard
    pub conversation: String, // actual agent.conversation_id(), Store address
    pub workspace: String,
    pub source: String,
    pub path: PathBuf,
    pub project: usize,
}
#[derive(Clone, Debug)]
pub struct ProjectTarget {
    pub project_id: String,
    // ROOT APPROVED: two preexisting ordinary cards, selected by sibling0/1.
    // Neither is one of the reserved read-witness tasks. No new cards seeded.
    pub ordinary_tasks: [String; 2],
}
#[derive(Clone, Debug)]
pub struct RootGitRefs {
    // Created and verified BEFORE timing. Both point to initial_commit and
    // each ref is unique across all eight roots (including linked worktrees).
    pub full_refs: [String; 2],
    pub initial_commit: String,
    pub initial_head_ref: String,
}
#[derive(Clone, Debug)]
pub struct CommonTargets {
    pub active: [ActiveTarget; 8],
    pub projects: [ProjectTarget; 4],
    pub git: [RootGitRefs; 8],
    // Actual seeded editor bytes, verified during setup. No timed fs.read.
    pub initial_editor_bodies: [Vec<u8>; 8],
    pub reserved_read_tasks: BTreeSet<String>,
}
#[derive(Clone, Debug)]
pub enum ActualRequest {
    Rpc { method: &'static str, params: Value },
    Mcp { agent: String, action: BridgeAction },
}
#[derive(Clone, Debug)]
pub enum ActorExpectation { User, Agent(String) }
#[derive(Clone, Debug)]
pub enum ExpectedEffect {
    Posted { owner: String, agent: String, thread: String, body: String, role: &'static str, operation_id: Option<String> },
    Seen { owner: String, agent: String, thread: String },
    UserPresent,
    TaskStatus { task: String, status: String, actor: ActorExpectation },
    Comment { task: String, body: String, actor: ActorExpectation },
    Topic { owner: String, agent: String, topic: String },
    Name { owner: String, agent: String, name: String },
    Handoff { caller: String, recipient_owner: String, recipient: String, thread: String, body: String },
    File { owner: usize, path: PathBuf, bytes: Vec<u8>, revision: String },
    GitHead { owner: usize, directory: PathBuf, full_ref: String, commit: String },
}
#[derive(Clone, Debug)]
pub struct CommonRequest {
    pub original_id: String,
    pub caller: usize,
    pub owner: usize,
    pub request: ActualRequest,
    pub effect: ExpectedEffect,
    pub durable_operation_id: Option<String>,
    // Only approved true dependencies: per-file FS and per-root Git chains.
    // State slots, including all eight same-owner burst slots, have NONE.
    pub predecessor: Option<String>,
    pub finite_target_us: Option<u64>,
    pub finite_ceiling_us: Option<u64>,
}
fn sha256(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn body(kind: &str, original: &str) -> Result<String, String> {
    let value = format!("Qualification {kind} for {original}: retain this exact durable effect and original identity.");
    if !(64..=256).contains(&value.len()) { return Err("common payload must remain64..256 UTF8 bytes".into()); }
    Ok(value)
}
fn file_scope(target: &ActiveTarget) -> Value {
    json!({"workspace_id":target.workspace,"source_id":target.source,"entity_id":target.owner})
}
fn task_for_owner(targets: &CommonTargets, owner: usize) -> String {
    let target = &targets.active[owner];
    let siblings = targets.active.iter().enumerate().filter(|(_, candidate)| candidate.project == target.project).map(|(index, _)| index).collect::<Vec<_>>();
    let position = siblings.iter().position(|index| *index == owner).unwrap();
    targets.projects[target.project].ordinary_tasks[position].clone()
}
pub fn build_common_requests(trial: TrialName, targets: &CommonTargets, immutable_plan: &[Slot]) -> Result<BTreeMap<String, CommonRequest>, String> {
    validate_targets(targets)?;
    let mut writes = immutable_plan.iter().filter(|slot| slot.traffic == Traffic::Write).collect::<Vec<_>>();
    writes.sort_by_key(|slot| (slot.due_us, slot.sequence));
    if writes.len() != 24_000 { return Err("exact24000 immutable semantic slots required".into()); }
    let mut last_file: [Option<String>; 8] = std::array::from_fn(|_| None);
    let mut last_git: [Option<String>; 8] = std::array::from_fn(|_| None);
    let mut file_revision: [String; 8] = std::array::from_fn(|i| sha256(&targets.initial_editor_bodies[i]));
    let mut git_sequence = [0_usize; 8];
    let mut task_status = [0_usize; 8];
    let mut mapped = BTreeMap::new();
    for slot in writes {
        let id = slot.original_id.clone(); let owner = slot.owner;
        if owner >= 8 || slot.caller >= 12 { return Err(format!("invalid write caller/owner for {id}")); }
        if slot.route == Route::SpaRpc && slot.caller >= 4 { return Err("SPA common request must use one of four actual openings".into()); }
        let target = &targets.active[owner];
        if slot.route == Route::AgentMcp && (slot.caller < 4 || slot.caller - 4 != owner) { return Err("Coding caller cannot switch to another owner's identity".into()); }
        let task = task_for_owner(targets, owner);
        let second = slot.sequence / 40; let position = slot.sequence % 40;
        let mut predecessor = None;
        let mut durable_operation_id = None;
        let (request, effect) = match slot.class {
            Some(WriteClass::State) if slot.route == Route::SpaRpc => {
                match (second * 8 + position) % 5 {
                    0 => {
                        let text = body("SPA post", &id)?;
                        let operation = format!("qual.{}.trial{}.write.{:05}", match trial.envelope { Envelope::Small => "small", Envelope::Large => "large" }, trial.number, slot.sequence);
                        if !operation.bytes().all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.' | b':')) { return Err("invalid durable operation_id syntax".into()); }
                        durable_operation_id = Some(operation.clone());
                        (ActualRequest::Rpc { method: "thread.post", params: json!({"entity_id":target.owner,"agent_id":target.agent,"thread_id":target.thread,"conversation_id":target.conversation,"operation_id":operation,"body":text,"interrupt":false}) },
                         ExpectedEffect::Posted { owner: target.owner.clone(), agent: target.agent.clone(), thread: target.conversation.clone(), body: text, role: "user", operation_id: Some(operation) })
                    }
                    1 => (ActualRequest::Rpc { method: "entity.seen", params: json!({"entity_id":target.owner,"agent_id":target.agent,"thread_id":target.thread,"conversation_id":target.conversation}) }, ExpectedEffect::Seen { owner: target.owner.clone(), agent: target.agent.clone(), thread: target.conversation.clone() }),
                    2 => (ActualRequest::Rpc { method: "user.present", params: json!({}) }, ExpectedEffect::UserPresent),
                    3 => {
                        let text = body("SPA comment", &id)?;
                        (ActualRequest::Rpc { method: "tasks.comment", params: json!({"task_id":task,"body":text}) }, ExpectedEffect::Comment { task, body: text, actor: ActorExpectation::User })
                    }
                    _ => {
                        let status = if task_status[owner] % 2 == 0 { "in_progress" } else { "backlog" }.to_string(); task_status[owner] += 1;
                        (ActualRequest::Rpc { method: "tasks.update", params: json!({"task_id":task,"status":status}) }, ExpectedEffect::TaskStatus { task, status, actor: ActorExpectation::User })
                    }
                }
            }
            Some(WriteClass::State) if slot.route == Route::AgentMcp => {
                match (second + position - 8) % 6 {
                    0 => {
                        let topic = format!("Qualify waits {}", slot.sequence);
                        (ActualRequest::Mcp { agent: target.agent.clone(), action: BridgeAction::SetTopic { topic: topic.clone() } }, ExpectedEffect::Topic { owner: target.owner.clone(), agent: target.agent.clone(), topic })
                    }
                    1 => {
                        let name = format!("Qualifier Q{owner}{}", slot.sequence);
                        (ActualRequest::Mcp { agent: target.agent.clone(), action: BridgeAction::SetName { name: name.clone() } }, ExpectedEffect::Name { owner: target.owner.clone(), agent: target.agent.clone(), name })
                    }
                    2 => {
                        let status = if task_status[owner] % 2 == 0 { "in_progress" } else { "backlog" }.to_string(); task_status[owner] += 1;
                        (ActualRequest::Mcp { agent: target.agent.clone(), action: BridgeAction::TrackerMoveTask { task_id: task.clone(), status: status.clone(), track: Some(false) } }, ExpectedEffect::TaskStatus { task, status, actor: ActorExpectation::Agent(target.agent.clone()) })
                    }
                    3 => {
                        let text = body("MCP comment", &id)?;
                        (ActualRequest::Mcp { agent: target.agent.clone(), action: BridgeAction::TrackerCommentTask { task_id: task.clone(), body: text.clone(), attachments: Vec::new(), refs: Vec::new(), track: Some(false), notify_user: Some(false), mention_user: Some(false) } }, ExpectedEffect::Comment { task, body: text, actor: ActorExpectation::Agent(target.agent.clone()) })
                    }
                    4 => {
                        let text = body("MCP post", &id)?;
                        (ActualRequest::Mcp { agent: target.agent.clone(), action: BridgeAction::PostThreadMessage { still_working: true, body: text.clone(), options: Vec::new(), attachments: Vec::new() } }, ExpectedEffect::Posted { owner: target.owner.clone(), agent: target.agent.clone(), thread: target.conversation.clone(), body: text, role: "agent", operation_id: None })
                    }
                    _ => {
                        let sibling = targets.active.iter().find(|candidate| candidate.project == target.project && candidate.agent != target.agent).ok_or("same-project live sibling missing")?;
                        let text = body("MCP handoff", &id)?;
                        (ActualRequest::Mcp { agent: target.agent.clone(), action: BridgeAction::MessageAgent { agent_id: sibling.agent.clone(), body: text.clone(), attachments: Vec::new() } }, ExpectedEffect::Handoff { caller: target.agent.clone(), recipient_owner: sibling.owner.clone(), recipient: sibling.agent.clone(), thread: sibling.conversation.clone(), body: text })
                    }
                }
            }
            Some(WriteClass::FilesystemProcess) if slot.route == Route::SpaRpc => {
                predecessor = last_file[owner].replace(id.clone());
                let bytes = body("finite filesystem edit", &id)?.into_bytes();
                let revision = sha256(&bytes);
                let mut params = file_scope(target);
                params["path"] = json!("qualified-editor.txt"); params["expected_revision"] = json!(file_revision[owner]); params["content_b64"] = json!(crate::encoding::b64encode(&bytes));
                // This is the planned successful-chain revision. A predecessor
                // failure blocks dependents; it NEVER rereads/retries/repairs.
                file_revision[owner] = revision.clone();
                (ActualRequest::Rpc { method: "fs.write", params }, ExpectedEffect::File { owner, path: target.path.join("qualified-editor.txt"), bytes, revision })
            }
            Some(WriteClass::GitProvider) if slot.route == Route::SpaRpc => {
                predecessor = last_git[owner].replace(id.clone());
                let full_ref = targets.git[owner].full_refs[git_sequence[owner] % 2].clone(); git_sequence[owner] += 1;
                let mut params = file_scope(target); params["full_ref"] = json!(full_ref);
                (ActualRequest::Rpc { method: "git.checkout_ref", params }, ExpectedEffect::GitHead { owner, directory: target.path.clone(), full_ref, commit: targets.git[owner].initial_commit.clone() })
            }
            _ => return Err(format!("unsupported exact common slot {id}")),
        };
        let item = CommonRequest { original_id: id.clone(), caller: slot.caller, owner, request, effect, durable_operation_id, predecessor, finite_target_us: slot.finite_target_us, finite_ceiling_us: slot.finite_ceiling_us };
        if mapped.insert(id.clone(), item).is_some() { return Err(format!("duplicate original {id}")); }
    }
    // State FIFO is not introduced for oracle convenience. In particular all
    //8owner0 burst writes preserve their same due time and four×two credits.
    if mapped.values().any(|request| request.predecessor.is_some() && !matches!(request.effect, ExpectedEffect::File { .. } | ExpectedEffect::GitHead { .. })) { return Err("unexpected state predecessor serialization".into()); }
    Ok(mapped)
}

fn validate_targets(targets: &CommonTargets) -> Result<(), String> {
    let mut refs = BTreeSet::new(); let mut agents = BTreeSet::new(); let mut directories = BTreeSet::new();
    for (owner, target) in targets.active.iter().enumerate() {
        if target.project >= 4 || target.owner.is_empty() || target.agent.is_empty() || target.thread.is_empty() || target.conversation.is_empty() || target.workspace.is_empty() || target.source.is_empty() || !target.path.is_absolute() || !agents.insert(&target.agent) || !directories.insert(&target.path) { return Err("eight distinct real native targets required".into()); }
        let git = &targets.git[owner];
        if git.initial_commit.is_empty() || git.initial_head_ref.is_empty() || git.full_refs.iter().any(|reference| !reference.starts_with("refs/heads/") || reference == &git.initial_head_ref || !refs.insert(reference)) { return Err("sixteen unique precreated branches with original commit and distinct starting HEAD required".into()); }
    }
    for project in 0..4 {
        if targets.active.iter().filter(|target| target.project == project).count() != 2 { return Err("two active owners per project required".into()); }
        let cards = &targets.projects[project].ordinary_tasks;
        if targets.projects[project].project_id.is_empty() || cards[0] == cards[1] || cards.iter().any(|task| task.is_empty() || targets.reserved_read_tasks.contains(task)) { return Err("two ordinary existing tasks/project must exclude reserved read witnesses".into()); }
    }
    Ok(())
}

/// Ephemeral witnesses loaded from REAL native storage/logs. They are consumed
/// by verify_saved and reduced to bounded typed evidence, never retained whole.
pub enum SavedEffect {
    Message { owner: String, agent: String, thread: String, item: Value, operation_status: Option<String>, matched_actual_session_turn: Option<String>, mandatory_children_complete: bool },
    Seen { owner: String, agent: String, thread: String, persisted_through: u64, published_through: u64, actual_read_target_through: u64 },
    UserSession { persisted: crate::session_summary::UserSession, invocation_start_ms: i64, decoded_final_ms: i64 },
    TaskVersion { saved: crate::tracker::Task, moved_event: Option<crate::tracker::TaskEvent> },
    Comment(crate::tracker::TaskComment),
    Agent { owner: String, saved: crate::agent::Agent },
    File { actual_path: PathBuf, actual_bytes: Vec<u8> },
    GitHead { actual_directory: PathBuf, actual_symbolic_head: String, actual_commit: String },
}
fn ensure(condition: bool, message: &str) -> Result<(), String> { if condition { Ok(()) } else { Err(message.into()) } }
fn actor_matches(actual: &crate::tracker::Actor, expected: &ActorExpectation) -> bool {
    match expected { ActorExpectation::User => matches!(actual, crate::tracker::Actor::User), ActorExpectation::Agent(agent) => actual.agent_id() == Some(agent.as_str()) }
}
fn assertion(field: &str, value: WitnessScalar) -> OracleAssertion { OracleAssertion { field: field.into(), actual: value.clone(), expected: value } }
impl CommonRequest {
    pub fn method(&self) -> &'static str { match &self.request { ActualRequest::Rpc { method, .. } => *method, ActualRequest::Mcp { action, .. } => action.tool_name() } }
    pub fn verify_saved(&self, decoded: &Value, actual: SavedEffect) -> Result<OracleWitness, String> {
        ensure(decoded.get("error").is_none_or(Value::is_null) && decoded.get("ok").and_then(Value::as_bool) != Some(false), "actual RPC/MCP returned an error")?;
        let result = decoded.get("result").ok_or("actual final response has no result")?;
        let mut fields = Vec::new();
        match (&self.effect, actual) {
            (ExpectedEffect::File { path, bytes, revision, .. }, SavedEffect::File { actual_path, actual_bytes }) => {
                ensure(path == &actual_path && bytes == &actual_bytes, "actual filesystem bytes/path differ")?;
                ensure(result["revision"].as_str() == Some(revision) && result["size"].as_u64() == Some(bytes.len() as u64) && result["content_b64"].as_str() == Some(crate::encoding::b64encode(bytes).as_str()), "actual fs.write reply revision/size/content differs")?;
                ensure(&sha256(&actual_bytes) == revision, "actual written revision differs")?;
                return Ok(OracleWitness::File { oracle: "actual-file-bytes+returned-revision".into(), path_suffix: "qualified-editor.txt".into(), bytes: bytes.len() as u64, sha256: revision.clone() });
            }
            (ExpectedEffect::GitHead { directory, full_ref, commit, .. }, SavedEffect::GitHead { actual_directory, actual_symbolic_head, actual_commit }) => {
                ensure(directory == &actual_directory && full_ref == &actual_symbolic_head && commit == &actual_commit, "actual libgit symbolic HEAD/commit differs")?;
                fields.push(assertion("actual_symbolic_head", WitnessScalar::Text(actual_symbolic_head))); fields.push(assertion("actual_commit", WitnessScalar::Text(actual_commit)));
            }
            (ExpectedEffect::Comment { task, body, actor }, SavedEffect::Comment(saved)) => {
                ensure(saved.task_id == *task && saved.body == *body && actor_matches(&saved.author, actor), "actual saved comment task/body/actor differs")?;
                ensure(result["comment"]["id"].as_str() == Some(saved.id.as_str()) && result["comment"]["body"].as_str() == Some(body), "returned exact comment ID/body differs from saved comment")?;
                fields.push(assertion("saved_comment_id", WitnessScalar::Text(saved.id))); fields.push(assertion("saved_comment_body", WitnessScalar::Text(saved.body)));
            }
            (ExpectedEffect::TaskStatus { task, status, actor }, SavedEffect::TaskVersion { saved, moved_event }) => {
                ensure(saved.id == *task && saved.status == *status && result["task"]["id"].as_str() == Some(task) && result["task"]["status"].as_str() == Some(status) && result["task"]["updated_at"].as_str() == Some(saved.updated_at.as_str()), "actual saved task VERSION must match exact returned ID/status/update version; latest overwritten task is insufficient")?;
                if let Some(event) = moved_event {
                    ensure(event.task_id == *task && event.kind == crate::tracker::TaskEventKind::Moved && actor_matches(&event.actor, actor) && event.payload["to"].as_str() == Some(status) && event.at == saved.updated_at, "immutable saved moved event does not prove returned task version")?;
                    fields.push(assertion("saved_move_event_id", WitnessScalar::Text(event.id)));
                } else { return Err("no immutable matching move event: retain explicit no-op/proof-gap evidence; do not add ordering or a replacement mutation".into()); }
                fields.push(assertion("saved_status", WitnessScalar::Text(saved.status))); fields.push(assertion("saved_updated_at", WitnessScalar::Text(saved.updated_at)));
            }
            (ExpectedEffect::Topic { owner, agent, topic }, SavedEffect::Agent { owner: saved_owner, saved }) => {
                ensure(owner == &saved_owner && agent == &saved.id && saved.topic.as_deref() == Some(topic), "actual saved agent topic differs")?;
                fields.push(assertion("saved_agent_id", WitnessScalar::Text(saved.id))); fields.push(assertion("saved_topic", WitnessScalar::Text(topic.clone())));
            }
            (ExpectedEffect::Name { owner, agent, name }, SavedEffect::Agent { owner: saved_owner, saved }) => {
                ensure(owner == &saved_owner && agent == &saved.id && saved.name.as_deref() == Some(name), "actual saved agent name differs")?;
                fields.push(assertion("saved_agent_id", WitnessScalar::Text(saved.id))); fields.push(assertion("saved_name", WitnessScalar::Text(name.clone())));
            }
            (ExpectedEffect::UserPresent, SavedEffect::UserSession { persisted, invocation_start_ms, decoded_final_ms }) => {
                let replied = result["user_session"]["last_activity_ms"].as_i64().ok_or("actual presence reply lacks activity time")?;
                ensure(invocation_start_ms <= replied && replied <= decoded_final_ms && persisted.last_activity_ms.is_some_and(|saved| saved >= replied), "actual presence activity is not inside invocation or persisted summary lost it")?;
                fields.push(assertion("replied_activity_ms", WitnessScalar::I64(replied))); fields.push(assertion("persisted_activity_ms", WitnessScalar::I64(persisted.last_activity_ms.unwrap())));
            }
            (ExpectedEffect::Seen { owner, agent, thread }, SavedEffect::Seen { owner: actual_owner, agent: actual_agent, thread: actual_thread, persisted_through, published_through, actual_read_target_through }) => {
                ensure(owner == &actual_owner && agent == &actual_agent && thread == &actual_thread && persisted_through >= actual_read_target_through && published_through == persisted_through, "actual saved/published seen cursor does not cover actual targeted canonical sequence")?;
                fields.push(assertion("actual_read_target_through", WitnessScalar::U64(actual_read_target_through))); fields.push(assertion("saved_and_published_through", WitnessScalar::U64(persisted_through)));
            }
            (ExpectedEffect::Posted { owner, agent, thread, body, role, operation_id }, SavedEffect::Message { owner: actual_owner, agent: actual_agent, thread: actual_thread, item, operation_status, matched_actual_session_turn, mandatory_children_complete }) => {
                verify_message(owner, agent, thread, body, role, operation_id.as_deref(), None, &actual_owner, &actual_agent, &actual_thread, &item)?;
                if operation_id.is_some() {
                    ensure(operation_status.as_deref() == Some("delivered") && matched_actual_session_turn.as_ref().is_some_and(|turn| turn.contains(body)), "actual SPA post receipt/session turn did not deliver exact body")?;
                }
                ensure(mandatory_children_complete, "actual post mandatory children remain unfinished")?;
                fields.push(assertion("saved_message_id", WitnessScalar::Text(item["data"]["id"].as_str().ok_or("saved message ID absent")?.into())));
                if let Some(operation) = operation_id { fields.push(assertion("saved_operation_id", WitnessScalar::Text(operation.clone()))); }
                fields.push(assertion("saved_body", WitnessScalar::Text(body.clone())));
            }
            (ExpectedEffect::Handoff { caller, recipient_owner, recipient, thread, body }, SavedEffect::Message { owner: actual_owner, agent: actual_agent, thread: actual_thread, item, operation_status, matched_actual_session_turn, mandatory_children_complete }) => {
                let operation = result["operation_id"].as_str().ok_or("actual MCP handoff receipt lacks operation ID")?;
                verify_message(recipient_owner, recipient, thread, body, "user", Some(operation), Some(caller), &actual_owner, &actual_agent, &actual_thread, &item)?;
                ensure(operation_status.as_deref() == Some("delivered") && matched_actual_session_turn.as_ref().is_some_and(|turn| turn.contains(body)) && mandatory_children_complete, "actual handoff receipt/session turn/mandatory children unfinished")?;
                fields.push(assertion("saved_operation_id", WitnessScalar::Text(operation.into()))); fields.push(assertion("recipient", WitnessScalar::Text(recipient.clone()))); fields.push(assertion("saved_body", WitnessScalar::Text(body.clone())));
            }
            _ => return Err("native saved witness type does not match actual request effect".into()),
        }
        Ok(OracleWitness::State { oracle: format!("native-common-effect/{}", self.method()), assertions: fields })
    }
}
#[allow(clippy::too_many_arguments)]
fn verify_message(owner: &str, agent: &str, thread: &str, body: &str, role: &str, operation: Option<&str>, from_agent: Option<&String>, actual_owner: &str, actual_agent: &str, actual_thread: &str, item: &Value) -> Result<(), String> {
    ensure(owner == actual_owner && agent == actual_agent && thread == actual_thread && item["type"] == "message" && item["data"]["body"].as_str() == Some(body) && item["data"]["role"].as_str() == Some(role), "actual canonical saved message address/body/role differs")?;
    if let Some(operation) = operation { ensure(item["data"]["operation_id"].as_str() == Some(operation), "saved exact message operation differs")?; }
    if let Some(from) = from_agent { ensure(item["data"]["from_agent"]["id"].as_str() == Some(from), "saved handoff sender differs")?; }
    Ok(())
}
