//! OFFSOURCE cursor consumer, not a second write ledger or source of completion.
//! Accepts only actual terminal native snapshots from the existing bounded cursor.
use crate::timing::write_wait::{WriteCohort, WriteId, WriteSnapshot};
use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};
use tokio::sync::Notify;

#[derive(Clone, Debug)]
pub(super) struct NativeCompletion {
    pub original_id: String,
    pub write_id: WriteId,
    pub completed_at: std::time::Instant,
}
struct Slot {
    value: Mutex<Option<Result<NativeCompletion, String>>>,
    ready: Notify,
}
pub(super) struct CompletedOrigins {
    slots: BTreeMap<String, Slot>,
}
impl CompletedOrigins {
    pub fn new(originals: impl IntoIterator<Item=String>) -> Result<Arc<Self>, String> {
        let mut slots = BTreeMap::new();
        for original in originals {
            if slots.insert(original.clone(), Slot { value: Mutex::new(None), ready: Notify::new() }).is_some() { return Err(format!("duplicate immutable completion consumer original {original}")); }
        }
        Ok(Arc::new(Self { slots }))
    }
    /// Called once per actual cursor snapshot, before notifying request proof
    /// consumers. Unknown background/bootstrap origins stay in the raw native
    /// archive; this index neither classifies nor discards that authoritative data.
    pub fn import(&self, row: &WriteSnapshot) -> Result<(), String> {
        let Some(slot) = self.slots.get(&row.original_id) else { return Ok(()); };
        let result = terminal(row);
        let invalid = result.as_ref().err().cloned();
        let mut value = slot.value.lock().map_err(|_| "completion consumer poisoned")?;
        if value.is_some() {
            *value = Some(Err(format!("multiple native completions for immutable original {}", row.original_id)));
        } else { *value = Some(result); }
        drop(value);
        slot.ready.notify_waiters();
        if let Some(error) = invalid { return Err(error); }
        Ok(())
    }
    pub async fn wait(&self, original: &str, cleanup_deadline: tokio::time::Instant) -> Result<NativeCompletion, String> {
        let slot = self.slots.get(original).ok_or("completion requested outside immutable semantic plan")?;
        loop {
            let changed = slot.ready.notified();
            tokio::pin!(changed);
            changed.as_mut().enable();
            if let Some(value) = slot.value.lock().map_err(|_| "completion consumer poisoned")?.clone() { return value; }
            // Timeout reports missing native proof; it does not cancel work,
            // erase the original or fabricate its registry completion.
            tokio::time::timeout_at(cleanup_deadline, changed).await.map_err(|_| format!("native completion not observed before bounded cleanup for {original}"))?;
        }
    }
    pub fn audit(&self) -> Vec<String> {
        self.slots.iter().filter_map(|(original, slot)| match slot.value.lock() {
            Ok(value) => match &*value { Some(Ok(_)) => None, Some(Err(error)) => Some(error.clone()), None => Some(format!("native completion missing {original}")) },
            Err(_) => Some(format!("completion consumer poisoned {original}")),
        }).collect()
    }
}
fn terminal(row: &WriteSnapshot) -> Result<NativeCompletion, String> {
    if row.cohort != WriteCohort::SemanticWrite || !row.root_finished || !row.outstanding.is_empty() || !row.active.is_empty() || row.cancelled || row.abandoned {
        return Err(format!("actual cursor row does not prove clean semantic completion {} ({:?})", row.original_id, row.id));
    }
    let completed_at = row.completed_at.ok_or_else(|| format!("native completed timestamp missing {}", row.original_id))?;
    Ok(NativeCompletion { original_id: row.original_id.clone(), write_id: row.id, completed_at })
}
