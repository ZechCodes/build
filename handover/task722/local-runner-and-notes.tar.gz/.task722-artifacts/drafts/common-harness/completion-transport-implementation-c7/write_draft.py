from pathlib import Path
root=Path(__file__).parent
base=Path('/home/zech/Projects/.build-worktrees/workspaces/proj-1/lock-hold-709/Build')
prefix=Path('bridge/src/app/tests/runtime/write_wait_qualification/backend')
def write(name,text):
 p=root/'after'/prefix/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
source=(base/prefix/'completed_origins.rs').read_text()
head=source[source.index('/// Only this module'):source.index('/// Empty TEST-FIRST')]
write('completed_origins.rs', '''//! One checked result per immutable expected original, from native terminal cursors.
use crate::timing::write_wait::{WriteCohort, WriteId, WriteSnapshot};
use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};
use std::time::Instant;
use tokio::sync::Notify;

'''+head+'''struct CompletionSlot {
    method: String,
    result: Mutex<Option<Result<NativeCompletion, String>>>,
    ready: Notify,
}

pub(super) struct CompletedOrigins {
    slots: BTreeMap<String, CompletionSlot>,
}

impl CompletedOrigins {
    pub(super) fn new(
        expected: impl IntoIterator<Item = (String, String)>,
    ) -> Result<Arc<Self>, String> {
        let mut slots = BTreeMap::new();
        for (original, method) in expected {
            let slot = CompletionSlot {
                method,
                result: Mutex::new(None),
                ready: Notify::new(),
            };
            if slots.insert(original.clone(), slot).is_some() {
                return Err(format!("duplicate_expected_original: {original}"));
            }
        }
        Ok(Arc::new(Self { slots }))
    }

    pub(super) fn import(&self, row: &WriteSnapshot) -> Result<(), String> {
        let Some(slot) = self.slots.get(&row.original_id) else {
            // Background and unplanned rows remain in the native raw archive.
            return Ok(());
        };
        let mut stored = slot.result.lock().map_err(|_| {
            format!("completion_state_poisoned: {}", row.original_id)
        })?;
        let result = if stored.is_some() {
            Err(format!("duplicate_native_completion: {} native {:?}", row.original_id, row.id))
        } else {
            checked_completion(row, &slot.method)
        };
        let status = result.as_ref().map(|_| ()).map_err(Clone::clone);
        // Construct at most one success. A replay or late distinct root replaces
        // success with a permanent failure, including after a waiter copied it.
        *stored = Some(result);
        drop(stored);
        slot.ready.notify_waiters();
        status
    }

    pub(super) async fn wait(
        &self,
        original: &str,
        cleanup_deadline: tokio::time::Instant,
    ) -> Result<NativeCompletion, String> {
        let slot = self.slots.get(original)
            .ok_or_else(|| format!("unknown_expected_original: {original}"))?;
        loop {
            let notified = slot.ready.notified();
            tokio::pin!(notified);
            // Register before checking the slot so import cannot lose a wake.
            notified.as_mut().enable();
            if let Some(result) = slot.result.lock()
                .map_err(|_| format!("completion_state_poisoned: {original}"))?.clone() {
                return result;
            }
            if tokio::time::timeout_at(cleanup_deadline, notified).await.is_err() {
                // A missed deadline is not cancellation or a permanent missing
                // result: owned native work can still finish during cleanup.
                return Err(format!("missing_native_completion: {original}"));
            }
        }
    }

    pub(super) fn audit(&self) -> Vec<String> {
        self.slots.iter().filter_map(|(original, slot)| {
            match slot.result.lock() {
                Ok(stored) => match stored.as_ref() {
                    Some(Ok(_)) => None,
                    Some(Err(error)) => Some(error.clone()),
                    None => Some(format!("missing_native_completion: {original}")),
                },
                Err(_) => Some(format!("completion_state_poisoned: {original}")),
            }
        }).collect()
    }
}

fn checked_completion(row: &WriteSnapshot, expected_method: &str) -> Result<NativeCompletion, String> {
    if row.method != expected_method {
        return Err(format!("native_method_mismatch: {} expected {expected_method}, actual {}", row.original_id, row.method));
    }
    if row.cohort != WriteCohort::SemanticWrite {
        return Err(format!("native_cohort_mismatch: {} actual {:?}", row.original_id, row.cohort));
    }
    if row.cancelled {
        return Err(format!("cancelled_native_completion: {}", row.original_id));
    }
    if row.abandoned {
        return Err(format!("abandoned_native_completion: {}", row.original_id));
    }
    if !row.root_finished || !row.outstanding.is_empty() || !row.active.is_empty() {
        return Err(format!("unfinished_native_completion: {}", row.original_id));
    }
    let completed_at = row.completed_at.ok_or_else(|| {
        format!("unfinished_native_completion: {} missing terminal timestamp", row.original_id)
    })?;
    Ok(NativeCompletion {
        original_id: row.original_id.clone(),
        method: row.method.clone(),
        write_id: row.id,
        completed_at,
    })
}

#[cfg(test)]
#[path = "completed_origins/tests.rs"]
mod tests;
''')
write('final_transport/validate.rs','''//! Final checks over the existing joined watch and native MCP reports.
use super::*;
use super::super::super::client_watch::{ClientRow, FinalOutcome, TrafficCohort};
use super::super::super::trial_complete::{Route, Traffic};
use std::collections::{BTreeMap, BTreeSet};
#[path = "validate_mcp.rs"]
mod mcp;

pub(super) fn validate_final_transport(
    plan: &[Slot],
    reconcile: Option<&FinalReconciliation>,
    report: Option<&WatchReport>,
    mcp: &McpShutdownReport,
    native_joined: bool,
) -> Vec<String> {
    let mut errors = Vec::new();
    let mut expected = BTreeMap::new();
    for slot in plan {
        if expected.insert(slot.original_id.as_str(), slot).is_some() {
            errors.push(format!("duplicate_planned_original: {}", slot.original_id));
        }
    }
    if let Some(reconcile) = reconcile {
        validate_clients(&expected, reconcile, &mut errors);
    } else {
        errors.push("missing_client_reconciliation".into());
    }
    validate_watch(report, &mut errors);
    mcp::validate(&expected, mcp, &mut errors);
    if !native_joined {
        errors.push("native_cleanup_unconfirmed".into());
    }
    errors
}

fn validate_clients(expected: &BTreeMap<&str, &Slot>, reconcile: &FinalReconciliation, errors: &mut Vec<String>) {
    errors.extend(reconcile.violations.iter().map(|error| format!("client_reconciliation: {error}")));
    let mut seen = BTreeSet::new();
    for row in &reconcile.rows {
        if !seen.insert(row.original_id.as_str()) {
            errors.push(format!("duplicate_client_original: {}", row.original_id));
        }
        match expected.get(row.original_id.as_str()) {
            Some(slot) if cohort(slot.traffic) != row.cohort => errors.push(format!("planned_cohort_mismatch: {}", row.original_id)),
            None => errors.push(format!("unexpected_client_original: {}", row.original_id)),
            _ => {}
        }
        if !client_complete(row) {
            errors.push(format!("client_reconciliation: {} incomplete or failed lifecycle", row.original_id));
        }
    }
    errors.extend(expected.keys().filter(|id| !seen.contains(**id)).map(|id| format!("missing_client_original: {id}")));
}

fn cohort(traffic: Traffic) -> TrafficCohort {
    match traffic {
        Traffic::Write => TrafficCohort::SemanticWrite,
        Traffic::Read => TrafficCohort::Read,
        Traffic::Exempt => TrafficCohort::Exempt,
    }
}

fn client_complete(row: &ClientRow) -> bool {
    let semantic = row.cohort == TrafficCohort::SemanticWrite;
    let supplied = [row.offered_at, row.sent_at, row.final_at, row.finished_at];
    let semantic_supplied = !semantic || (row.server_registered_at.is_some() && row.admitted_at.is_some());
    supplied.iter().all(Option::is_some)
        && semantic_supplied
        && row.final_outcome == Some(FinalOutcome::Reply)
        && row.registered_at <= row.intended_at
        && !row.implicit_schedule
        && !row.cancelled
        && row.cancelled_at.is_none()
        && !row.breached
}

fn validate_watch(report: Option<&WatchReport>, errors: &mut Vec<String>) {
    let Some(report) = report else {
        errors.push("missing_watch_report".into());
        return;
    };
    for (failed, diagnostic) in [
        (report.failed, "watch_failed"),
        (report.panicked, "watch_panicked"),
        (report.still_indexed != 0, "watch_still_indexed"),
        (!report.breaches.is_empty(), "watch_breach"),
    ] {
        if failed { errors.push(diagnostic.into()); }
    }
}
''')
write('final_transport/validate_mcp.rs','''use super::*;
use super::super::super::super::mcp_adapter::{McpCallRow, McpHarness, SocketEvidence, ROUTER_ENDPOINT};

pub(super) fn validate(expected: &BTreeMap<&str, &Slot>, report: &McpShutdownReport, errors: &mut Vec<String>) {
    if !report.quiet || !report.unfinished.is_empty() {
        errors.push(format!("mcp_worker_join: quiet={} unfinished={:?}", report.quiet, report.unfinished));
    }
    errors.extend(report.evidence.errors.iter().map(|error| format!("mcp_transport_error: {error}")));
    let sockets = validate_sockets(&report.evidence.sockets, errors);
    let mut seen = BTreeSet::new();
    for (key, call) in &report.evidence.calls {
        if key != &call.original_id || !seen.insert(call.original_id.as_str()) {
            errors.push(format!("duplicate_or_mismatched_mcp_original: key={key}, original={}", call.original_id));
        }
        let planned = expected.get(call.original_id.as_str()).copied().filter(|slot| slot.route == Route::AgentMcp);
        match planned {
            Some(slot) => validate_binding(slot, call, errors),
            None => errors.push(format!("unexpected_mcp_original: {}", call.original_id)),
        }
        if !sockets.contains(&call.endpoint) {
            errors.push(format!("missing_mcp_endpoint: {} endpoint={}", call.original_id, call.endpoint));
        }
        validate_call(call, errors);
    }
    errors.extend(expected.values().filter(|slot| slot.route == Route::AgentMcp && !seen.contains(slot.original_id.as_str()))
        .map(|slot| format!("missing_mcp_original: {}", slot.original_id)));
}

fn validate_sockets(rows: &[SocketEvidence], errors: &mut Vec<String>) -> BTreeSet<usize> {
    let mut endpoints = BTreeSet::new();
    let mut agents = BTreeSet::new();
    for row in rows {
        if !endpoints.insert(row.endpoint) || !agents.insert(row.agent.as_str()) || row.agent.is_empty() {
            errors.push(format!("duplicate_or_missing_mcp_endpoint: {}", row.endpoint));
        }
        if row.endpoint > ROUTER_ENDPOINT || row.passive_router != (row.endpoint == ROUTER_ENDPOINT) {
            errors.push(format!("mcp_endpoint_role: {}", row.endpoint));
        }
        if row.limit != 2 || row.maximum_active > 2 || row.active != 0 {
            errors.push(format!("mcp_socket_limit: endpoint={} active={} maximum={} limit={}", row.endpoint, row.active, row.maximum_active, row.limit));
        }
    }
    endpoints
}

fn validate_binding(slot: &Slot, call: &McpCallRow, errors: &mut Vec<String>) {
    if call.read != (slot.traffic == Traffic::Read) || slot.traffic == Traffic::Exempt {
        errors.push(format!("mcp_cohort_mismatch: {}", call.original_id));
    }
    if McpHarness::endpoint_for_caller(slot.caller).ok() != Some(call.endpoint) {
        errors.push(format!("mcp_endpoint_mismatch: {}", call.original_id));
    }
    // Write slots name their tool through the immutable CommonRequest, checked
    // by the native completion consumer. Declared read methods bind here too.
    if call.method.is_empty() || slot.method.as_ref().is_some_and(|method| method != &call.method) {
        errors.push(format!("mcp_method_mismatch: {}", call.original_id));
    }
}

fn validate_call(call: &McpCallRow, errors: &mut Vec<String>) {
    let joined = [call.client_closed_at, call.server_joined_at, call.worker_finished_at, call.worker_reaped_at];
    if joined.iter().any(Option::is_none) || call.abandoned {
        errors.push(format!("mcp_worker_join: {}", call.original_id));
    }
    let transport = [call.socket_wait_started_at, call.socket_acquired_at, call.sent_at, call.final_reply_at];
    let response = call.response_ok == Some(true)
        && call.response_bytes.is_some_and(|bytes| bytes > 0)
        && call.response_sha256.as_ref().is_some_and(|hash| hash.len() == 64 && hash.bytes().all(|byte| byte.is_ascii_hexdigit()));
    if transport.iter().any(Option::is_none) || !response || call.error.is_some() {
        errors.push(format!("mcp_call_lifecycle: {}", call.original_id));
    }
    // actual_wire_id is optional native evidence; never invent or require an echo.
}
''')
# Reconcile narrowly against current tracked bases; never replay stale afterimages.
s=(base/prefix/'control.rs').read_text()
s=s.replace('    registry: Arc<crate::timing::write_wait::WriteWaitRegistry>,','    registry: Arc<crate::timing::write_wait::WriteWaitRegistry>,\n    completed: Arc<completed_origins::CompletedOrigins>,',1)
s=s.replace('        let result = std::panic::catch_unwind', '''        let completed = match completed_origins::CompletedOrigins::new(
            prepared.plan.iter().filter(|slot| slot.traffic == Traffic::Write)
                .map(|slot| (slot.original_id.clone(), recipe_for(&prepared, slot).method)),
        ) {
            Ok(completed) => completed,
            Err(reason) => return Err(PreparationFailure { reason, retained: prepared }),
        };
        let result = std::panic::catch_unwind''',1)
s=s.replace('Ok(Self::from_attached(prepared, sink))','Ok(Self::from_attached(prepared, sink, completed))',1)
s=s.replace('fn from_attached(prepared: PreparedBackend, sink: Arc<dyn ArtifactSink>) -> Self {','fn from_attached(prepared: PreparedBackend, sink: Arc<dyn ArtifactSink>, completed: Arc<completed_origins::CompletedOrigins>) -> Self {',1)
s=s.replace('                &registry,\n                prepared','                &registry,\n                Arc::clone(&completed),\n                prepared',1)
s=s.replace('            registry,\n            resources:','            registry,\n            completed,\n            resources:',1)
write('control.rs',s)
s=(base/prefix/'control/archive.rs').read_text()
s=s.replace('    snapshots: CompletedSnapshotsCursor,','    completed: Arc<completed_origins::CompletedOrigins>,\n    errors: BTreeSet<String>,\n    snapshots: CompletedSnapshotsCursor,',1)
s=s.replace('pub fn new(registry: &Arc<WriteWaitRegistry>, intended: BTreeSet<String>) -> Self {','pub fn new(registry: &Arc<WriteWaitRegistry>, completed: Arc<completed_origins::CompletedOrigins>, intended: BTreeSet<String>) -> Self {',1)
s=s.replace('        Self {\n            snapshots:', '        Self {\n            completed,\n            errors: BTreeSet::new(),\n            snapshots:',1)
s=s.replace('        self.batch(registry, observe).map(|_| ())','''        self.batch(registry, observe)?;
        self.result()
    }
    fn result(&self) -> Result<(), String> {
        if self.errors.is_empty() { Ok(()) } else {
            Err(self.errors.iter().cloned().collect::<Vec<_>>().join("; "))
        }''',1)
s=s.replace('''                    self.import_stages(&row, observe)?;''','''                    if let Err(error) = self.import_stages(&row, observe) {
                        self.errors.insert(error);
                    }''',1)
s=s.replace('''            }
        }
        let intervals = registry''','''            }
            // The cursor advanced over this entire batch. Process every row,
            // even after a prior import error, and validate cohort before any
            // proof credit. Publish after stages so waiters see real milestones.
            if let Err(error) = self.completed.import(&row) {
                self.errors.insert(error);
            }
        }
        let intervals = registry''',1)
s=s.replace('''                    observe.stage(&row.original_id, stage, at)?;''','''                    if let Err(error) = observe.stage(&row.original_id, stage, at) {
                        self.errors.insert(error);
                    }''',1)
s=s.replace('''        prepared: &PreparedBackend,
        observe: &Observation,''','''        prepared: &mut PreparedBackend,
        registry: &WriteWaitRegistry,
        observe: &Observation,''',1)
start=s.index('        let registry = &prepared\n')
end=s.index('        let cursor_result =',start)
s=s[:start]+s[end:]
s=s.replace('''        super::super::native_archive::persist(prepared, &rows, &intervals, sink)?;''','''        if let Err(error) = super::super::native_archive::persist(prepared, registry, &rows, &intervals, sink) {
            self.errors.insert(error);
        }''',1)
s=s.replace('''            self.import_stages(row, observe)?;''','''            if let Err(error) = self.import_stages(row, observe) {
                self.errors.insert(error);
            }''',1)
s=s.replace('''        archive_final_rows(&rows, &intended, observe)?;
        archive_final_services(''','''        if let Err(error) = archive_final_rows(&rows, &intended, observe) {
            self.errors.insert(error);
        }
        if let Err(error) = archive_final_services(''',1)
s=s.replace('''        )?;
        cursor_result?;
        let finite_missing''','''        ) {
            self.errors.insert(error);
        }
        if let Err(error) = cursor_result {
            self.errors.insert(error);
        }
        self.errors.extend(self.completed.audit());
        let finite_missing''',1)
s=s.replace('''            return Err(format!("actual work drained but incremental completion proof RED: {} of{} intended roots observed via real cursor; {} actual interval rows", intended.iter().filter(|id| self.imported.contains(*id)).count(), intended.len(), self.actual_interval_rows));
        }
        Ok(())''','''            self.errors.insert(format!("actual work drained but incremental completion proof RED: {} of{} intended roots observed via real cursor; {} actual interval rows", intended.iter().filter(|id| self.imported.contains(*id)).count(), intended.len(), self.actual_interval_rows));
        }
        self.result()''',1)
# Services must not hide completion audit when their ownership evidence is absent.
s=s.replace('''        if let Err(error) = archive_final_services(
            &rows,
            &intervals,
            prepared
                .services
                .as_ref()
                .ok_or("actual finite services missing")?,
            observe,
        ) {
            self.errors.insert(error);
        }''','''        match prepared.services.as_ref() {
            Some(services) => {
                if let Err(error) = archive_final_services(&rows, &intervals, services, observe) {
                    self.errors.insert(error);
                }
            }
            None => { self.errors.insert("actual finite services missing".into()); }
        }''',1)
write('control/archive.rs',s)
s=(base/prefix/'native_archive.rs').read_text()
s=s.replace('    prepared: &PreparedBackend,','    prepared: &mut PreparedBackend,\n    registry: &crate::timing::write_wait::WriteWaitRegistry,',1)
start=s.index('    let registry = &prepared\n');end=s.index('    let mut counts',start);s=s[:start]+s[end:]
s=s.replace('    sink.registry_archive(prepared.name, &json!({','    let record = json!({',1)
s=s.replace('all native rows at pre-cleanup required drain','all native rows after actual native cleanup attempt',1)
s=s.replace('''    }))
}
fn native_row''','''    });
    let result = sink.registry_archive(prepared.name, &record);
    if result.is_err() {
        // Keep the exact full export even when persistence rejects it.
        prepared.native_archive = Some(record);
    }
    result
}
fn native_row''',1)
write('native_archive.rs',s)
s=(base/prefix/'mod.rs').read_text().replace('    transport_archive: Option<serde_json::Value>,','    transport_archive: Option<serde_json::Value>,\n    native_archive: Option<serde_json::Value>,',1).replace('            transport_archive: None,','            transport_archive: None,\n            native_archive: None,',1)
write('mod.rs',s)
s=(base/prefix/'control/close.rs').read_text()
s=s.replace('    archive: Arc<Mutex<receipt_archive::Pump>>,','    archive: Arc<Mutex<receipt_archive::Pump>>,\n    registry: Arc<crate::timing::write_wait::WriteWaitRegistry>,',1)
s=s.replace('            archive: Arc::clone(&self.archive),','            archive: Arc::clone(&self.archive),\n            registry: Arc::clone(&self.registry),',1)
s=s.replace('        self.final_archive(prepared);\n','',1)
s=s.replace('        let native_joined = self.close_native(prepared).await;','''        let native_joined = self.close_native(prepared).await;
        // One final export after cleanup includes native completions that
        // arrived after their original proof waiter returned.
        self.final_archive(prepared);''',1)
s=s.replace('        if report.is_none() || !persisted {','        if report.is_none() || !persisted || prepared.native_archive.is_some() {',1)
s=s.replace('fn final_archive(&self, prepared: &PreparedBackend)', 'fn final_archive(&self, prepared: &mut PreparedBackend)',1)
s=s.replace('.finish(prepared, observe, &*self.sink)', '.finish(prepared, &self.registry, observe, &*self.sink)',1)
s=s.replace('    prepared.services.take();\n','''    // FixtureServices owns only exact-root test registrations and samples,
    // not AppState. Retain it through the final post-cleanup native export.
''',1)
write('control/close.rs',s)
