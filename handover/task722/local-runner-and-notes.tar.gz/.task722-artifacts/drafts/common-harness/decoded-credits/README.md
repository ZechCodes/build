# Decoded reply credits — narrow TESTFIRST package

Offsource only. No source changes, build, run, or passing evidence.

The observed defect is the existing RunState coupling of caller credits to the
execution/proof JoinHandle. `backend/control/effects.rs` may keep that handle
pending after a decoded final response while mandatory children and saved proof
settle. The new helper below separates those lifetimes; its decoded transition
is deliberately empty for the first observed RED. Its finish transition retains
the current behavior. The controls are explicitly accounting/ownership controls,
not fabricated native response or qualification success.

Requested TESTFIRST source window:

1. Add `trial/runner/credits.rs` from `credits.testfirst.rs` and its `tests.rs`.
2. Register `#[path = "runner/credits.rs"] mod credits;` in `trial/runner.rs`.
3. Add a single optional decoded observer to ClientWatch, registered before
   callers dispatch. Its TESTFIRST emission seam is empty. Existing settlement,
   deadlines, raw evidence, and transport behavior remain unchanged.
4. Append the supplied actual adapter-boundary control to existing rpc/tests.rs
   and timestamp/error-cohort control to client_watch/tests.rs. The RPC control
   performs a real encrypted mutation and retains its owned proof-tail task
   until after observing the decoded event. Exact callback notification does not
   release the physical SocketLease.

Exact ready helper selectors (prefix
`app::tests::runtime::write_wait_qualification::trial_complete::runner::credits::tests::`):

- `decoded_write_releases_caller_and_coordinator_socket_while_tail_stays_owned`
- `decoded_mcp_read_releases_only_coordinator_socket_before_oracle_tail`
- `decoded_reply_is_exactly_once_and_finish_never_releases_twice`
- `no_reply_failure_releases_held_credits_without_decoded_success`

The first three must fail at the decoded transition, after real owned task
cleanup. The last preserves pre-reply error fallback. No source implementation
is authorized by this draft: obtain and retain actual RED first.

The two additional exact selectors are:

- `app::tests::runtime::write_wait_qualification::rpc::tests::actual_rpc_decoded_notification_precedes_owned_proof_tail`
- `app::tests::runtime::write_wait_qualification::client_watch::tests::decoded_observer_preserves_actual_timestamp_without_converting_transport_failure_to_reply`

Both must fail for missing decoded notification, after preserved lifecycle and
cleanup. `testfirst.patch` combines these six controls, stubs, and registration.

After RED, connect the existing coordinator's done channel to an enum carrying
`DecodedReply { original_id, actual_at }` and `Finished`. The observer sends the
decoded event synchronously at validated parse, and the execution task sends
Finished later on that same channel. This avoids a cross-channel race in which
Finished removes an original before its queued decoded event is consumed.

Replace each Running tuple with an owned entry containing this credit lease and
the same JoinHandle. Decoded events look up the exact original, reject unknown or
duplicate events, release the semantic active credit only for Write and release
the coordinator MCP socket credit for Write or Read. Read/exempt active credits
keep their current completion boundary. Finished removes and joins the task and
releases only still-held credits. Running remains the drain/cleanup obligation
set; predecessor eligibility still requires Stage::Completed. No row milestone,
saved/native proof, registry root, or five-second deadline is completed/reset by
credit release.

Actual parse boundaries: rpc/receive.rs `deliver_final` after matching the pending
original; mcp_adapter/socket.rs `exchange_inner` after `validate_final`. Pass the
existing `final_reply_at`. Do not use backend::transport::record_reply: MCP calls
it after EOF and server join. Do not treat a transport failure/cancellation as a
decoded reply. Keep physical socket semaphore, owned worker/server joins, active
socket evidence, and all current physical-two-socket assertions unchanged.

Pending: Trace review and a separate deterministic actual MCP
decode-before-server-join control. The MCP parse site is routed correctly in this
patch but the RPC and shared-notification controls alone do not prove its native
server-tail ordering. This package does not enable normal trials.
