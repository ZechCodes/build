# Decoded-credit implementation successor — offsource

No source application or build/run. Requires retained intended RED from the
six first-batch controls, review, and a source window from root.

The shared validated parser callback sends DecodedReply onto the existing
coordinator completion channel, before the execution can send Finished. The
single channel preserves each original's causal event order. No full archive
polling, new runtime, or production hook is added.

Running entries retain their JoinHandle independently from CallerCredits. The
actual RunState decoder event path releases Write active credit and any MCP
coordinator socket credit once. Read/exempt active-credit boundaries stay at
execution return. Physical MCP SocketLease, server/worker ownership, two-socket
cap, and genuine adapter wait evidence remain unchanged. Finished removes/joins
the execution and releases only counters still held after errors or before a
reply. Unknown/duplicate events remain failures. Recipe predecessors still
require Stage::Completed; all existing proof, drain, watchdog and deadline
requirements are retained.

Two raw ledger milestones distinguish the actual validated parser timestamp
(`DecodedReplyObserved`) from coordinator credit-return time
(`CallerCreditReleased`). Existing wire-sent, parsed-reply, native receipt,
completed root, service and raw socket timestamps remain intact. No deadline
or success counter is advanced by these new milestones.

The additional coordinator controls call the same apply_decoded/take_finished
reducers used by RunState against exact-ID Running entries and real owned
pending tasks. They require a next write's caller/socket eligibility while its
previous task remains pending, no Stage::Completed/predecessor credit, immutable
due time, raw event/release times, unchanged counters on unknown/duplicate event,
and no double decrement at joined completion. They are honestly bookkeeping
controls, not fabricated native effect proofs.

The additional MCP control executes RequestWorker::exchange_inner over a real
UnixStream pair and holds the protocol peer's EOF after it emits one valid
native-shaped response. It requires notification at the actual decoder while
both tasks remain pending, then releases EOF and joins them before asserting.
It is codec/ownership evidence only: no authenticated semantic mutation, fake
product success, or native child proof is claimed. The actual mixed smoke remains
the authenticated integration check. It never changes the physical lease.

The three new selectors and every source-before/after hash are in manifest.json.
The six earlier exact selectors remain required. Run the required controls and
release smoke after review; do not start normal trials from this package.
