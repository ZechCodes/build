//! OFF-SOURCE integration contract. Not a compiled workload or qualification result.
use std::future::Future;
use std::pin::Pin;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use serde_json::Value;
use crate::app::{AppState, read_view::ReadViewSlot};
use crate::carrier::FrameIntake;
use crate::timing::write_wait::{WriteId, WriteWaitRegistry};

type WorkFuture<'a, T> = Pin<Box<dyn Future<Output = Result<T, String>> + Send + 'a>>;

#[derive(Clone)]
pub(super) struct ProjectContext {
    pub project_id: String,
    pub repository: std::path::PathBuf,
    pub source_id: String,
    pub tasks: Vec<String>,
}
#[derive(Clone)]
pub(super) struct WorkspaceContext {
    pub project: usize,
    pub workspace_id: String,
    pub source_id: String,
    pub directory: std::path::PathBuf,
    pub owner: String,
    pub agent_id: String,
    pub thread_id: String,
}

pub(super) struct QualificationFixture {
    // All four contexts and8active source workspaces have real temp files/WAL rows.
    pub state: Arc<Mutex<AppState>>,
    pub intake: Arc<FrameIntake>,
    pub registry: Arc<WriteWaitRegistry>,
    pub view: ReadViewSlot,
    pub projects: Vec<ProjectContext>,
    pub active_workspaces: Vec<WorkspaceContext>,
    // The implemented version must also own temp roots, fake sessions,
    // subscriptions, producers and wire receivers through joined shutdown.
}

pub(super) struct RequestIdentity {
    pub original_id: String, // qual/{small|large}/{trial1..3}/{traffic}/{sequence}
    pub caller: usize,
    pub intended_at: Instant,
    pub offered_at: Instant,
}

pub(super) struct ReplyProof {
    pub original_id: String,
    pub method: String,
    pub write_id: Option<WriteId>,
    pub intended_at: Instant,
    pub offered_at: Instant,
    pub sent_at: Instant,
    pub admission_receipt_at: Option<Instant>,
    pub final_reply_at: Instant,
    pub result: Value,
    pub encoded_result_bytes: usize,
}

/// Actual adapters only. A synthetic implementation must not be accepted by
/// long-trial entrypoints, even if it returns ReplyProof-looking metadata.
trait QualificationTransport: Send + Sync {
    fn rpc<'a>(&'a self, identity: RequestIdentity, method: &'static str, params: Value)
        -> WorkFuture<'a, ReplyProof>;
    fn mcp<'a>(&'a self, identity: RequestIdentity, action: crate::mcp::BridgeAction)
        -> WorkFuture<'a, ReplyProof>;
}

/// A successful reply alone is insufficient. Each recipe also verifies a
/// durable/published effect or accepted service job at its declared boundary.
trait FiniteServiceRecipe: Send + Sync {
    fn method(&self) -> &'static str;
    fn external_bound(&self) -> Duration;
    fn execute_and_verify<'a>(&'a self, fixture: &'a QualificationFixture,
        transport: &'a dyn QualificationTransport, identity: RequestIdentity)
        -> WorkFuture<'a, ReplyProof>;
}
