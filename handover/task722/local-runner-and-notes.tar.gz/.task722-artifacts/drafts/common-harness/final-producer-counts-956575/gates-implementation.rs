//! Final joined producer accounting; no synthetic admission/refusal counters.
use super::*;

// Independent plan oracle: normal600s requires2400/2400/600/600 callbacks.
// Short accounting controls use these same periods, never normal trial credit.
const EXPECTED: [(&str, u64); 4] = [
    ("status_observations", 250_000),
    ("delivery_consumption", 250_000),
    ("source_git_refresh", 1_000_000),
    ("watcher_publication", 1_000_000),
];

pub(in super::super) fn validate_final_producers(
    snapshot: &ProbeSnapshot,
    offer_window: Duration,
    observe: &Observation,
) {
    let mut errors = snapshot.producer_failures.clone();
    if snapshot.producer_counts.len() != EXPECTED.len() {
        errors.push(format!(
            "expected four final producer reports, got {}",
            snapshot.producer_counts.len()
        ));
    }
    let window_us = offer_window.as_micros();
    for (name, period_us) in EXPECTED {
        match snapshot.producer_counts.get(name) {
            Some(counts) => errors.extend(producer_errors(name, counts, window_us, period_us)),
            None => errors.push(format!("missing final producer report: {name}")),
        }
    }
    if !errors.is_empty() {
        observe.fail(None, "final_producer_report", errors.join("; "));
    }
}

fn producer_errors(
    name: &str,
    counts: &ProducerCounts,
    window_us: u128,
    period_us: u64,
) -> Vec<String> {
    let planned = window_us.div_ceil(u128::from(period_us));
    let checks = [
        (counts.counters_coherent, "incoherent final counters"),
        (
            counts.joined && counts.body_released,
            "producer ownership not joined and released",
        ),
        (
            counts.period_us == period_us,
            "producer period differs from approved plan",
        ),
        (
            u128::from(counts.planned) == planned && planned > 0,
            "planned total differs from offer window",
        ),
        (
            counts.intended == counts.planned,
            "intended callbacks differ from full plan",
        ),
        (
            counts.started == counts.intended,
            "started callbacks differ from intended",
        ),
        (
            counts.completed == counts.started && counts.failed == 0,
            "callback outcomes are incomplete or failed",
        ),
        (
            counts.pending_not_started == 0 && counts.missed_at_stop == 0,
            "due callbacks remain pending or missed",
        ),
        (
            counts.active_ordinal.is_none()
                && counts.oldest_owed_ordinal.is_none()
                && counts.oldest_owed_age_us.is_none(),
            "callback remains active or owed",
        ),
    ];
    checks
        .into_iter()
        .filter_map(|(valid, reason)| {
            (!valid).then(|| format!("{name}: {reason}; actual={counts:?}"))
        })
        .collect()
}

#[path = "producers/tests.rs"]
mod tests;
