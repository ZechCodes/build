from pathlib import Path
repo=Path('/home/zech/Projects/.build-worktrees/workspaces/proj-1/lock-hold-709/Build')
bundle=repo.parent/'.task722-artifacts/drafts/common-harness/final-transport-refusals-afd-v2'
base='bridge/src/app/tests/runtime/write_wait_qualification/backend/'
path=base+'final_transport.rs';text=(repo/path).read_text()
text=text.replace('use super::super::client_watch', 'use super::overload_refusals::VerifiedRefusals;\nuse super::super::client_watch',1)
text=text.replace('mod validate;','mod validate;\n#[path = "final_transport/refusals.rs"]\nmod refusals;',1)
needle='''    // None explicitly means the guard was not confirmed joined.'''
idx=text.index(needle)
text=text[:idx]+'''    archive_bound(name, (plan, None), watch, report, mcp, native_joined, sink)
}

pub(super) fn archive_final_overload(
    name: TrialName,
    bound_plan: (&[Slot], &VerifiedRefusals),
    watch: Option<&ClientWatch>,
    report: Option<&WatchReport>,
    mcp: &McpShutdownReport,
    native_joined: bool,
    sink: &dyn ArtifactSink,
) -> FinalArchive {
    archive_bound(name, (bound_plan.0, Some(bound_plan.1)), watch, report, mcp, native_joined, sink)
}

fn archive_bound(
    name: TrialName,
    (plan, refused): (&[Slot], Option<&VerifiedRefusals>),
    watch: Option<&ClientWatch>,
    report: Option<&WatchReport>,
    mcp: &McpShutdownReport,
    native_joined: bool,
    sink: &dyn ArtifactSink,
) -> FinalArchive {
'''+text[idx:]
text=text.replace('''    let record = json!({''','''    let partition = refused.map(|verified| {
        refusals::partition(plan, reconcile.as_ref(), violations.clone(), verified, anchor)
    });
    let effective = partition.as_ref().map(|audit| audit.errors.as_slice()).unwrap_or(&violations);
    let mut record = json!({''',1)
text=text.replace('"audit_violations":violations,','"audit_violations":effective,',1)
text=text.replace('''    // Persist failed audits as well, before returning any audit rejection.''','''    if let Some(partition) = &partition {
        // The original strict audit and raw ProtocolError rows stay untouched.
        record["strict_audit_violations"] = json!(violations);
        record["verified_refusal_partition"] = json!(partition.discharged);
    }
    // Persist failed audits as well, before returning any audit rejection.''',1)
text=text.replace('    let mut errors = violations;','    let mut errors = partition.map(|audit| audit.errors).unwrap_or(violations);',1)
target=bundle/'testfirst/after'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
path=base+'final_transport/refusals.rs';text='''//! Only closed final native refusal tokens can discharge a reply-only failure.
use super::*;

#[cfg(test)]
#[path = "refusals/tests.rs"]
mod tests;

pub(super) struct Audit {
    pub errors: Vec<String>,
    pub discharged: Vec<Value>,
}

pub(super) fn partition(
    _plan: &[Slot],
    _reconcile: Option<&FinalReconciliation>,
    mut strict_errors: Vec<String>,
    _refused: &VerifiedRefusals,
    _anchor: Instant,
) -> Audit {
    strict_errors.push("verified_refusal_transport_partition_TESTFIRST_pending".into());
    Audit { errors: strict_errors, discharged: Vec::new() }
}
'''
target=bundle/'testfirst/after'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
