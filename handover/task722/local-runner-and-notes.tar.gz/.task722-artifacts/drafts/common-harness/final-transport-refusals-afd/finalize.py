from pathlib import Path
import json,hashlib,difflib,re,subprocess
repo=Path('/home/zech/Projects/.build-worktrees/workspaces/proj-1/lock-hold-709/Build');bundle=repo.parent/'.task722-artifacts/drafts/common-harness/final-transport-refusals-afd'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name in ['testfirst','implementation']:
    stage=bundle/name;files=sorted(p for p in (stage/'after').rglob('*.rs'));patch='';entries=[]
    for target in files:
        path=str(target.relative_to(stage/'after'));first=bundle/'testfirst/after'/path
        prior=first if name=='implementation' and first.exists() else repo/path
        before=prior.read_text() if prior.exists() else '';after=target.read_text()
        patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+path if prior.exists() else '/dev/null',tofile='b/'+path))
        entries.append({'path':path,'base_sha256':hashlib.sha256(before.encode()).hexdigest() if prior.exists() else None,'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'baseline':'testfirst-after' if prior==first else 'afd-tracked'})
    (stage/(name+'.patch')).write_text(patch)
    manifest={'base_commit':base,'status':'offsource_dependency_API_review_pending_no_runtime','patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'files':entries,
      'dependencies':['Fault backend::overload_refusals VerifiedRefusals/VerifiedRefusal exact API and synchronous test_support::verified_spa_full/verified_zero_refusals Bundle','Effects saved_evidence actual empty_rejections_control and persisted AcceptedRefusals token'],
      'runtime':'No source/ref/build/test/commit. Apply/test only after reviewed dependencies are materialized. A prerequisite failure is not transport targetRED.',
      'TDD_order':['accepted rejection audit RED then implementation','native refusal final verifier RED then implementation','this transport TESTFIRST6 must reach target assertions and produce actual RED','only then apply this separate minimal implementation'],
      'scope':'Normal archive_final and strict validator unchanged. Overload retains all raw ProtocolError reconciliation and strict audit violations; only exact known two diagnostic strings are discharged after full immutable plan/native/watch binding. Unknown/unrelated/duplicate diagnostics remain failures.'}
    if name=='implementation':manifest['requires_testfirst_patch_sha256']=hashlib.sha256((bundle/'testfirst/testfirst.patch').read_bytes()).hexdigest()
    (stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(name,manifest['patch_sha256'])
testfile=bundle/'testfirst/after/bridge/src/app/tests/runtime/write_wait_qualification/backend/final_transport/refusals/tests.rs'
selectors=['app::tests::runtime::write_wait_qualification::backend::final_transport::refusals::tests::'+name for name in re.findall(r'^fn (final_transport_\w+)\(',testfile.read_text(),re.M)]
(bundle/'testfirst/selectors.json').write_text(json.dumps(selectors,indent=2)+'\n')
(bundle/'integration-contract.json').write_text(json.dumps({
 'API':'archive_final_overload(name, (&plan, &verified_refusals), watch, report, mcp_shutdown, native_joined, sink)',
 'normal':'archive_final remains strict; call overload entrypoint only for original immutable physical400 plan',
 'token_API':['VerifiedRefusals.get(id)','VerifiedRefusals.originals()','VerifiedRefusals.matches_slot(&Slot)','VerifiedRefusals.expected_method(id)','VerifiedRefusal.original_id/method/write_id/intended_at/sent_at/intake_at/classified_at/decoded_at/raw_reply/raw_response_artifact getters'],
 'fixture_API':'test_support::{verified_spa_full(),verified_zero_refusals()} -> Bundle {token:Arc<VerifiedRefusals>,plan:Vec<Slot>,watch:ClientWatch,watch_report:WatchReport}; synchronous; each outer test invokes isolated_git_test!',
 'actual_event_binding':'intended<=offered<=rawSent<=watchSent<=nativeIntake==watchServer<=nativeClassified==watchAdmitted<=rawDecoded<=watchFinal<=intended+100ms; finished>=watchFinal; uncancelled, unbreached explicit semantic lifecycle',
 'method_binding':'original Slot remains unchanged. Full immutable Slot equality via private eligible map plus expected Recipe.method == token.method; no MCP candidates.',
 'raw_retention':'Original strict violation strings and ProtocolError rows remain in transport-final. Accepted exception adds actual raw busy value and its original persisted raw artifact path. Failed sink returns exact generated Value and persisted=false.',
 'test_scope':'6 native-accounting/transport-boundary controls; not live carrier Full branch or physical400 qualification. Full load evidence remains mandatory elsewhere.'
},indent=2)+'\n')
