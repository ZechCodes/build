//! Only closed final native refusal tokens can discharge a reply-only failure.
use super::super::super::client_watch::{ClientRow, FinalOutcome, TrafficCohort};
use super::super::super::trial_complete::{Route, Traffic};
use super::super::overload_refusals::VerifiedRefusal;
use super::*;
use std::collections::BTreeMap;
use std::time::Duration;

#[cfg(test)]
mod tests;

pub(super) struct Audit {
    pub errors: Vec<String>,
    pub discharged: Vec<Value>,
}

pub(super) fn partition(
    plan: &[Slot],
    reconcile: Option<&FinalReconciliation>,
    strict_errors: Vec<String>,
    refused: &VerifiedRefusals,
    anchor: Instant,
) -> Audit {
    let mut audit = Audit {
        errors: strict_errors,
        discharged: Vec::new(),
    };
    let mut planned: BTreeMap<&str, Vec<&Slot>> = BTreeMap::new();
    for slot in plan {
        planned.entry(&slot.original_id).or_default().push(slot);
    }
    let mut clients: BTreeMap<&str, Vec<&ClientRow>> = BTreeMap::new();
    if let Some(reconcile) = reconcile {
        for row in &reconcile.rows {
            clients.entry(&row.original_id).or_default().push(row);
        }
    }
    for original in refused.originals() {
        let Some(proof) = refused.get(original) else {
            audit
                .errors
                .push(format!("refusal_missing_token: {original}"));
            continue;
        };
        let slot = planned.get(original).map(Vec::as_slice);
        if !matches!(slot, Some([slot]) if plan_matches(slot, proof, refused, original)) {
            audit
                .errors
                .push(format!("refusal_plan_binding: {original}"));
            continue;
        }
        let rows = clients.get(original).map(Vec::as_slice);
        if !matches!(rows, Some([row]) if client_matches(row, proof)) {
            audit
                .errors
                .push(format!("refusal_client_binding: {original}"));
            continue;
        }
        discharge(&mut audit, proof, anchor);
    }
    audit
}

fn plan_matches(
    slot: &Slot,
    proof: &VerifiedRefusal,
    refused: &VerifiedRefusals,
    original: &str,
) -> bool {
    proof.original_id() == original
        && slot.route == Route::SpaRpc
        && slot.traffic == Traffic::Write
        && refused.matches_slot(slot)
        && refused.expected_method(original) == Some(proof.method())
}

fn client_matches(row: &ClientRow, proof: &VerifiedRefusal) -> bool {
    let (Some(offered), Some(sent), Some(intake), Some(classified), Some(final_at), Some(finished)) = (
        row.offered_at,
        row.sent_at,
        row.server_registered_at,
        row.admitted_at,
        row.final_at,
        row.finished_at,
    ) else {
        return false;
    };
    let Some(deadline) = proof.intended_at().checked_add(Duration::from_millis(100)) else {
        return false;
    };
    row.original_id == proof.original_id()
        && row.cohort == TrafficCohort::SemanticWrite
        && row.intended_at == proof.intended_at()
        && row.registered_at <= row.intended_at
        && row.intended_at <= offered
        && offered <= proof.sent_at()
        && proof.sent_at() <= sent
        && sent <= intake
        && intake == proof.intake_at()
        && intake <= classified
        && classified == proof.classified_at()
        && classified <= proof.decoded_at()
        && proof.decoded_at() <= final_at
        && final_at <= deadline
        && final_at <= finished
        && row.final_outcome == Some(FinalOutcome::ProtocolError)
        && !row.implicit_schedule
        && !row.cancelled
        && row.cancelled_at.is_none()
        && !row.breached
}

fn discharge(audit: &mut Audit, proof: &VerifiedRefusal, anchor: Instant) {
    let original = proof.original_id();
    // Exact known diagnostics only, once each. Never substring-match an ID or
    // erase another failure for the same original. Preserve both in raw export.
    let expected = [
        format!("client_reconciliation: {original}: successful transport reply"),
        format!("client_reconciliation: {original} incomplete or failed lifecycle"),
    ];
    if expected
        .iter()
        .any(|known| audit.errors.iter().filter(|error| *error == known).count() != 1)
    {
        audit
            .errors
            .push(format!("refusal_partition_diagnostic: {original}"));
        return;
    }
    audit.errors.retain(|error| !expected.contains(error));
    audit.discharged.push(json!({
        "original_id":original,"method":proof.method(),"native_write_id":format!("{:?}",proof.write_id()),
        "disposition":"verified_pre_durable_retryable_busy","discharged_strict_diagnostics":expected,
        "raw_reply":proof.raw_reply(),"raw_response_artifact":proof.raw_response_artifact(),
        "intended_at_us":export::at(proof.intended_at(),anchor),
        "sent_at_us":export::at(proof.sent_at(),anchor),
        "native_intake_at_us":export::at(proof.intake_at(),anchor),
        "native_classified_at_us":export::at(proof.classified_at(),anchor),
        "decoded_at_us":export::at(proof.decoded_at(),anchor)
    }));
}
