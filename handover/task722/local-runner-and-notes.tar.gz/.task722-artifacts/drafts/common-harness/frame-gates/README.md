# Full completed-frame hold maximum: TEST-FIRST draft

OFFSOURCE ONLY. No tracked edits, implementation, builds, tests, or product execution occurred. These are explicit unit-data controls using completed `FrameTrace` values and the real `Observation` ledger; they are not native qualification evidence. Normal factory remains fail-closed. The required maximum stays 200 ms; this introduces no 50 ms p95 work and changes no 5 s caller/wait, 100 ms loaded-read, or finite-service bound.

`full-frame-hold-testfirst.patch` adds the empty seam and three unit controls, and wires the seam through the existing `validate_final_rows`. Both original finalization and explicit two-second finalization already call that function. The only changes to existing files are declaring `gates/frames.rs` and taking a final clone of `other_frames` before calling the seam. The ledger lock is released before the gate could record a violation. No observation, service, metrics, runner, factory, pipeline test, or backend source is changed.

The only function seam is:

```rust
validate_frame_holds(rows: &[Row], other_frames: &[FrameTrace], observe: &Observation)
    -> FrameHoldAudit
```

It is intentionally empty and returns `FrameHoldAudit::default()`. The tiny audit has `unique_frames`, `over_limit_frames`, and `max_held_us`. This lets the third control prove collector-observation deduplication directly: the existing violation latch must not accidentally hide double evaluation. No actual hold validation is implemented before the authorized real RED.

Exact selectors:

- `full_frame_hold_max_includes_200000_and_rejects_200001_microseconds`: actual `Observation.frame` enrollment and the normal final-row gate. The inclusive boundary must produce zero hold violations; 200001 must produce one with measured 200001 and limit 200000. Empty seam is expected to fail at the latter assertion.
- `full_frame_hold_rejects_225000_despite_same_original_150000_finite_service`: valid paired unit FS service, root union, finite plan, and completed row. Full frame hold is 225000; service is 150000. Even though subtraction would leave 75000, the gate must record measured 225000 against 200000. Existing finite-service gates must remain otherwise green. Empty seam is expected to fail the missing hold rejection.
- `full_frame_hold_counts_unknown_background_and_shared_observer_ids_once`: real Observation assigns immutable observer IDs. One mixed-origin trace is stored in two known rows and `other_frames`; an unmatched trace and an originless background trace also live in `other_frames`. All three unique IDs must be checked once, all three over-limit measurements retained, and max must be 200003. Empty seam is expected to fail the audit assertion.

Proposed violation contract is stable kind `app_lock_full_frame_hold_max`, full `held_us` in `measured_us`, 200000 in `limit_us`, the first original ID when present (including unmatched IDs) or None for originless background, and an exact `observer_id=<n>;` token in detail. Observer ID is a harness-assigned collector-observation identity, never a product frame ID. Actual held totals already copied from CompletedFrame/Spent remain intact; the future implementation must neither subtract finite services nor reinterpret these as per-acquisition measurements. Row copies and `other_frames` copies of the same observer ID must be deduplicated. Different collector observations must not be discarded based on missing client membership.

Next: parent/Trace review, materialize only this TEST-FIRST patch in an authorized source window, run these controls to establish the intended real RED, then separately authorize implementation. The expected RED above is a prediction from source review, not a result. Review all failures for the intended assertions rather than accepting compilation, setup, or unrelated gate failures as RED. `manifest.json` records the observed source head and exact base/draft SHA256s; shared source may advance independently.

## Root boundary correction before first execution

The reviewed initial inclusive draft was incorrect. The tracked TESTFIRST control now requires199999us allowed,200000us and200001us rejected, with selector `full_frame_hold_max_allows_199999_and_rejects_200000_and_200001_microseconds`. Full held time must be strictly <200ms, matching the existing busy policy. The original initial-draft patch/manifest is retained as provenance; `strict-boundary-correction.patch` records this correction before any test execution. Gate behavior remains the empty TESTFIRST seam.
