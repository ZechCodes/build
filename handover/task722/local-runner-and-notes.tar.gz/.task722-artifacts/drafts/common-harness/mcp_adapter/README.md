MCP backend assembly API (off-source, uncompiled, unrun)
=====================================================

Copy mcp_adapter.rs and its archive.rs, driver.rs, socket.rs children together
only after actual test-first controls and source release. The draft calls actual
tracked AppState, ControlPlane, handle_done_stream, UnixStream and ClientWatch
APIs. It contains no trait-only response implementation or effect fabrication.

Construction and execution
--------------------------

`McpHarness::new(state, registry, identities, watch) -> Result<Arc<McpHarness>, String>`

Construct AFTER actual full fixture/read/Router readiness. Supply the same
Arc<WriteWaitRegistry> as RPC/other producer instrumentation. identities is a
Vec<McpIdentity> with eight Coding identities at endpoints 0..7 and exactly one
passive actual Router at endpoint 8. Fields are agent, issued token, read_only.
The constructor verifies distinct agents, actual token authentication and actual
AddressedSession roles; it does not manufacture a Router or issue credentials.
One ControlPlane captures ready read inputs and is reused across all requests.

`McpHarness::endpoint_for_caller(global_caller) -> Result<usize, String>` maps
trial Coding callers 4..11 to endpoints 0..7 and passive Router caller 12 to 8.

`execute(endpoint, original_id, BridgeAction, read) -> Result<rpc::ReplyProof, String>`

Driver preregisters all immutable relative client IDs before watch setup, calls
watch/start once, and records actual offer BEFORE writer or socket credits.
The adapter registers/offers no ID and never resets the due time. The declared
read flag must match actual is_independent_read classification and the exact
scheduled cohort. Passive Router semantic writes are refused. Each issued
identity has ONE shared two-socket semaphore for reads AND writes; driver keeps
its separate two-semantic-write limit. No extra per-read socket pool exists.
Every accepted call creates one fresh UnixStream pair, sends exactly one frame,
reads one actual final line, half-closes its request direction and requires EOF.
There is no generic pipelining or hidden fanout carrier.

Actual native MCP action replies currently omit an id. The adapter does not add
one: one dedicated socket carrying exactly one authenticated original is its
correlation. If a wire id is present it must match exactly, and actual_wire_id
stays None for current native replies. Malformed, mismatched, extra or duplicate
responses fail; receipts/push-shaped payloads cannot settle this protocol.
Actual send and parsed final callbacks drive the attached watch automatically;
backend must not call them a second time. An ok:false reply is a ProtocolError,
and a missing/malformed response leaves the original unfinished. A transport
error never fabricates a final reply or successful client settlement.

Worker/socket ownership and shutdown
------------------------------------

Each original's worker handle is owned by the adapter, including while queued
for its identity semaphore. The worker retains the acquired permit through
actual client close and accepted server JoinHandle completion. Client timeout or
caller abandonment does not drop/detach the server or release that permit.
Exchange panic is caught outside the accepted server ownership boundary, then
its client closes and the real server still joins. No accepted server abort is
used. Worker handles are removed/reaped only after is_finished is true.

`stop_offers()` rejects new jobs but does not cancel queued/admitted jobs.
`reap_finished().await` joins completed worker handles without taking a pending
handle out of owned storage. `is_quiet()` requires no owned workers and zero
active sockets.

`shutdown(deadline: tokio::time::Instant).await -> McpShutdownReport` stops new
jobs, reaps until quiet/deadline, batch-exports actual registry boundaries, and
returns quiet/unfinished/evidence. is_clean() also checks no errors/abandonment,
actual successful final reply, actual server join, and actual worker reap for
all attempted calls. If unfinished is nonempty, retain the backend/McpHarness
Arc in outer unfinished-cleanup state and fail qualification. Do not discard
ownership or retry/tune a run. The external owned-process timeout remains the
last containment for an actually hung accepted service.

`archive_registry_receipts() -> McpRegistryArchive` is an explicit final/checkpoint
batch, never per read. It imports actual intake/admitted_at through watch *_at
only for started, scheduled, matching semantic IDs owned by this adapter.
Read-lane requests have no invented write origins. Background/provisional/other
adapter/unmatched rows remain in unimported for whole-cohort audit. Shared RPC
and MCP exports contain overlapping registry copies: deduplicate whole-cohort
rows by real WriteId rather than counting each export as new work. collected_at
is export completion only, not a clock for re-aging capped active intervals.

Independent probe and bounded evidence
-------------------------------------

`observation() -> McpObservation` is Sync and holds no guard/receiver.
`pending()` returns an immutable Arc<imbl::OrdMap<String, ()>> transport-active
index; `failed()` and `active_sockets()` read atomics. IndependentProbe uses this
handle, not evidence()/is_quiet() or any mutable caller/AppState/collector lock.
This transport index contains actual worker lifecycle, not a second deadline
watcher. Client due deadlines remain solely in the one ClientWatch watchdog.

`evidence()` is an archival caller-path snapshot. Calls retain scalar times,
status, byte length and SHA-256 of the actual response line (including newline),
not every full read response body. ReplyProof returns the real parsed body to
its native oracle and the coordinator's bounded representative writer.

Actual controls still pending RED
--------------------------------

* Actual eight issued Coding tokens plus one real passive Router are validated;
  wrong/duplicate identities, invented Router, or stale token cannot construct.
* Real read and write for the SAME Coding identity hold both shared permits;
  a third offered original remains unsent, independently ages from intended due,
  and cannot open a third socket. Router remains read-only and separately counted.
* An actual final line (current no-id protocol) alone settles its dedicated
  original, with explicit one-socket correlation and native effect/read oracle.
  Unexpected wire id/extra response fails without fabricating original identity.
* Timeout/abandonment while an actual accepted finite effect is held retains its
  owned worker, accepted server and socket permit. Shutdown deadline reports it;
  releasing the finite service allows actual join/reap/quiet, preserving failure.
* A decode/instrumentation panic still closes and joins its accepted server;
  a transport error without final cannot become ClientWatch.finished_at.
* Archive writes retain exact actual intake/admission timestamps and all other
  cohort rows. Re-export is idempotent, independent read gets no synthetic root.
* IndependentProbe reads observer atomics/immutable maps while the archival jobs
  lock is held, without taking that lock or driving deadlines by a snapshot.

ClientWatch observer/lifecycle additions
--------------------------------------

Only offsource client_watch_complete.rs currently contains these additions:
`guard.observer() -> Arc<ClientWatchObservation>` with failed/polls/indexed and
immutable actual breaches(); and `guard.into_lifecycle()` with observer(),
request_finish(), report()->Option<Arc<WatchReport>>, is_finished(). One shutdown
control owner retains guard/receiver, outside IndependentProbe and any guard
mutex. Its extra thread waits only for finish; it is not a second watchdog.
Breach entries are published before failed=true and retain their own observed_at.
Normal joined stop does not become an unexpected-thread failure. If failed()
with no breach entries occurs (e.g. watchdog panic), emit an explicit infrastructure
Violation rather than declaring an empty caller_breaches list healthy. Retain and
assert the actual joined WatchReport through shutdown. These changes need their
own valid RED/review/source release; current tracked ClientWatch remains frozen.

RPC assembly status and explicit blockers
----------------------------------------

Use the narrow current tracked RpcHarness and new finish_report rather than
blindly copying old rpc_complete.rs, which retains full replies and has outdated
report APIs. Narrow tracked watch attachment now drives send/final callbacks and
batch registry actual timestamps, pending root/Trace review and authorized tests.

There is a real next test-first bootstrap/lifecycle gap: Fixture::ready already
used the same RPC carrier, so strict empty-history attach cannot be used after
bootstrap; ReadyReadInputs.shutdown later issues native cleanup IDs outside the
143000 plan. Need explicit clean-bootstrap attach and quiet qualification detach
controls/APIs, preserving all prior IDs and accounting real lifecycle frames.
Do not clear prior IDs, prefix-filter watch callbacks or create hidden replacement
carriers. A nonclosing explicit timestamp-export boundary is also needed before
detach if final reconciliation requires it. No normal qualification run is
unblocked by this off-source draft alone.
