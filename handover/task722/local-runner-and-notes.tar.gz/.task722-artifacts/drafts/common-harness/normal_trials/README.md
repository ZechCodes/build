# Six-original entrypoint draft — OFFSOURCE, not ready to execute

Exact ignored selector: `app::tests::runtime::write_wait_qualification::normal_trials::qualify_small_and_large_three_original_ten_minute_trials`.

This package preserves the existing six-original engine: Small1/2/3 then Large1/2/3, exactly 600 s offers per trial and 40 semantic writes/s. It neither retries failed originals nor substitutes the short smoke. SQL-only conservative failures stop later originals for review. All 5 s/100 ms/strict <200 ms rules remain unchanged.

## Files and boundaries

- `registration.patch` wires the ignored selector, four afterimages, shared smoke metadata helpers and exactly two additional environment names in the isolated Git child. It does **not** enable normal factory readiness.
- `provenance.rs` verifies the supplied actual clean source/tree and successful NI10 opt3 lib-test receipts, their frozen raw hashes, the current compiled worktree HEAD/tree/clean status, its own actual executable hash/NI10/affinity, fixed envelope declarations and the time-bounded coordinator quiet authorization. Declarations are not native fixture evidence. Only `BUILD_QUALIFICATION_MANIFEST` and `BUILD_QUALIFICATION_QUIET_RELEASE` are new inherited inputs.
- `qualification_metadata.rs` contains shared actual binary/affinity readers plus `read_input` and `validate_build(&Provenance, ...)`. Fault entrypoints may reuse those helpers without importing the six-original loader or widening the environment list.
- `evidence.rs` preserves raw inputs before any fixture, atomically claims a fresh run directory and records errors. Existing roots cannot be overwritten. The entrypoint saves the actual returned report before assertions and retains unfinished ownership instead of silently declaring cleanup success.
- `read-transport.patch`, `read_actual.rs` and `read_cohort.rs` are the minimal read adapter package. The actual full RPC/MCP native oracle and recipe-specific Ready/Legacy form drive proofs; decoded stage/oracle failures pass to raw failure archival. Effects owns additive write-only transport changes.
- `native-counts.patch` and `bind_fixture_counts.rs` measure real native fixture state before T0 using the existing shutdown-count reader. Any mismatch must take the retained preparation-failure path. External worktrees remain visible without being incorrectly counted as registered workspaces.
- `NORMAL-ENABLE.md` gives the single-backend integration order; `TEST-PLAN.md` lists the required red/green controls. Normal readiness remains blocked until native proof consumers, fixture/count/read adapters and final audits are integrated and green.

The quiet receipt is an external coordinator authorization and attestation, not a claim that the test scanned the host. The authorized runner must retain exact child PID/start/exit receipts, keep the whole host free of builds/gates during the six normal trials and allow the full 60 minutes of offers plus setup/drain/cleanup. Source, binary/compiler, service-hook contract and quiet receipts must all belong to the same frozen run. The coordinator alone dispatches timing.yml and sets the aggregate p95 calibration threshold.

These are uncompiled off-source drafts. No qualification has run and no source readiness claim follows from this package. `manifest.json` supersedes the older bae-based draft hashes. Final #722 evidence must name #725's real filesystem mutex hold limit.
