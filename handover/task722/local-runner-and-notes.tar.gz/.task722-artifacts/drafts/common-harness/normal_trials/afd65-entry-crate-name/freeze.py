"""Hash and package only the already-written offsource afterimages."""
from pathlib import Path
import difflib
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
COMMIT = "afd65d0829c51dff6889d61715c8e5b017a24867"
PREFIX = "bridge/src/app/tests/runtime/write_wait_qualification"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def files(stage):
    return {str(path.relative_to(stage)): path.read_bytes()
            for path in sorted(stage.rglob("*")) if path.is_file()}


def patch(before, after):
    parts = []
    for name in sorted(before.keys() | after.keys()):
        if before.get(name) == after.get(name):
            continue
        parts.extend(difflib.unified_diff(
            before.get(name, b"").decode().splitlines(keepends=True),
            after.get(name, b"").decode().splitlines(keepends=True),
            fromfile="a/" + name if name in before else "/dev/null",
            tofile="b/" + name if name in after else "/dev/null"))
    return "".join(parts).encode()


base = files(ROOT / "base")
testfirst = files(ROOT / "testfirst/after")
implementation = files(ROOT / "implementation/after")
artifacts = {}
for name, before, after in [
    ("testfirst.patch", base, testfirst),
    ("implementation.patch", testfirst, implementation),
    ("combined.patch", base, implementation),
]:
    data = patch(before, after)
    (ROOT / name).write_bytes(data)
    artifacts[name] = {"sha256": digest(data), "bytes": len(data)}

selectors = []
for name, data in implementation.items():
    if not name.endswith(".rs"):
        continue
    text = data.decode()
    if name.startswith(PREFIX + "/"):
        suffix = name[len(PREFIX) + 1:-3].replace("/", "::")
        module = "app::tests::runtime::write_wait_qualification::" + suffix
    elif name == "bridge/src/git_fixture/environment.rs":
        module = "git_fixture::environment::tests"
    else:
        continue
    for function in re.findall(r"#\[(?:tokio::)?test(?:\([^\n]*\))?\]\s*(?:async )?fn (\w+)\(", text):
        if function in {
            "a_child_with_no_matching_test_is_rejected",
            "a_matching_child_reuses_the_prepared_environment",
        }:
            continue
        selector = module + "::" + function
        if "pipeline_tests" not in selector:
            selectors.append(selector)

red_names = {
    "quiet_release_cannot_authorize_another_purpose_or_selector",
    "compiler_receipt_rejects_conflicting_flags_even_with_valid_summary_fields",
    "isolated_child_forwards_only_explicit_qualification_paths",
}
selection = {
    "executed": False,
    "new_control_count": len(selectors),
    "expected_testfirst_red": sorted(s for s in selectors if s.rsplit("::", 1)[-1] in red_names),
    "expected_testfirst_green": sorted(s for s in selectors if s.rsplit("::", 1)[-1] not in red_names),
    "all_expected_implementation_green": sorted(selectors),
    "excluded_ignored_qualification": "app::tests::runtime::write_wait_qualification::normal_trials::qualify_small_and_large_three_original_ten_minute_trials",
}
assert len(selectors) == 19, len(selectors)
(ROOT / "selectors.json").write_text(json.dumps(selection, indent=2) + "\n")
manifest = {
    "schema": "task722.offsource-entry-controls.v1",
    "base_revision": COMMIT,
    "base_tree": "e5376da552002776fcff83c0d652ca8733859855",
    "source_clean_at_freeze": True,
    "qualification": False,
    "tests_executed": False,
    "builds_executed": False,
    "offsource_rustfmt_exit": 0,
    "new_control_count": 19,
    "expected_red_count": 3,
    "normal_factory_enabled": False,
    "patches": artifacts,
    "baseline": {name: digest(data) for name, data in base.items()},
    "testfirst": {name: digest(data) for name, data in testfirst.items()},
    "implementation": {name: digest(data) for name, data in implementation.items()},
}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"patches": artifacts,
                  "metadata_sha256": manifest["implementation"][PREFIX + "/qualification_metadata.rs"],
                  "new_controls": len(selectors)}, indent=2))
