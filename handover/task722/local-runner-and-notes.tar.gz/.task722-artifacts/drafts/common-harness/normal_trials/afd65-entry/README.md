# Entry/provenance controls: OFFSOURCE, not executed

Base is clean `afd65d0829c51dff6889d61715c8e5b017a24867`, tree
`e5376da552002776fcff83c0d652ca8733859855`. The source checkout, build outputs,
and coordinator calibration run were left untouched.

Apply `testfirst.patch` first, capture its focused results, then apply
`implementation.patch`. The latter is incremental against TESTFIRST.
`combined.patch` is only the final review diff; applying it first would skip
the required red observation. The afterimages and `manifest.json` are the
authoritative package. No test result is claimed here. Rustfmt parsed and
formatted only these offsource Rust afterimages successfully; there was no
compiler, cargo, test, gate, or qualification invocation.

Nineteen new selectors are listed in `selectors.json`. Three are expected RED
in TESTFIRST and GREEN after the implementation:

- Quiet authorization cannot use a physical-control purpose, another selector,
  or omit either binding.
- Compiler evidence cannot append contradictory optimization, debug-assertion,
  or crate-name flags while retaining valid summary fields.
- The isolated Git child must forward the two explicit qualification inputs.
  Its exact environment key set excludes arbitrary qualification/BRIDGE names,
  keeps private HOME/identity/marker values, and preserves exact test selection.

The remaining controls cover both actual captured receipt shapes; head, tree,
dirty patch and untracked changes in either receipt; build exit/NI/profile/cfg;
binary file hashing; a temporary repository's actual changed head/tree/working
state; supplied actual runtime NI/hash/affinity; exact Small/Large declarations;
quiet authorization identity and inclusive clock boundaries; byte-identical
malformed/hash-mismatched input retention; later missing input; exclusive
artifact-root/file creation; actual caught suite error/panic classification;
preflight archival and visible artifact-write errors. A narrow startup-failure
factory runs the existing six-original coordinator without constructing a
backend or starting timed traffic, then verifies all six ordered outcomes,
five explicit NotAttempted reasons, one factory call, identical returned and
history reports, and refusal to reuse the root. This is a control, not a timed
qualification run.

The ignored six-original selector remains
`app::tests::runtime::write_wait_qualification::normal_trials::qualify_small_and_large_three_original_ten_minute_trials`.
It still performs three Small and three Large originals with 600 seconds each.
The normal factory remains closed. No five-second, 100 ms, strict <200 ms,
offer count, caller-credit, or original-replacement rule changes here.

Only `BUILD_QUALIFICATION_MANIFEST` and `BUILD_QUALIFICATION_QUIET_RELEASE` are
new runtime environment inputs. Existing explicit isolated-child support
variables remain unchanged. The new valid normal quiet receipt requires
`purpose: "six-original-qualification"` and `exact_selector` equal to the ignored
selector above, in addition to the existing run/source/tree/binary/root,
coordinator, quiet-interval, issue-time, and start-deadline bindings. This is an
external coordinator authorization; these controls do not scan or certify the
whole host.

Shared metadata API stays `actual_affinity`, `binary_hash`, `read_input`,
`validate_build`, and `validate_current_source`. Smoke imports the first two
unchanged implementations. Faults can continue importing this shared module;
they retain their private purpose/launcher binding. Merge root module additions
with the producer/Faults registration: register `qualification_metadata` once.
This package does not touch the producer's native counts, read adapters,
compatibility cases, factory readiness, or Faults' process/entry files.

Remaining integration evidence: compiler/strict-warning results for these
drafts; observed red/green results; the existing strict 312 smoke and focused
controls; native fixture/read compatibility and physical controls; final
freeze/quiet authorization and actual release six-original execution. The
receipt fixtures are copied from checkpoint 005 to test its real schema, and
are never evidence that a newly integrated binary has that old hash.
