OFFSOURCE TESTFIRST only; no tests/builds executed, no source applied.

Six selectors remain those in manifest.json. The native59 timing/read-error controls and large native count control require explicit isolated release NI10. All 100 ms, 5 s, exact native identities and native cleanup assertions remain unchanged.

Successor fixes two static blockers: tasks.get returns result.task.id, and pre-dispatch helper failures now reach their decisive assertion only after owned producer/MCP/watch joins and real native cleanup. Cancelled originals remain cancelled, quiet detach still refuses missing finals, and the real terminal/read cleanup errors survive beside original proof failures. Existing fixture cleanup attempts all tab retirements and encrypted receiver joins and retains roots on any unconfirmed cleanup. This control makes no qualification claim and no claim that refusal means successful detachment.

The existing cleanup helper is made qualification-visible; this is the identical one-line dependency in Lifecycle core and must be deduplicated during union. No PreparedBackend normal shutdown policy is changed by this component.
