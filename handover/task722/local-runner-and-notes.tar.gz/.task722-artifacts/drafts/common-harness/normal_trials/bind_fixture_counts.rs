// OFFSOURCE backend helper. Call after assemble()/bootstrap and before
// attach_client_watch/T0 when enabling the same engine's Qualification mode.
// On failure return PreparationFailure with the original PreparedBackend;
// preserve its existing owned shutdown path rather than unwrap/drop it.
fn bind_native_fixture_counts(prepared: &mut PreparedBackend) -> Result<(), String> {
    if prepared.mode != PipelineMode::Qualification {
        return Ok(());
    }
    let actual = prepared
        .fixture
        .as_ref()
        .ok_or("owned normal fixture missing")?
        .qualification_count_receipt();
    let supplied = &prepared.provenance.fixture_counts;
    let index = match prepared.name.envelope {
        Envelope::Small => 0,
        Envelope::Large => 1,
    };
    let expected = supplied["expected_envelopes"]
        .as_array()
        .and_then(|envelopes| envelopes.get(index))
        .ok_or("normal fixture declaration missing")?;
    let tasks = actual["task_counts"]
        .as_array()
        .ok_or("native task count receipt missing")?;
    let expected_tasks = expected["tracker_tasks"]
        .as_u64()
        .ok_or("expected task total missing")?;
    if supplied["qualification"] != true
        || tasks.len() != 4
        || tasks
            .iter()
            .any(|count| count.as_u64() != Some(expected_tasks / 4))
        || actual["projects"] != expected["projects"]
        || actual["registry_residents"] != expected["registry_workspaces"]
        || actual["active_workspaces"] != expected["active_workspaces"]
        || actual["canonical_histories"] != expected["canonical_histories"]
        || actual["total_thread_items"] != expected["thread_items"]
        || actual["live_sessions"] != 8
    {
        return Err(format!("actual pre-T0 fixture differs from fixed envelope: expected={expected}; measured={actual}"));
    }
    prepared.provenance.fixture_counts = serde_json::json!({
        "supplied_contract":supplied,"actual_pre_t0":actual,
        "trial":prepared.name,"source_revision":prepared.provenance.source_revision,
        "source_tree":prepared.provenance.source_tree,"binary_sha256":prepared.provenance.binary_sha256,
        "boundary":"after real native support/bootstrap; before first caller or producer start"
    });
    Ok(())
}
