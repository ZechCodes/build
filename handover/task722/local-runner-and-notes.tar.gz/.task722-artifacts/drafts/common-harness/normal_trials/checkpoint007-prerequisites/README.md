# Checkpoint007 fixture prerequisites — not implementation

Base: f7f246aae024c763397fe861c706c6cac29390a9. Offsource only.

- Control22: exact normal method source owner/caller selects its own action, expected native oracle and issued MCP endpoint. The immutable original schedule is unchanged. Only14 derived compatibility identities are enrolled at unchanged150ms offsets; watch budgets remain100ms. All native resource cleanup and45/14 oracles remain required.
- Controls23–25: their measured native counts and typed results are captured before one actual github.repos read through the existing encrypted RPC adapter. The existing native case oracle checks its returned payload. This is explicitly fixture-prerequisite activity outside the pre-T0 count/classification boundary, not a normal original or timing pass. Raw response, actual latency and success/error are retained; caught errors do not skip real cleanup. Existing full-fixture gh activity/isolation assertions are unchanged.
- Binder and expected_read_cohort TESTFIRST stubs remain unchanged. Controls23–25 need their first decisive target RED after these prerequisite fixes.

No product behavior, normal schedule, counters, thresholds, proof assertions or factory readiness is changed. No build or test was run for this draft.
