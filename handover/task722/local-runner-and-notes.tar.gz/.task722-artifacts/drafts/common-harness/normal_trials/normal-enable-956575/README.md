# Held normal factory enable reconciliation

This is an off-source additive reconciliation against the exact source and per-file hashes in manifest.json. It is not applied, compiled, executed, or a readiness claim.

The four target changes preserve the current Fault overload state/audit and decoded-event integration, optional-notice/report fields, MCP cleanup ownership, and the genuine github.repos prerequisite in the actual CloseJob control. Roster targeting and physical read-timer attribution are outside these targets and remain unchanged.

The pending optional-notice implementation changes close.rs, native_archive.rs, optional_notices.rs and setup.rs. It has no target overlap here. Its already-present test-first additions in backend/mod.rs and close/tests.rs are retained. Entry's dead ProofGap variant cleanup is a prerequisite; the reconciled normal execute match preserves Verified and returns an error for unexpected Refused, with no proof-gap success path.

The existing single engine may accept only the six fixed names and the actual measured full native fixture, with 24,000 writes, 59,000 reads and 60,000 exempt calls per 600-second original. Preparation and backend-create failures retain their initiating error even if real cleanup also fails. The normal watch/recipe schedule is attached once and exact typed native read recipes include the unchanged 100 ms LegacyFull list_tasks policy.

Do not apply this package until the parent explicitly releases the source window and all prerequisites in the manifest are proven. In particular, #738/#741/#751/#752 integration/recalibration and Large pre-T0 count proof remain pending. No original trial has been enabled or run by this package. The separate final-producer count/coherence gate must also be integrated and controlled before original trials.
