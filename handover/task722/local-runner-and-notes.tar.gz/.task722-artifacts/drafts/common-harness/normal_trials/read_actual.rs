// OFFSOURCE replacement for ControlBackend::read_actual only. Reuses the
// existing transport/strong native oracle, with its typed result retained next
// to the actual reply so failures are archived before being returned.
pub(super) async fn read_actual(
    &self,
    prepared: &PreparedBackend,
    slot: &Slot,
    recipe: &Recipe,
    observe: &Observation,
) -> Result<ControlExecution, String> {
    use super::super::transport::NativeReadOutcome;
    use crate::app::tests::runtime::write_wait_qualification::read_recipes::FullReadForm;
    let native = prepared.dispatch_read(slot, observe).await?;
    let mut cohort = None;
    let response_evidence = verify_and_summarize_response(
        prepared.name,
        &slot.original_id,
        &recipe.method,
        &native.reply.reply,
        |_| {
            let actual = match native.native_outcome? {
                NativeReadOutcome::Rpc(FullReadOutcome::Ready) => ReadCohort::ReadyBounded,
                NativeReadOutcome::Rpc(FullReadOutcome::LegacyFull) => ReadCohort::LegacyUnbounded,
                NativeReadOutcome::Rpc(_) => {
                    return Err("actual native RPC read pending/refused/unavailable".into())
                }
                NativeReadOutcome::McpVerified { actual_tool, form } => {
                    if recipe.method != format!("mcp.control:{actual_tool}") {
                        return Err("actual MCP tool differs from frozen recipe".into());
                    }
                    match form {
                        FullReadForm::Ready => ReadCohort::ReadyBounded,
                        FullReadForm::LegacyFull => ReadCohort::LegacyUnbounded,
                    }
                }
            };
            if recipe.expected_read_cohort.as_ref() != Some(&actual) {
                return Err("actual native read form differs from declared typed recipe".into());
            }
            // The full decoded native oracle ran inside dispatch_read; this
            // witness records that result, never a copied expected JSON body.
            let witness = native_read_witness(&recipe.method, &actual);
            cohort = Some(actual);
            Ok(witness)
        },
        &*self.sink,
    )?;
    observe.stage(&slot.original_id, Stage::EffectVerified, Instant::now())?;
    Ok(ControlExecution::Verified(actual_proof(
        slot,
        recipe,
        response_evidence,
        cohort,
        observe,
    )))
}
