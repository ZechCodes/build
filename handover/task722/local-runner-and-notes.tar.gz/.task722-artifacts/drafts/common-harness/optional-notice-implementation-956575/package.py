from pathlib import Path
import difflib,hashlib,json,subprocess,tempfile,shutil
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=sorted(p.relative_to(O/'base') for p in (O/'base').rglob('*.rs'))
patch=''.join(''.join(difflib.unified_diff((O/'base'/f).read_text().splitlines(True),(O/'after'/f).read_text().splitlines(True),fromfile='a/'+str(f),tofile='b/'+str(f))) for f in files)
(O/'implementation.patch').write_text(patch)
with tempfile.TemporaryDirectory(dir=O,prefix='replay-') as d:
 shutil.copytree(O/'base',d,dirs_exist_ok=True)
 p=subprocess.run(['patch','--batch','--fuzz=0','-p1','-d',d],input=patch,text=True,capture_output=True)
 assert p.returncode==0,p.stdout+p.stderr
 assert all(sha(Path(d)/f)==sha(O/'after'/f) for f in files)
P=Path('bridge/src/app/tests/runtime/write_wait_qualification/backend')
def section(s,start,end):return s[s.index(start):s.index(end,s.index(start))]
b=(O/'base'/P/'control/close.rs').read_text();a=(O/'after'/P/'control/close.rs').read_text()
protected={
 'fault_archive_transport':section(b,'    fn archive_transport(','    fn final_archive(')==section(a,'    fn archive_transport(','    fn archive_optional_failure('),
 'fault_final_archive':section(b,'    fn final_archive(','    async fn close_native(')==section(a,'    fn final_archive(','    async fn close_native('),
 'fault_final_success_order':section(b,'        let native_joined = self.close_native(prepared).await;','    async fn join_workers(')==section(a,'        let native_joined = self.close_native(prepared).await;','    async fn join_workers('),
 'd69_audit_detach':section(b,'        let (report, before) = match','        let owner = release_app_owners(prepared);')==section(a,'        let (report, before) = match','        if let Err(error) = prepared.drain_optional_notices'),
 'native_row_visibility_and_body':(O/'base'/P/'native_archive.rs').read_text().split('pub(super) fn native_row',1)[1]==(O/'after'/P/'native_archive.rs').read_text().split('pub(super) fn native_row',1)[1],
 'roster_mapping':section((O/'base'/P/'setup.rs').read_text(),'    fn prepare_recipes(','    pub(super) fn prepare_bounded_recipes(')==section((O/'after'/P/'setup.rs').read_text(),'    fn prepare_recipes(','    pub(super) fn prepare_bounded_recipes('),
}
assert all(protected.values()),protected
m={'schema':'build.offsource.optional-notice-successor.v1','source_revision':'95657518f0fb335f0bb8bf83b909b39cc032f2bc','status':'held implementation only; checkpoint009 interrupted, all38 NOTRUN; causal RED remains required','supersedes_patch_sha256':'8318440faa27ef35e7d107a5903dfc31922657192f3ecb733b116adcb2c82435','patch_sha256':sha(O/'implementation.patch'),'source_materialized':False,'builds_executed':False,'tests_executed':False,'qualification':False,'bindings':[{'target':str(f),'base_sha256':sha(O/'base'/f),'after_sha256':sha(O/'after'/f)} for f in files],'static_validation':{'exact_patch_replay':True,'fuzz_used':0,'protected_current_source_regions_unchanged':protected},'coordination':{'entry_cleanup':'setup.rs adds only prepare_optional_notices call; Entry edits git_support return destructuring in two separate methods','producer_normal_enable':'no target-file overlap with normal-enable-956575','mcp_setup_cleanup':'shutdown.rs and current TESTFIRST child module untouched'}}
(O/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'patch_sha256':m['patch_sha256'],'manifest_sha256':sha(O/'manifest.json'),'protected':protected},indent=2))
