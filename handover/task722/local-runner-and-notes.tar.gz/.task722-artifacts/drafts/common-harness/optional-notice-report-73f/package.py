from pathlib import Path
import difflib,hashlib,json
OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted({p.relative_to(OUT/stage) for stage in ['base','testfirst','after'] for p in (OUT/stage).rglob('*.rs')})
def patch(left,right):
 output=[]
 for f in paths:
  a=OUT/left/f;b=OUT/right/f
  at=a.read_text().splitlines(True) if a.exists() else []
  bt=b.read_text().splitlines(True) if b.exists() else []
  output.extend(difflib.unified_diff(at,bt,fromfile='a/'+str(f) if a.exists() else '/dev/null',tofile='b/'+str(f) if b.exists() else '/dev/null'))
 return ''.join(output)
for name,left,right in [('testfirst','base','testfirst'),('implementation','testfirst','after'),('combined','base','after')]:
 (OUT/(name+'.patch')).write_text(patch(left,right))
prefix='app::tests::runtime::write_wait_qualification::backend::optional_notices::tests::'
manifest={
 'status':'offsource static review candidate; no build or test executed; implementation held for actual TESTFIRST RED',
 'source_revision':'2aaceab93043a4cdb02f10ba2d519ab38583f84e',
 'original_review_revision':'73f3578f315939b5716fb94dc0a6070f52037bb6',
 'reviewed_dependency':'d69e2f0fa28516a79914575dd88ead2926666d8b465f1bc87d35b169e312d6c5, now committed in source_revision',
 'source_materialized':False,'builds_executed':False,'tests_executed':False,'qualification':False,
 'patches':{name:sha(OUT/(name+'.patch')) for name in ['testfirst','implementation','combined']},
 'bindings':[{'target':str(f),**{stage+'_sha256':sha(OUT/stage/f) if (OUT/stage/f).exists() else None for stage in ['base','testfirst','after']}} for f in paths],
 'new_test_selectors':[prefix+s for s in ['native_optional_notice_setup_captures_exact_plan_and_zero_cohort','native_optional_report_preserves_off_on_completed_and_censored_cleanup_counts','native_optional_report_cleanup_preserves_mixed_and_running_turns']],
 'extended_native_control':'app::tests::runtime::write_wait_qualification::backend::control::close::tests::actual_close_job_audits_failed_terminal_watch_before_full_native_cleanup',
 'unchanged_required_native_controls':'app::tests::tracker_tracking::optional_notices:: (all existing controls)',
 'testfirst_expected_first_failures':[
  'actual prepare_collectors must install optional notice capture before T0 (after actual setup cleanup)',
  'report[enabled] null versus actual disabled policy false (after real native queue completion)',
  'report[before_cleanup][active] null versus real optional mixed child count1 (after real mixed turn completion)',
  'actual prepare_collectors must capture optional notices (existing CloseJob after actual full cleanup and failed-workload preservation assertions)'],
 'static_validation':['rustfmt --edition 2021 --config skip_children=true on offsource afterimages only; no compilation','additive rebase of mirrored target files onto committed 2aaceab93; no source writes'],
}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(paths),'patches':manifest['patches'],'manifest_sha256':sha(OUT/'manifest.json')},indent=2))
