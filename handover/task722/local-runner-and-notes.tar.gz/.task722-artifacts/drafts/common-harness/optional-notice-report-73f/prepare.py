from pathlib import Path
import shutil, subprocess
ROOT=Path('/home/zech/Projects/.build-worktrees/workspaces/proj-1/lock-hold-709')
SRC=ROOT/'Build'; OUT=ROOT/'.task722-artifacts/drafts/common-harness/optional-notice-report-73f'
P='bridge/src/app/tests/runtime/write_wait_qualification/'
files=[P+'backend/mod.rs',P+'backend/setup.rs',P+'backend/native_archive.rs',P+'backend/control/close.rs',P+'backend/control/close/tests.rs',P+'backend/control/archive/tests.rs','bridge/src/timing/optional_notices.rs','bridge/src/app/tests/tracker_tracking.rs','bridge/src/app/tests/tracker_tracking/optional_notices.rs']
for kind in ['base','testfirst','after']:
 for f in files:
  p=OUT/kind/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SRC/f,p)
# Close afterimages depend only on the separately held, reviewed d69 patch.
patch=(ROOT/'.task722-artifacts/drafts/quiet-watch-detach/close-path/close-path-implementation.patch').read_text()
start=patch.index('diff --git a/'+P+'backend/control/close.rs')
end=patch.index('diff --git ',start+1)
for kind in ['base','testfirst','after']:
 subprocess.run(['patch','--batch','-p1','-d',str(OUT/kind)],input=patch[start:end],text=True,check=True,stdout=subprocess.DEVNULL)
def edit(kind,f,old,new):
 p=OUT/kind/f;s=p.read_text();assert old in s,(kind,f,old);p.write_text(s.replace(old,new,1))
for kind in ['testfirst','after']:
 edit(kind,P+'backend/mod.rs','mod native_archive;','mod native_archive;\nmod optional_notices;')
 edit(kind,P+'backend/mod.rs','    native_archive: Option<serde_json::Value>,','    native_archive: Option<serde_json::Value>,\n    optional_notices: Option<optional_notices::OptionalNoticeEvidence>,')
 edit(kind,P+'backend/mod.rs','            native_archive: None,','            native_archive: None,\n            optional_notices: None,')
 edit(kind,P+'backend/control/archive/tests.rs','        native_archive: None,','        native_archive: None,\n        optional_notices: None,')
 # Reuse the existing native tracker fixture, exposing only within app tests.
 edit(kind,'bridge/src/app/tests/tracker_tracking.rs','mod optional_notices;','pub(in crate::app::tests) mod optional_notices;')
 f='bridge/src/app/tests/tracker_tracking/optional_notices.rs'
 edit(kind,f,'struct Fixture {','pub(in crate::app::tests) struct Fixture {')
 for name in ['state','watcher','task','registry']:
  edit(kind,f,'    '+name+':','    pub(in crate::app::tests) '+name+':')
 for name in ['new','update','advance','finish','row']:
  edit(kind,f,'    fn '+name+'(','    pub(in crate::app::tests) fn '+name+'(')
 # One policy snapshot supplies summary and raw bindings; existing summary API retained.
 edit(kind,'bridge/src/timing/optional_notices.rs','    pub(crate) fn summary(&self) -> OptionalNoticeSummary {\n        let samples = self.samples();', '    pub(crate) fn summary(&self) -> OptionalNoticeSummary {\n        self.snapshot().0\n    }\n    pub(crate) fn snapshot(&self) -> (OptionalNoticeSummary, Vec<OptionalNoticeSample>) {\n        let samples = self.samples();')
 edit(kind,'bridge/src/timing/optional_notices.rs','        OptionalNoticeSummary {\n            offered:', '        let summary = OptionalNoticeSummary {\n            offered:')
 edit(kind,'bridge/src/timing/optional_notices.rs','            active_age_maximum,\n        }\n    }','            active_age_maximum,\n        };\n        (summary, samples)\n    }')
# Setup and report are deliberately unwired in TESTFIRST.
edit('after',P+'backend/setup.rs','    pub(super) fn prepare_collectors(&mut self) -> Result<(), String> {','    pub(super) fn prepare_collectors(&mut self) -> Result<(), String> {\n        self.prepare_optional_notices()?;')
edit('after',P+'backend/native_archive.rs','        "cohort_method_counts":counts,','        "cohort_method_counts":counts,\n        "optional_notices":prepared.optional_notices.as_ref().map(|evidence| evidence.report(prepared.fixture.is_none())),')
# Additive against d69 only; preserve its watch join and detach before native cleanup.
edit('after',P+'backend/control/close.rs','        let Some(mcp) = self.join_workers(prepared).await else {','        let cleanup_deadline = tokio::time::Instant::now() + Duration::from_secs(5);\n        let Some(mcp) = self.join_workers(prepared, cleanup_deadline).await else {')
edit('after',P+'backend/control/close.rs','        let owner = release_app_owners(prepared);','        if let Err(error) = prepared.drain_optional_notices(cleanup_deadline).await {\n            self.error(error);\n            // No native shutdown can cancel a running or mixed turn. Retain\n            // resources and persist the actual active/censored evidence.\n            self.final_archive(prepared);\n            self.archive_transport(prepared, Some(&report), Some(&before), false);\n            return;\n        }\n        let owner = release_app_owners(prepared);')
edit('after',P+'backend/control/close.rs','        prepared: &PreparedBackend,\n    ) -> Option<super::super::super::mcp_adapter::McpShutdownReport> {\n        let deadline = tokio::time::Instant::now() + Duration::from_secs(5);','        prepared: &PreparedBackend,\n        deadline: tokio::time::Instant,\n    ) -> Option<super::super::super::mcp_adapter::McpShutdownReport> {')
