# Physical-fault and overload review package

OFFSOURCE only, uncompiled and unexecuted. This package grants no §8 qualification credit. It changes no tracked source or refs, starts no build or test, and dispatches no workflow. All afterimages bind to clean `afd65d0829c51dff6889d61715c8e5b017a24867`. The normal six-original selector is not used here.

`physical-faults-afd65.patch` is the complete 49-file review candidate. Do not apply it as a shortcut around TDD. `staged/plan.json` is the source-window plan: apply the TESTFIRST registration, observe the real accepted-archive target RED, apply its implementation, then observe the native-verifier target RED, apply its implementation, then observe the transport-partition target RED and apply its implementation. Upstream fixture failures are prerequisite RED, never target RED. Independent parser/provenance controls can share the first build. If Effects already passed independently, use staged/10-native-testfirst-on-accepted.patch instead of stages00/01; it requires the exact normalized accepted implementation and never rolls it back. Shared root registration must still be deduplicated with Entry. The four patches were applied sequentially to disposable exact-base files and reconstructed the final afterimages byte for byte; this is static application evidence only. Rustfmt exited 0. No compiler or runtime result exists for this package.

The shared metadata helper is an external exact-hash dependency in `manifest.json`, owned by Entry. Register it once, and allow only the existing `BUILD_QUALIFICATION_MANIFEST` and `BUILD_QUALIFICATION_QUIET_RELEASE` paths into the isolated child. The helper's own tests/source-window sequence remain separate prerequisites. Normal and fault quiet receipts are purpose-specific; neither grants the other's run capability.

## Executable cases and unchanged limits

The four ignored release-only cases are:

- `physical_pre_ack_app_lock_six_seconds`: a real AppState guard blocks an actual RPC write for six seconds.
- `physical_pre_ack_source_exclusion_six_seconds`: the actual source exclusion blocks an actual Git write for six seconds.
- `physical_post_ack_required_child_six_seconds`: the initiating write replies, then an actual required delivery child remains charged to that original while AppState is held for six seconds.
- `overload_four_hundred_semantic_offers_one_second`: exactly the first 400 common semantic slots, compressed tenfold into one second, with unchanged ownership, identity, two caller write credits and two MCP sockets.

Physical cases require the genuine independent registry watchdog to detect more than five seconds blocked; pre-ACK cases also require the independent client breach. The required-child case requires the initial reply within five seconds. Evidence and cleanup attempts precede verdict assertions. These deliberately injected failures prove detection only.

Overload keeps every accepted-write ACK, effect, completion, 5 s wait, read≤100 ms/no-app-lock, and hold assertion. A refusal must return within 100 ms of its original intended due time, including pre-send delay. Busy MAY occur; zero busy is valid. The plan does not enlarge credits or invent refusals. Caller-credit backlog is a harness-side delay and is reported separately from native admitted/execution/SQLite waits; a true deadline breach remains an overload failure. No overload result waives a normal limit.

## Closed refusal proof and retained evidence

Only an immutable SPA semantic slot may be a carrier-Full refusal candidate. MCP busy remains an ordinary failure. The raw decoded response must carry its exact string original id, `ok=false`, `error_code=busy` and `retryable=true`. Wrapper identity, Recipe method, complete immutable Slot, actual native id/timestamps and raw JSON value must agree.

`SavedEvidence.take_rejected` retains the entire real vector before checking exact expected membership, exactly one take and zero accepted records. It records a provisional rejected outcome, never native-save success. After actual native close, the real final `take_all` retains every late/unknown vector, and successful persistence plus an error-free quiet audit issues a private accepted-record-absence token. This alone is insufficient to prove refusal.

An overload-only bounded cursor quarantine retains every canceled candidate before strict CompletedOrigins import. Progress lookup reads only that original’s retained cursor rows; it never polls the full registry or fills missing evidence from a snapshot. Its separate final verifier requires exactly one original/method-matched canceled terminal native row, no native reply-success ACK, no unfinished/abandoned obligation, zero frames, no finite/SQLite/external service, the final actual wait archive, the accepted-record token, raw-reply binding and original 100 ms bound. Missing/duplicate/malformed evidence and capture errors fail. It preserves `admitted_at` as classified intake before Full; that marker is neither erased nor counted as durable acceptance. Only this final verification creates the private refusal token. Late evidence or a repeated final audit invalidates subsequent token lookup.

Before the runner counts or excludes a refusal, the backend must confirm the actual closed cleanup task, no final audit errors and that exact token/Slot/method. The default backend confirmation rejects. A focused actual-registry control rejects parser-only candidates before final proof and changed/late evidence afterwards.

The strict normal CompletedOrigins import/wait/audit APIs are unchanged. The separate overload final audit excludes only the token's exact unimported canceled originals. Any prior imported error or overlap with an accepted completion remains a failure.

Final transport consumes that same token and exact immutable Slot/method map. It requires one actual SPA semantic client row, actual intake/classified timestamp equality, ordered raw/watch send/decode timestamps, an explicit uncancelled/unbreached final lifecycle and the same original 100 ms deadline. It discharges only the two exact known unsuccessful-reply diagnostics, once each; raw ProtocolError rows and strict diagnostics remain archived. Unknown, duplicate and unrelated diagnostics are preserved. Normal transport remains strict, and a zero-refusal overload uses the same strict audit results.

All400 originals must remain intended/offered/sent/completed, with disjoint accepted successes plus verified refusals totaling400. Refusals are reported separately and never labeled accepted success. Invalid dispositions, archive/sink errors, every engine violation, unsent dependents, missing counts and unfinished cleanup remain asserted after the cleanup attempt.

## Tests and provenance

`test-selectors.json` lists41 unexecuted controls, including the four physical/overload entrypoints. Literal busy payloads in narrow classifier/verifier tests are explicit boundary inputs; they are not live carrier-Full or 400/s evidence. Those tests use actual WriteWaitRegistry canceled roots, ClientWatch events and a real temporary AppState/Store accepted collector persisted through JsonArtifacts, never public token constructors. Late/unknown/nonempty acceptance and native/transport ambiguity have focused negatives.

Each physical entrypoint requires frozen source head/tree, actual current executable SHA, successful actual NI10 optimized build receipts, self nice/affinity, a fresh artifact root and a purpose/selector/source/binary-bound quiet receipt tied to a current launcher PID/start pair in at most four ancestors. Missing provenance blocks before fixture creation. The explicit coordinator quiet attestation is not presented as an invented host inspection. No example receipt authorizes a run.

The known fenced-filesystem app-mutex limit #725 is unchanged and must remain named in the final #722 report. This candidate must pass static review, source-window reconciliation, the staged actual RED/GREEN controls and real frozen-provenance physical runs before any source-readiness or qualification claim.

The separately approved native59-v3 control is not part of afd65. integration-supplements/native-read-unexpected-refusal.patch adds only its exhaustive Refused→error arm when Fault is integrated. It does not change the independent29 batch. After that batch, root/backend/control/effects/count-helper overlaps must merge additively; never overwrite the newer source with these afd65 afterimages. Every test listing now includes its exact Rust selector.
