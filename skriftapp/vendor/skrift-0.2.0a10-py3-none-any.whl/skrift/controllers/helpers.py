"""Shared helpers for public-facing controllers."""

from uuid import UUID

from litestar import Request
from sqlalchemy.ext.asyncio import AsyncSession

from skrift.auth.session_keys import SESSION_USER_ID
from skrift.db.cache import get_by_pk
from skrift.db.models.user import User
from skrift.db.services.setting_service import get_cached_site_theme
from skrift.hooks import RESOLVE_THEME, apply_filters


async def get_user_context(request: Request, db_session: AsyncSession) -> dict:
    """Get user data for template context if logged in."""
    user_id = request.session.get(SESSION_USER_ID)
    if not user_id:
        return {"user": None}

    user = await get_by_pk(db_session, User, UUID(user_id))
    return {"user": user}


async def resolve_theme(request: Request) -> str:
    """Resolve the active theme for this request via filter hook."""
    theme_name = get_cached_site_theme()
    return await apply_filters(RESOLVE_THEME, theme_name, request)
