import hashlib
import logging
from pathlib import Path

from collections.abc import Callable

from litestar import Request, Response
from litestar.exceptions import HTTPException
from litestar.status_codes import HTTP_500_INTERNAL_SERVER_ERROR
from markupsafe import Markup

from skrift.auth.session_keys import SESSION_USER_EMAIL, SESSION_USER_ID, SESSION_USER_NAME, SESSION_USER_PICTURE_URL
from skrift.config import get_settings
from skrift.db.services.setting_service import get_cached_site_name
from skrift.forms.core import CSRF_FIELD_NAME, CSRF_SESSION_KEY
from skrift.lib import observability

logger = logging.getLogger(__name__)

TEMPLATE_DIR = Path(__file__).parent.parent.parent / "templates"


def _accepts_html(request: Request) -> bool:
    """Check if the request accepts HTML responses (browser request)."""
    accept = request.headers.get("accept", "")
    return "text/html" in accept


def _resolve_error_template(status_code: int) -> str:
    """Resolve error template with fallback, WP-style."""
    from skrift.db.services.setting_service import get_cached_site_theme
    from skrift.template import Template
    return Template("error", str(status_code)).resolve(
        TEMPLATE_DIR, theme_name=get_cached_site_theme()
    )


def _get_session_from_cookie(request: Request) -> dict | None:
    """Manually decode session from cookie when middleware hasn't run.

    This replicates Litestar's ClientSideSessionBackend decryption logic synchronously.
    """
    try:
        import time
        from base64 import b64decode
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from litestar.middleware.session.client_side import decode_json, NONCE_SIZE, AAD

        # Get the session cookie
        cookie_value = request.cookies.get("session")
        if not cookie_value:
            return None

        # Get the secret key and hash it the same way asgi.py does
        settings = get_settings()
        secret = hashlib.sha256(settings.secret_key.encode()).digest()

        # Decode the base64 cookie value
        decoded = b64decode(cookie_value)

        # Extract nonce (first 12 bytes)
        nonce = decoded[:NONCE_SIZE]

        # Find where AAD marker starts
        aad_starts_from = decoded.find(AAD)
        if aad_starts_from == -1:
            return None

        # Associated data is the JSON part only (after removing the AAD prefix)
        associated_data = decoded[aad_starts_from:].replace(AAD, b"")

        # Check expiration
        if decode_json(value=associated_data)["expires_at"] <= round(time.time()):
            return None

        # Extract encrypted session (between nonce and AAD marker)
        encrypted_session = decoded[NONCE_SIZE:aad_starts_from]

        # Decrypt using AES-GCM with the JSON part as associated_data
        aesgcm = AESGCM(secret)
        decrypted = aesgcm.decrypt(nonce, encrypted_session, associated_data=associated_data)

        # Deserialize JSON
        session_data = decode_json(decrypted)
        return session_data
    except Exception:
        logger.debug("Session decryption failed", exc_info=True)
        return None


def _get_user_context_from_session(session: dict | None) -> dict | None:
    """Get user display info from session if available."""
    if not session:
        return None
    try:
        user_id = session.get(SESSION_USER_ID)
        if not user_id:
            return None
        return {
            "id": user_id,
            "name": session.get(SESSION_USER_NAME),
            "email": session.get(SESSION_USER_EMAIL),
            "picture_url": session.get(SESSION_USER_PICTURE_URL),
        }
    except Exception:
        logger.debug("Failed to extract user from session", exc_info=True)
        return None


class SessionUser:
    """Lightweight user object for templates, populated from session data."""

    def __init__(self, data: dict):
        self.id = data.get("id")
        self.name = data.get("name")
        self.email = data.get("email")
        self.picture_url = data.get("picture_url")


def _csrf_field_from_session(session: dict | None) -> Callable[[], Markup]:
    """Build a ``csrf_field`` callable for error-page rendering.

    The production ``csrf_field`` template global reads ``request.session``, but
    exception handlers render outside the session middleware, so that global
    raises ``KeyError('request')`` and turns any error page into a second 500.
    This standalone version reads the token straight from the cookie-decoded
    session (the same dict the handler already uses for the logged-in user),
    so the masthead's logout form renders with a valid token.
    """

    def csrf_field() -> Markup:
        token = (session or {}).get(CSRF_SESSION_KEY, "")
        return Markup(
            f'<input type="hidden" name="{CSRF_FIELD_NAME}" value="{token}">'
        )

    return csrf_field


def _render_error_response(
    request: Request, status_code: int, detail: str, json_detail: str | None = None
) -> Response:
    """Render an error response as HTML for browsers or JSON for API clients."""
    if _accepts_html(request):
        session = _get_session_from_cookie(request)
        user_data = _get_user_context_from_session(session)
        user = SessionUser(user_data) if user_data else None
        template_name = _resolve_error_template(status_code)
        template_engine = request.app.template_engine
        template = template_engine.get_template(template_name)
        content = template.render(
            status_code=status_code,
            message=detail,
            user=user,
            site_name=get_cached_site_name,
            csrf_field=_csrf_field_from_session(session),
        )
        return Response(
            content=content,
            status_code=status_code,
            media_type="text/html",
        )

    return Response(
        content={"status_code": status_code, "detail": json_detail or detail},
        status_code=status_code,
        media_type="application/json",
    )


def http_exception_handler(request: Request, exc: HTTPException) -> Response:
    """Handle HTTP exceptions with HTML for browsers, JSON for APIs."""
    detail = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
    return _render_error_response(request, exc.status_code, detail)


def internal_server_error_handler(request: Request, exc: Exception) -> Response:
    """Handle unexpected exceptions with HTML for browsers, JSON for APIs."""
    if not observability.exception(
        "Unhandled exception on {method} {path}",
        method=request.method,
        path=request.url.path,
    ):
        logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return _render_error_response(
        request, HTTP_500_INTERNAL_SERVER_ERROR,
        "An unexpected error occurred.", json_detail="Internal Server Error",
    )
