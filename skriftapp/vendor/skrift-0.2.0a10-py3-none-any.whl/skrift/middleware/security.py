"""Security headers middleware for Skrift.

Injects security response headers (CSP, HSTS, X-Frame-Options, etc.)
into every HTTP response. Headers already set by a route handler are
not overwritten, allowing per-route overrides.

When csp_nonce is enabled, the nonce is appended to the script-src
directive to allow nonced inline scripts. style-src is left unchanged
because CSP nonces do not cover inline style attributes.
"""

import contextvars
import re
import secrets

from litestar.types import ASGIApp, Receive, Scope, Send

# ContextVar for template access to the current request's CSP nonce
csp_nonce_var: contextvars.ContextVar[str] = contextvars.ContextVar("csp_nonce")

_SCRIPT_SRC = re.compile(r"(script-src\s)([^;]*)")
_FORM_ACTION = re.compile(r"(form-action\s)([^;]*)")


def apply_csp_nonce(csp: str, nonce: str) -> str:
    """Append ``'nonce-<nonce>'`` to the ``script-src`` directive.

    ``style-src`` is intentionally left untouched because CSP nonces do not
    cover inline ``style`` attributes.
    """
    return _SCRIPT_SRC.sub(rf"\1\2 'nonce-{nonce}'", csp)


def add_form_action_source(csp: str, source: str) -> str:
    """Allow ``source`` as a ``form-action`` destination in ``csp``.

    If a ``form-action`` directive is present, ``source`` is appended unless it
    is already listed. If absent, a ``form-action 'self' <source>`` directive is
    added so the new source is allowed without silently relaxing the rest of the
    policy. Used by the OAuth2 authorize endpoint to permit the post-consent
    redirect to a validated, registered client ``redirect_uri`` origin.
    """
    if _FORM_ACTION.search(csp):
        def _append(match: re.Match) -> str:
            existing = match.group(2)
            if source in existing.split():
                return match.group(0)
            return f"{match.group(1)}{existing.rstrip()} {source}"

        return _FORM_ACTION.sub(_append, csp)

    return f"{csp.rstrip().rstrip(';')}; form-action 'self' {source}"


class SecurityHeadersMiddleware:
    """ASGI middleware that adds security headers to HTTP responses.

    Args:
        app: The ASGI application to wrap.
        headers: Pre-encoded header pairs as list of (name_bytes, value_bytes).
            Should NOT include CSP (CSP is handled separately via csp_value).
        csp_value: The raw CSP header string (or None to disable CSP).
        csp_nonce: Whether to inject a nonce into script-src.
        debug: Whether the application is running in debug mode.
    """

    def __init__(
        self,
        app: ASGIApp,
        headers: list[tuple[bytes, bytes]],
        csp_value: str | None = None,
        csp_nonce: bool = True,
        debug: bool = False,
        cache_authenticated: str | None = None,
    ) -> None:
        self.app = app
        self.headers = headers
        self.csp_value = csp_value
        self.csp_nonce = csp_nonce
        self.debug = debug
        self.cache_authenticated = cache_authenticated

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        nonce: str | None = None
        token = None

        if self.csp_nonce and self.csp_value:
            nonce = secrets.token_urlsafe(16)
            # Store in scope state for other middleware/handlers
            scope.setdefault("state", {})
            scope["state"]["csp_nonce"] = nonce
            token = csp_nonce_var.set(nonce)

        try:
            # Build CSP header for this request
            csp_header: tuple[bytes, bytes] | None = None
            if self.csp_value:
                if nonce:
                    csp_str = apply_csp_nonce(self.csp_value, nonce)
                else:
                    csp_str = self.csp_value
                csp_header = (b"content-security-policy", csp_str.encode())

            async def send_with_headers(message: dict) -> None:
                if message["type"] == "http.response.start":
                    existing = {h[0].lower() for h in message.get("headers", [])}
                    extra = [(k, v) for k, v in self.headers if k.lower() not in existing]
                    if csp_header and csp_header[0] not in existing:
                        extra.append(csp_header)
                    if (
                        self.cache_authenticated
                        and b"cache-control" not in existing
                        and scope.get("session", {}).get("user_id")
                    ):
                        extra.append((b"cache-control", self.cache_authenticated.encode()))
                    message["headers"] = list(message.get("headers", [])) + extra
                await send(message)

            await self.app(scope, receive, send_with_headers)
        finally:
            if token is not None:
                csp_nonce_var.reset(token)
